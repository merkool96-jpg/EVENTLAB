"""Strict import staging and transactional confirmation. No source API access."""

import csv
import hashlib
import io
import json
import re
import unicodedata
import zipfile
from xml.etree.ElementTree import ParseError
from defusedxml.common import DefusedXmlException
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path
from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone
from core.models import (
    Event,
    ImportBatch,
    AdObservation,
    TicketingEvent,
    OrderRevision,
    RegistrationRevision,
    AuditEntry,
)

MAX_BYTES = 10 * 1024 * 1024
MAX_ROWS = 50000
PARSER_VERSION = "4"

# Exact aliases after accent/case normalization. Unrecognized schemas fail visibly.
ALIASES = {
    "platform": ["platform", "piattaforma"],
    "registration_id": ["registration id", "id registrazione"],
    "guests": ["guests", "partecipanti"],
    "ad": [
        "nome dell’inserzione",
        "nome dell'inserzione",
        "nome inserzione",
        "ad name",
    ],
    "ad_id": ["id inserzione", "id dell'inserzione", "ad id"],
    "campaign": ["nome campagna", "campaign name", "nome della campagna"],
    "adset": ["nome gruppo di inserzioni", "nome del gruppo di inserzioni", "ad set name"],
    "start": [
        "inizio report",
        "inizio dei report",
        "reporting starts",
        "reporting start",
    ],
    "end": ["fine report", "fine dei report", "reporting ends", "reporting end"],
    "spend": [
        "importo speso (eur)",
        "amount spent (eur)",
        "importo speso",
        "amount spent",
    ],
    "currency": ["valuta", "currency"],
    "clicks": ["clic sul link", "link clicks"],
    "impressions": ["impression", "impressions"],
    "purchases": ["acquisti", "purchases"],
    "attributed_revenue": [
        "valore di conversione degli acquisti",
        "purchases conversion value",
    ],
    "attribution": ["impostazione di attribuzione", "attribution setting"],
    "order_id": [
        "numero ordine",
        "numero di ordine",
        "order id",
        "order #",
        "order number",
    ],
    "event_id": ["id evento", "event id"],
    "status": ["stato ordine", "stato dell'ordine", "order status", "status", "stato"],
    "quantity": ["quantità", "quantity", "tickets", "biglietti"],
    "gross": ["vendite lorde", "gross sales", "ricavi lordi", "gross revenue"],
    "fees": [
        "commissioni eventbrite",
        "eventbrite fees",
        "platform fees",
        "commissioni piattaforma",
    ],
    "refunds": ["rimborsi", "refunds"],
}


def normalized(value):
    text = unicodedata.normalize(
        "NFKD", str(value).strip().lower().replace("_", " ").replace("’", "'")
    )
    return " ".join("".join(c for c in text if not unicodedata.combining(c)).split())


def number(value, *, integer=False, optional=False):
    text = str(value).strip().replace("\u00a0", "").replace(" ", "").replace("€", "")
    if text in ("", "-", "—"):
        if optional:
            return None
        raise ValueError("Valore numerico mancante")
    if "," in text and "." in text:
        decimal_sep = "," if text.rfind(",") > text.rfind(".") else "."
        text = text.replace("." if decimal_sep == "," else ",", "").replace(
            decimal_sep, "."
        )
    elif "," in text:
        # Locale is inferred at file level before reaching this helper.
        text = text.replace(",", ".")
    try:
        result = Decimal(text)
    except InvalidOperation:
        raise ValueError("Numero non valido")
    if not result.is_finite() or result < 0:
        raise ValueError("Il numero deve essere finito e non negativo")
    if integer:
        if result != result.to_integral_value():
            raise ValueError("Conteggio non intero: controllare i separatori numerici")
        if result > 9223372036854775807:
            raise ValueError("Conteggio fuori intervallo")
        return int(result)
    if result > Decimal("99999999999999.99") or result.as_tuple().exponent < -2:
        raise ValueError("Importo fuori intervallo o con più di due decimali")
    return str(result.quantize(Decimal(".01")))


def parse_date(value):
    if isinstance(value, datetime):
        return value.date().isoformat()
    text = str(value).strip()
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
        try:
            return datetime.strptime(text, fmt).date().isoformat()
        except ValueError:
            pass
    raise ValueError("Data non riconosciuta; usare YYYY-MM-DD o GG/MM/AAAA")


def table_from_file(upload):
    data = upload.read(MAX_BYTES + 1)
    if len(data) > MAX_BYTES or not data:
        raise ValidationError("File vuoto o superiore a 10 MB.")
    extension = Path(upload.name).suffix.lower()
    if extension == ".csv":
        try:
            text = data.decode("utf-8-sig")
        except UnicodeDecodeError:
            try:
                text = data.decode("cp1252")
            except UnicodeDecodeError:
                raise ValidationError("Codifica CSV non valida; esportare in UTF-8.")
        try:
            dialect = csv.Sniffer().sniff(text[:8192], delimiters=",;\t")
        except csv.Error:
            raise ValidationError("Separatore CSV non riconosciuto.")
        rows = list_row_limit(csv.reader(io.StringIO(text), dialect))
    elif extension == ".xlsx":
        from openpyxl import load_workbook

        try:
            with zipfile.ZipFile(io.BytesIO(data)) as archive:
                if sum(i.file_size for i in archive.infolist()) > 50 * 1024 * 1024:
                    raise ValidationError(
                        "Archivio Excel troppo grande dopo decompressione."
                    )
            workbook = load_workbook(io.BytesIO(data), read_only=True, data_only=False)
            if len(workbook.worksheets) != 1:
                raise ValidationError(
                    "Il file deve contenere un solo foglio; esportare quello desiderato."
                )
            rows = list_row_limit(workbook.active.values)
            workbook.close()
        except (
            zipfile.BadZipFile,
            OSError,
            KeyError,
            ValueError,
            ParseError,
            DefusedXmlException,
        ):
            raise ValidationError("File XLSX non valido.")
    elif extension == ".xls":
        import xlrd

        try:
            book = xlrd.open_workbook(file_contents=data, on_demand=True)
            if book.nsheets != 1:
                raise ValidationError("Il file deve contenere un solo foglio.")
            sheet = book.sheet_by_index(0)
            rows = list_row_limit(sheet.row_values(i) for i in range(sheet.nrows))
            book.release_resources()
        except xlrd.XLRDError:
            raise ValidationError(
                "Il file non è un vero XLS. Esportare CSV/XLSX; gli XLS contenenti HTML richiedono verifica del file originale."
            )
    else:
        raise ValidationError("Formato non supportato: usare CSV, XLS o XLSX.")
    if len(rows) < 2:
        raise ValidationError("Nessuna riga dati disponibile.")
    return data, rows


def list_row_limit(iterator):
    rows = []
    for row in iterator:
        if len(rows) >= MAX_ROWS + 1:
            raise ValidationError("Limite di 50.000 righe superato.")
        if len(row) > 200:
            raise ValidationError("Troppe colonne: massimo 200.")
        rows.append(list(row))
    return rows


def parse(upload, expected_source=None):
    labels = {"meta": "Meta Ads", "eventbrite": "Eventbrite", "partiful": "Partiful", "dice": "DICE"}
    if expected_source is not None and expected_source not in labels:
        raise ValidationError("Selezionare una fonte valida prima di caricare i file.")
    data, table = table_from_file(upload)
    headers = [normalized(v) for v in table[0]]
    if len(set(headers)) != len(headers):
        raise ValidationError("Intestazioni duplicate: correggere il file.")
    mapping = {}
    for field, aliases in ALIASES.items():
        indices = [
            i for i, h in enumerate(headers) if h in [normalized(a) for a in aliases]
        ]
        if len(indices) > 1:
            raise ValidationError(
                f"Più colonne corrispondono al campo {field}; selezionare una sola colonna."
            )
        if indices:
            mapping[field] = indices[0]
    meta = all(k in mapping for k in ("ad", "start", "end", "spend"))
    orders = all(
        k in mapping
        for k in ("order_id", "event_id", "status", "quantity", "gross", "currency")
    )
    rsvp = all(
        k in mapping
        for k in ("platform", "registration_id", "event_id", "status", "guests")
    )
    if sum((meta, orders, rsvp)) != 1:
        raise ValidationError(
            "Fonte ambigua o colonne indispensabili mancanti. Meta: nome inserzione, inizio/fine report, spesa. Eventbrite: ID ordine/evento, stato, quantità, vendite lorde, valuta."
        )
    source = "meta" if meta else "eventbrite"
    if "platform" in mapping and not meta:
        platforms = {
            normalized(row[mapping["platform"]])
            for row in table[1:]
            if len(row) > mapping["platform"] and any(v not in ("", None) for v in row)
        }
        if len(platforms) != 1 or not platforms.issubset(
            {"partiful", "dice", "eventbrite"}
        ):
            raise ValidationError(
                "Indicare una sola piattaforma valida nel tracciato normalizzato."
            )
        source = platforms.pop()
        if rsvp and source != "partiful":
            raise ValidationError(
                "Tracciato registrazioni supportato per Partiful soltanto."
            )

    if expected_source is not None and source != expected_source:
        raise ValidationError(
            f"Hai selezionato {labels[expected_source]}, ma le colonne identificano {labels[source]}. "
            "Carica il report corretto oppure cambia la fonte. Nessun dato importato."
        )

    # Infer decimal style only from explicit monetary text, not from names or counts.
    hints = set()
    for row in table[1:]:
        for field in ("spend", "gross", "fees", "refunds", "attributed_revenue"):
            index = mapping.get(field)
            if index is not None and index < len(row) and isinstance(row[index], str):
                text = (
                    row[index]
                    .strip()
                    .replace("€", "")
                    .replace(" ", "")
                    .replace("\u00a0", "")
                )
                match = re.search(r"([,.])\d{1,2}$", text)
                if match:
                    hints.add(match.group(1))
    if len(hints) > 1:
        raise ValidationError(
            "Separatori decimali discordanti: verificare la formattazione del file."
        )
    decimal_separator = next(iter(hints), None)

    def numeric(raw, **kwargs):
        text = str(raw).strip().replace("€", "").replace(" ", "").replace("\u00a0", "")
        thousands = (
            "."
            if decimal_separator == ","
            else ","
            if decimal_separator == "."
            else None
        )
        if thousands and re.fullmatch(
            r"\d{1,3}(?:" + re.escape(thousands) + r"\d{3})+", text
        ):
            text = text.replace(thousands, "")
        elif re.fullmatch(r"\d{1,3}[,.]\d{3}", text):
            raise ValueError(
                "Separatore ambiguo; esportare senza separatore migliaia o con decimali espliciti"
            )
        return number(text, **kwargs)

    digest = hashlib.sha256(data).hexdigest()
    payload = []
    keys = set()
    intervals = {}
    for row_number, row in enumerate(table[1:], 2):
        if not any(v not in ("", None) for v in row):
            continue

        def get(field):
            index = mapping.get(field)
            if index is None or index >= len(row) or row[index] is None:
                return ""
            value = row[index]
            if (
                field in ("clicks", "impressions", "purchases", "quantity", "guests")
                and isinstance(value, float)
                and not value.is_integer()
            ):
                raise ValueError("Conteggio numerico non intero nel foglio sorgente")
            if isinstance(value, datetime):
                return value.date().isoformat()
            if field in ("order_id", "event_id", "ad_id") and isinstance(
                value, (float, int)
            ):
                if not isinstance(value, bool) and float(value).is_integer():
                    return str(int(value))
            return str(value).strip()

        try:
            currency = get("currency").upper()
            if not currency and meta and "(eur)" in headers[mapping["spend"]]:
                currency = "EUR"
            if not rsvp and currency != "EUR":
                raise ValueError(
                    "Valuta mancante o diversa da EUR; nessuna conversione automatica"
                )
            if meta:
                name = get("ad")
                if normalized(name) in {
                    "totale",
                    "total",
                    "totali",
                    "risultati totali",
                    "grand total",
                }:
                    raise ValueError(
                        "Totale aggregato non importabile insieme al dettaglio; esportare senza righe riepilogative"
                    )
                if not name or len(name) > 255:
                    raise ValueError(
                        "Nome inserzione mancante o troppo lungo; i totali non sono righe importabili"
                    )
                if len(get("attribution")) > 160:
                    raise ValueError("Impostazione di attribuzione troppo lunga")
                start, end = parse_date(get("start")), parse_date(get("end"))
                if end < start:
                    raise ValueError("Periodo invertito")
                # Only platform IDs identify ads. Without them preserve each source row,
                # including identical zero-spend rows, without inventing an ad identity.
                identity = (
                    ["id", get("ad_id")]
                    if get("ad_id")
                    else ["report-row", digest, row_number]
                )
                key = hashlib.sha256(
                    json.dumps(identity, ensure_ascii=False).encode()
                ).hexdigest()
                entry = dict(
                    key=key,
                    stable_identity=bool(get("ad_id")),
                    name=name,
                    start=start,
                    end=end,
                    currency=currency,
                    spend=numeric(get("spend")),
                    impressions=numeric(
                        get("impressions"), integer=True, optional=True
                    ),
                    clicks=numeric(get("clicks"), integer=True, optional=True),
                    purchases=numeric(get("purchases"), integer=True, optional=True),
                    attributed_revenue=numeric(
                        get("attributed_revenue"), optional=True
                    ),
                    attribution=get("attribution"),
                )
                unique = (key, start, end)
                if get("ad_id"):
                    intervals.setdefault(key, []).append((start, end))
            elif rsvp:
                status = normalized(get("status"))
                if status not in ("confirmed", "cancelled"):
                    raise ValueError("Stato RSVP ammesso: confirmed o cancelled")
                rid, eid = get("registration_id"), get("event_id")
                if not rid or not eid or len(rid) > 100 or len(eid) > 100:
                    raise ValueError(
                        "ID registrazione o evento mancante o troppo lungo"
                    )
                guests = numeric(get("guests"), integer=True)
                if guests > 2147483647:
                    raise ValueError("Numero partecipanti fuori intervallo")
                entry = dict(
                    registration_id=rid,
                    event_id=eid,
                    status=status,
                    guests=guests,
                    kind="registration",
                )
                unique = (eid, rid)
            else:
                status = normalized(get("status"))
                statuses = {
                    "completed": "completed",
                    "complete": "completed",
                    "completato": "completed",
                    "completata": "completed",
                    "refunded": "refunded",
                    "rimborsato": "refunded",
                    "cancelled": "cancelled",
                    "canceled": "cancelled",
                    "annullato": "cancelled",
                }
                if status not in statuses:
                    raise ValueError(
                        "Stato ordine non riconosciuto; richiede una mappatura verificata"
                    )
                for field in ("order_id", "event_id"):
                    if not get(field) or len(get(field)) > 100:
                        raise ValueError("ID ordine o evento mancante o troppo lungo")
                entry = dict(
                    order_id=get("order_id"),
                    event_id=get("event_id"),
                    status=statuses[status],
                    quantity=numeric(get("quantity"), integer=True),
                    gross=numeric(get("gross")),
                    fees=numeric(get("fees"), optional=True),
                    refunds=numeric(get("refunds"), optional=True),
                    currency=currency,
                )
                if entry["quantity"] > 2147483647:
                    raise ValueError("Quantità di biglietti fuori intervallo")
                unique = (entry["event_id"], entry["order_id"])
            if unique in keys:
                if meta:
                    raise ValueError(
                        "ID inserzione Meta ripetuto nello stesso periodo: verificare duplicati o breakdown; nessuna somma applicata"
                    )
                if rsvp:
                    raise ValueError("ID registrazione duplicato per lo stesso evento")
                raise ValueError(
                    "Identità ordine duplicata: il report potrebbe contenere righe biglietto anziché righe ordine"
                )
            keys.add(unique)
            entry["row"] = row_number
            payload.append(entry)
        except (ValueError, InvalidOperation) as exc:
            # Error messages never include raw row values or attendee data.
            raise ValidationError(f"Riga {row_number}: {exc}.")
    for periods in intervals.values():
        ordered = sorted(periods)
        for previous, current in zip(ordered, ordered[1:]):
            if current[0] <= previous[1]:
                raise ValidationError(
                    "Righe della stessa inserzione con periodi sovrapposti o breakdown non supportati."
                )
    if not payload:
        raise ValidationError("Nessuna riga valida.")
    if source != "meta" and len({r["event_id"] for r in payload}) != 1:
        raise ValidationError(
            "Più eventi di ticketing nello stesso file: separare gli export per evento."
        )
    return source, digest, payload


def conflicts(event, source, payload, exclude_batch=None):
    if source == "meta":
        existing = list(
            AdObservation.objects.filter(
                batch__event=event, batch__status="confirmed"
            ).exclude(batch_id=exclude_batch)
        )
        by_key = {}
        for row in existing:
            by_key.setdefault(row.source_key, []).append(
                (row.period_start.isoformat(), row.period_end.isoformat())
            )
        # Row-scoped observations cannot be reconciled with another overlapping
        # export, even if its names differ. Never sum two unknown snapshots.
        first, last = min(r["start"] for r in payload), max(r["end"] for r in payload)
        overlapping = [r for r in existing if r.period_start.isoformat() <= last
                       and r.period_end.isoformat() >= first]
        if overlapping and (
            any(not r.get("stable_identity") for r in payload)
            or any(not r.get("stable_identity") for batch in ImportBatch.objects.filter(
                pk__in={r.batch_id for r in overlapping}) for r in batch.payload)
        ):
            raise ValidationError(
                "Report Meta sovrapposti senza ID inserzione: identità non verificabile. "
                "Esportare gli ID oppure annullare il report precedente e caricare lo snapshot completo. Nessuna somma applicata."
            )
        incoming = {}
        for row in payload:
            incoming.setdefault(row["key"], []).append((row["start"], row["end"]))
        for key, periods in incoming.items():
            prior = sorted(by_key.get(key, []))
            cursor = 0
            for start, end in sorted(periods):
                while cursor < len(prior) and prior[cursor][1] < start:
                    cursor += 1
                if cursor < len(prior) and prior[cursor][0] <= end:
                    raise ValidationError(
                        "Periodo già coperto per almeno una inserzione. Annullare il report precedente e caricare quello sostitutivo completo, oppure esportare periodi disgiunti. Nessuna somma è stata applicata."
                    )

    else:
        foreign = TicketingEvent.objects.filter(
            platform=source, external_id=payload[0]["event_id"]
        ).exclude(event=event)
        if foreign.exists():
            raise ValidationError(
                "Questo evento Eventbrite è già associato a un’altra edizione."
            )
        # V1 refuses overlapping order snapshots; no blind overwrite of unknown export chronology.
        registration = payload[0].get("kind") == "registration"
        revision_model = RegistrationRevision if registration else OrderRevision
        id_field = "registration_id" if registration else "order_id"
        previous_orders = set(
            revision_model.objects.filter(
                batch__status="confirmed",
                ticketing_event__event=event,
                ticketing_event__external_id=payload[0]["event_id"],
                ticketing_event__platform=source,
            )
            .exclude(batch_id=exclude_batch)
            .values_list("external_id", flat=True)
        )
        if previous_orders.intersection(r[id_field] for r in payload):
            raise ValidationError(
                "Ordini già presenti in un altro report. Per aggiornare uno snapshot, annullare prima quello precedente e caricare il report completo."
            )


def validate_replacement(event, source, payload, prior, require_confirmed=True):
    if (
        prior.event_id != event.pk
        or prior.source != source
        or (require_confirmed and prior.status != "confirmed")
    ):
        raise ValidationError(
            "Selezionare un report confermato della stessa fonte ed evento."
        )
    if source == "meta":
        by_key = {}
        for row in payload:
            by_key.setdefault(row["key"], []).append((row["start"], row["end"]))
        snapshot_periods = [(row["start"], row["end"]) for row in payload]
        # This is an inventory/completeness guard for an explicitly chosen whole
        # snapshot, never a join of ads by name. Unknown ads retain row identities.
        from collections import Counter
        old_labels = Counter(row["name"] for row in prior.payload if not row.get("stable_identity"))
        new_labels = Counter(row["name"] for row in payload)
        if old_labels - new_labels:
            raise ValidationError(
                "Snapshot Meta senza ID incompleto o con etichette cambiate: "
                "impossibile verificare la sostituzione. Includere tutte le righe precedenti "
                "oppure verificare e annullare esplicitamente il precedente. Nessun dato modificato."
            )
        from datetime import date, timedelta

        for old in prior.payload:
            cursor = date.fromisoformat(old["start"])
            end = date.fromisoformat(old["end"])
            for start, stop in sorted(
                by_key.get(old["key"], []) if old.get("stable_identity") else snapshot_periods
            ):
                start, stop = date.fromisoformat(start), date.fromisoformat(stop)
                if start > cursor:
                    break
                if stop >= cursor:
                    if stop >= end:
                        cursor = None
                        break
                    cursor = stop + timedelta(days=1)
            if cursor is not None:
                raise ValidationError(
                    "La sostituzione deve coprire tutte le inserzioni e tutto il periodo precedente. Nessun dato modificato."
                )
    else:
        field = (
            "registration_id"
            if prior.payload[0].get("kind") == "registration"
            else "order_id"
        )
        if any(
            r.get("event_id") != prior.payload[0]["event_id"] for r in payload
        ) or not {r[field] for r in prior.payload}.issubset(
            {r.get(field) for r in payload}
        ):
            raise ValidationError(
                "Lo snapshot sostitutivo deve contenere tutti gli identificativi del precedente, compresi quelli annullati."
            )


@transaction.atomic
def stage(event, upload, user, replaces=None, expected_source=None):
    event = Event.objects.select_for_update().get(pk=event.pk)
    source, digest, payload = parse(upload, expected_source=expected_source)
    if source == "meta":
        # A reused name is not evidence of the same creative across editions.
        for row in payload:
            if not row.get("stable_identity"):
                row["key"] = hashlib.sha256(
                    f"{event.pk}:{row['key']}".encode()
                ).hexdigest()
    existing = ImportBatch.objects.filter(
        event=event, source=source, sha256=digest
    ).first()
    if existing:
        return existing, False
    if replaces:
        replaces = ImportBatch.objects.select_for_update().get(pk=replaces.pk)
        validate_replacement(event, source, payload, replaces)
    conflicts(event, source, payload, exclude_batch=replaces.pk if replaces else None)
    batch = ImportBatch.objects.create(
        event=event,
        source=source,
        sha256=digest,
        filename=Path(upload.name).name[:255],
        parser_version=PARSER_VERSION,
        created_by=user,
        payload=payload,
        replaces=replaces,
        period_start=min(r["start"] for r in payload) if source == "meta" else None,
        period_end=max(r["end"] for r in payload) if source == "meta" else None,
    )
    return batch, True


@transaction.atomic
def confirm(batch, user):
    Event.objects.select_for_update().get(pk=batch.event_id)
    batch = ImportBatch.objects.select_for_update().get(pk=batch.pk)
    if batch.status == "confirmed":
        return False
    if batch.status not in ("staged", "reverted"):
        raise ValidationError("Importazione non confermabile.")
    if batch.replaces_id:
        prior = ImportBatch.objects.select_for_update().get(pk=batch.replaces_id)
        validate_replacement(
            batch.event, batch.source, batch.payload, prior, require_confirmed=False
        )
        if prior.status == "confirmed":
            prior.status = "reverted"
            prior.save(update_fields=["status", "updated_at"])
            AuditEntry.objects.create(
                actor=user,
                event=batch.event,
                action="import.replaced",
                details={"previous": str(prior.pk), "replacement": str(batch.pk)},
            )
    conflicts(batch.event, batch.source, batch.payload)
    # Reconfirmation restores the same revision rather than inserting new data.
    if (
        not batch.ad_observations.exists()
        and not batch.orders.exists()
        and not batch.registrations.exists()
    ):
        if batch.source == "meta":
            AdObservation.objects.bulk_create(
                [
                    AdObservation(
                        batch=batch,
                        source_key=r["key"],
                        creative_name=r["name"],
                        period_start=r["start"],
                        period_end=r["end"],
                        currency=r["currency"],
                        spend=r["spend"],
                        impressions=r["impressions"],
                        link_clicks=r["clicks"],
                        attributed_purchases=r["purchases"],
                        attributed_revenue=r["attributed_revenue"],
                        attribution=r["attribution"],
                        source_row=r["row"],
                    )
                    for r in batch.payload
                ]
            )
        else:
            link, _ = TicketingEvent.objects.get_or_create(
                platform=batch.source,
                external_id=batch.payload[0]["event_id"],
                defaults={"event": batch.event},
            )
            if link.event_id != batch.event_id:
                raise ValidationError(
                    "Evento Eventbrite associato a un’altra edizione durante la conferma."
                )
            if batch.payload[0].get("kind") == "registration":
                RegistrationRevision.objects.bulk_create(
                    [
                        RegistrationRevision(
                            batch=batch,
                            ticketing_event=link,
                            external_id=r["registration_id"],
                            status=r["status"],
                            guests=r["guests"],
                        )
                        for r in batch.payload
                    ]
                )
            else:
                OrderRevision.objects.bulk_create(
                    [
                        OrderRevision(
                            batch=batch,
                            ticketing_event=link,
                            external_id=r["order_id"],
                            status=r["status"],
                            ticket_count=r["quantity"],
                            gross_revenue=r["gross"],
                            fees=r["fees"],
                            refunds=r["refunds"],
                            currency=r["currency"],
                        )
                        for r in batch.payload
                    ]
                )
    batch.status = "confirmed"
    batch.confirmed_at = timezone.now()
    batch.save(update_fields=["status", "confirmed_at", "updated_at"])
    AuditEntry.objects.create(
        actor=user,
        event=batch.event,
        action="import.confirmed",
        details={"batch": str(batch.pk)},
    )
    from .business import automatic_report

    automatic_report(batch.event)
    return True


@transaction.atomic
def revert(batch, user):
    Event.objects.select_for_update().get(pk=batch.event_id)
    batch = ImportBatch.objects.select_for_update().get(pk=batch.pk)
    if batch.status != "confirmed":
        raise ValidationError(
            "Solo le importazioni confermate possono essere annullate."
        )
    batch.status = "reverted"
    batch.save(update_fields=["status", "updated_at"])
    AuditEntry.objects.create(
        actor=user,
        event=batch.event,
        action="import.reverted",
        details={"batch": str(batch.pk)},
    )
    from .business import automatic_report

    automatic_report(batch.event)
