"""Read-only reconciliation from originals. Reference numbers are not forced expectations."""

import json
import os
from decimal import Decimal
from pathlib import Path
from django.core.exceptions import ValidationError
from django.core.files import File
from django.core.management.base import BaseCommand, CommandError
from core.services.imports import parse, PARSER_VERSION


class Command(BaseCommand):
    help = "Verifica i due originali Halloween senza modificare il database."

    def add_arguments(self, parser):
        parser.add_argument("--meta", required=True)
        parser.add_argument("--orders", required=True)
        parser.add_argument("--output", required=True)

    def handle(self, *args, **options):
        paths = [Path(options["meta"]), Path(options["orders"])]
        if any(not p.is_file() for p in paths):
            raise CommandError(
                "Originali mancanti: nessuna validazione reale eseguita."
            )
        parsed = []
        for path, expected in zip(paths, ("meta", "eventbrite")):
            try:
                with path.open("rb") as source:
                    kind, digest, rows = parse(File(source, name=path.name))
                if kind != expected:
                    raise CommandError(
                        "Fonte diversa da quella attesa; nessun risultato dichiarato valido."
                    )
                parsed.append((digest, rows))
            except ValidationError as exc:
                raise CommandError(
                    "Schema originale non ancora compatibile: " + " ".join(exc.messages)
                ) from None
        meta, orders = parsed[0][1], parsed[1][1]

        def complete(rows, key):
            values = [r[key] for r in rows]
            return (
                sum((Decimal(str(v)) for v in values), Decimal(0))
                if values and all(v is not None for v in values)
                else None
            )

        completed = [r for r in orders if r["status"] == "completed"]
        result = {
            "source_parsing_verified": True,
            "parser_version": PARSER_VERSION,
            "sources": [
                {"filename": p.name, "sha256": data[0], "rows": len(data[1])}
                for p, data in zip(paths, parsed)
            ],
            "observed": {
                "spend": complete(meta, "spend"),
                "link_clicks": complete(meta, "clicks"),
                "completed_orders": len(completed),
                "tickets": sum(r["quantity"] for r in completed),
                "gross_completed": complete(completed, "gross"),
                "attributed_purchases": complete(meta, "purchases")
                if len({r["attribution"] for r in meta}) == 1
                and bool(meta[0]["attribution"])
                else None,
            },
            "reference_not_verified": {
                "spend": "299.84",
                "link_clicks": 4558,
                "completed_orders": 52,
                "tickets": 64,
                "gross_completed": "1280.00",
                "attributed_purchases": 5,
            },
            "attribution_note": "Acquisti Meta distinti dagli ordini. Confrontare inoltre finestra e semantica ricavi/commissioni nelle fonti; nessuna verifica causale automatica.",
        }
        result["reference_differences"] = [
            key
            for key, value in result["observed"].items()
            if value is None
            or Decimal(str(value))
            != Decimal(str(result["reference_not_verified"][key]))
        ]
        target = Path(options["output"])
        if target.resolve() in {p.resolve() for p in paths}:
            raise CommandError("Il report non può sovrascrivere gli originali.")
        target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        try:
            fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        except FileExistsError:
            raise CommandError(
                "Report già esistente: usare un nuovo percorso, nessun file sovrascritto."
            ) from None
        with os.fdopen(fd, "w") as file:
            json.dump(result, file, default=str, ensure_ascii=False, indent=2)
        self.stdout.write(
            "Parsing completato, evidenze private salvate. Eventuali differenze richiedono riconciliazione: non sono state corrette artificialmente."
        )
