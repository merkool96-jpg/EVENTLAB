from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.urls import reverse
from django.views.generic import ListView, DetailView, CreateView
from .forms import EventForm
from .models import Event, AuditEntry
from django.db import transaction


class EventList(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    permission_required = "core.view_event"
    model = Event
    template_name = "core/event_list.html"

    def get_queryset(self):
        return Event.objects.select_related("brand", "format")


class EventDetail(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    permission_required = "core.view_event"
    model = Event
    template_name = "core/event_detail.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update(dashboard(self.object))
        context["imports"] = self.object.imports.order_by("-created_at")
        return context


class EventCreate(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    permission_required = "core.add_event"
    model = Event
    form_class = EventForm
    template_name = "core/event_form.html"

    @transaction.atomic
    def form_valid(self, form):
        response = super().form_valid(form)
        AuditEntry.objects.create(
            actor=self.request.user, event=self.object, action="event.created"
        )
        return response

    def get_success_url(self):
        return reverse("event-detail", args=[self.object.pk])


from django.contrib import messages
from django.core.exceptions import ValidationError
from django.http import HttpResponseRedirect
from django.shortcuts import get_object_or_404, render
from django.views import View
from .forms import ImportForm
from .models import ImportBatch
from .services.imports import stage, confirm, revert
from .services.kpis import dashboard


class ImportUpload(LoginRequiredMixin, PermissionRequiredMixin, View):
    permission_required = ("core.add_importbatch", "core.view_event")

    def get(self, request, pk):
        event = get_object_or_404(Event, pk=pk)
        return render(
            request,
            "core/import_upload.html",
            {"event": event, "form": ImportForm(event=event)},
        )

    def post(self, request, pk):
        event = get_object_or_404(Event, pk=pk)
        form = ImportForm(request.POST, request.FILES, event=event)
        if form.is_valid():
            try:
                with transaction.atomic():
                    staged = [
                        stage(
                            event,
                            upload,
                            request.user,
                            replaces=form.cleaned_data.get("replaces"),
                        )
                        for upload in form.cleaned_data["file"]
                    ]
                if any(not created for _, created in staged):
                    messages.info(
                        request,
                        "File già caricati riconosciuti: nessun dato duplicato.",
                    )
                if len(staged) == 1:
                    return HttpResponseRedirect(
                        reverse("import-detail", args=[staged[0][0].pk])
                    )
                messages.info(
                    request,
                    "File analizzati. Apri le anteprime nello storico e conferma ciascuna importazione. I conflitti vengono ricontrollati alla conferma.",
                )
                return HttpResponseRedirect(reverse("event-detail", args=[event.pk]))
            except ValidationError as exc:
                form.add_error(None, exc)
        return render(
            request, "core/import_upload.html", {"event": event, "form": form}
        )


class ImportDetail(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    permission_required = ("core.view_importbatch", "core.view_event")
    model = ImportBatch
    template_name = "core/import_detail.html"


class ImportAction(LoginRequiredMixin, PermissionRequiredMixin, View):
    permission_required = ("core.change_importbatch", "core.view_event")

    def post(self, request, pk, action):
        batch = get_object_or_404(ImportBatch, pk=pk)
        try:
            if action == "confirm":
                confirm(batch, request.user)
                messages.success(request, "Importazione confermata. Dati aggiornati.")
            elif action == "revert":
                revert(batch, request.user)
                messages.success(
                    request,
                    "Importazione annullata. Storico conservato e KPI aggiornati.",
                )
            else:
                from django.http import Http404

                raise Http404
        except ValidationError as exc:
            messages.error(request, " ".join(exc.messages))
        return HttpResponseRedirect(reverse("import-detail", args=[batch.pk]))
