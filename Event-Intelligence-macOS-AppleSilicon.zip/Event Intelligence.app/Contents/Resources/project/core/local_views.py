"""Desktop-only controls. Every route is absent unless the local profile is used."""

from django.conf import settings
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model
from django.http import Http404, JsonResponse, HttpResponseRedirect
from django.shortcuts import render
from django.views.decorators.csrf import ensure_csrf_cookie
from django.views.decorators.http import require_POST
from django.urls import reverse
from . import local_runtime as runtime
from .services.ollama import MODELS, readiness
from .services.generative_ai import configuration


def local_only():
    if not getattr(settings, "EVENT_LOCAL_MODE", False):
        raise Http404


@ensure_csrf_cookie
def launch(request):
    local_only()
    return render(request, "local/launch.html")


@require_POST
def unlock(request):
    local_only()
    if not runtime.consume_token(request.headers.get("X-Local-Launch-Token")):
        return JsonResponse(
            {"error": "Apri Event Intelligence dall’app sul Mac."}, status=403
        )
    user = (
        get_user_model()
        .objects.filter(
            username="proprietario_locale", is_superuser=True, is_active=True
        )
        .first()
    )
    if user is None:
        return JsonResponse({"error": "Account locale non inizializzato."}, status=503)
    login(request, user, backend="django.contrib.auth.backends.ModelBackend")
    return JsonResponse({"next": reverse("overview")})


@login_required
def settings_page(request):
    local_only()
    if not request.user.is_superuser:
        raise Http404
    if request.method == "POST":
        action = request.POST.get("action")
        if action == "model":
            if request.POST.get("model") not in MODELS:
                return JsonResponse({"error": "Modello non ammesso"}, status=400)
            runtime.select_model(request.POST.get("model"))
            runtime.private_json(
                settings.LOCAL_DATA_DIR / "model-request.json",
                {"model": runtime.preferences()["model"]},
            )
        elif action == "backup":
            runtime.backup_database(force=True)
        elif action == "stop":
            runtime.private_json(
                settings.LOCAL_DATA_DIR / "stop-request.json", {"stop": True}
            )
        else:
            return JsonResponse({"error": "Azione non ammessa"}, status=400)
        return HttpResponseRedirect(reverse("local-settings"))
    return render(
        request,
        "local/settings.html",
        {
            "models": MODELS,
            "selected": runtime.preferences()["model"],
            "status": runtime.model_status(),
            "ready_error": readiness(configuration()),
            "backups": sorted(
                (settings.LOCAL_DATA_DIR / "backups").glob("*.sqlite3"), reverse=True
            )[:10],
        },
    )
