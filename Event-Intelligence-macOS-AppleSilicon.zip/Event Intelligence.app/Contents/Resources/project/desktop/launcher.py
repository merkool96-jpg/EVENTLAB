#!/usr/bin/env python3
"""Desktop controller: shared Django app, native SQLite and one AI subprocess."""

import contextlib
import fcntl
import logging
import os
from pathlib import Path
import secrets
import signal
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser

PORT = int(os.environ.get("EVENTLAB_LOCAL_PORT", "8000"))
if not 1024 <= PORT <= 65535:
    raise RuntimeError("Porta locale non valida.")
PROJECT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT))


def data_directory():
    override = os.environ.get("EVENTLAB_DATA_DIR")
    if override:
        return Path(override).expanduser().resolve()
    if sys.platform != "darwin":
        raise RuntimeError(
            "Impostare una directory dati esplicita per il collaudo Linux."
        )
    return Path.home() / "Library" / "Application Support" / "Event Intelligence"


def configure():
    root = data_directory()
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    root.chmod(0o700)
    for folder in ("logs", "private", "backups"):
        (root / folder).mkdir(mode=0o700, exist_ok=True)
    secret = root / "django-secret"
    setup_lock = os.open(root / "configuration.lock", os.O_CREAT | os.O_RDWR, 0o600)
    try:
        fcntl.flock(setup_lock, fcntl.LOCK_EX)
        if not secret.exists():
            fd = os.open(secret, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            with os.fdopen(fd, "w") as f:
                f.write(secrets.token_hex(48))
    finally:
        fcntl.flock(setup_lock, fcntl.LOCK_UN)
        os.close(setup_lock)
    os.environ["EVENTLAB_DATA_DIR"] = str(root)
    for name in (
        "EVENT_AI_API_KEY_FILE",
        "EVENT_AI_API_KEY",
        "PGPASSWORD_FILE",
        "DJANGO_PREVIEW_ORIGIN",
        "DJANGO_TRUST_PROXY",
    ):
        os.environ.pop(name, None)
    os.environ["DJANGO_SETTINGS_MODULE"] = "config.local_settings"
    os.environ.pop("DJANGO_SECRET_KEY", None)
    os.environ["DJANGO_SECRET_KEY_FILE"] = str(secret)
    import django

    django.setup()
    return root


def log_setup(root):
    from logging.handlers import RotatingFileHandler

    handler = RotatingFileHandler(
        root / "logs" / "desktop.log", maxBytes=2_000_000, backupCount=3
    )
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    logging.basicConfig(level=logging.INFO, handlers=[handler])
    # No HTTP access logs or launch tokens in logs.
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("axes").setLevel(logging.WARNING)


def error_dialog():
    if sys.platform == "darwin":
        subprocess.run(
            [
                "/usr/bin/osascript",
                "-e",
                'display dialog "Event Intelligence non si è avviato. Controlla che la porta 8000 sia libera e consulta desktop.log nella cartella dati." buttons {"OK"} default button "OK" with icon caution',
            ],
            check=False,
        )


def healthy():
    try:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(f"http://127.0.0.1:{PORT}/health/", timeout=1) as r:
            return r.status == 200
    except Exception:
        return False


def open_application():
    from core.local_runtime import new_launch_token

    webbrowser.open(f"http://127.0.0.1:{PORT}/local/launch/#" + new_launch_token())


def find_ollama():
    choices = [
        "/Applications/Ollama.app/Contents/Resources/ollama",
        "/opt/homebrew/bin/ollama",
        "/usr/local/bin/ollama",
        shutil.which("ollama"),
    ]
    return next(
        (p for p in choices if p and Path(p).is_file() and os.access(p, os.X_OK)), None
    )


def start_ollama(root):
    import httpx

    try:
        with httpx.Client(timeout=2, trust_env=False) as client:
            if client.get("http://127.0.0.1:11434/api/version").status_code == 200:
                return None
    except httpx.HTTPError:
        pass
    binary = find_ollama()
    if not binary:
        return None
    env = os.environ.copy()
    env.update(
        OLLAMA_HOST="127.0.0.1:11434",
        OLLAMA_NUM_PARALLEL="1",
        OLLAMA_MAX_LOADED_MODELS="1",
        OLLAMA_MAX_QUEUE="1",
        OLLAMA_CONTEXT_LENGTH="2048",
        OLLAMA_KEEP_ALIVE="0",
        OLLAMA_NO_CLOUD="1",
        OLLAMA_DEBUG="0",
    )
    stream = open(root / "logs" / "ollama.log", "a")
    process = subprocess.Popen(
        [binary, "serve"], env=env, stdout=stream, stderr=subprocess.STDOUT
    )
    stream.close()
    return process


def supervise(root, server, worker, own_ollama, stop):
    from core.local_runtime import (
        backup_database,
        preferences,
        prepare_model,
        model_status,
        private_json,
    )
    from core.services.ollama import readiness
    from core.services.generative_ai import configuration

    pulling = None
    last_backup = 0
    worker_failed = False
    while not stop.wait(3):
        if (root / "stop-request.json").exists():
            (root / "stop-request.json").unlink()
            stop.set()
            server.close()
            return
        if time.monotonic() - last_backup > 3600:
            try:
                backup_database()
                last_backup = time.monotonic()
            except Exception:
                logging.error("Backup automatico locale non riuscito.")
        if worker.poll() is not None and not worker_failed:
            worker_failed = True
            private_json(
                root / "model-status.json",
                {
                    "state": "error",
                    "message": "Worker locale arrestato: arresta i servizi dalle impostazioni e riapri l’app. I dati e l’analisi a regole restano disponibili.",
                },
            )
            logging.error(
                "Worker AI arrestato. Il report a regole resta disponibile; riapri l’app."
            )

        if worker_failed:
            continue
        request = root / "model-request.json"

        if pulling is None or not pulling.is_alive():
            ready = readiness(configuration())
            if not ready:
                if model_status().get("state") != "ready":
                    private_json(
                        root / "model-status.json",
                        {"state": "ready", "message": "Ollama locale pronto."},
                    )
                from django.db import close_old_connections
                from core.models import Event
                from core.services.generative_ai import enqueue

                if getattr(supervise, "last_model", None) != preferences()["model"]:
                    close_old_connections()
                    for event in Event.objects.filter(
                        imports__status="confirmed"
                    ).distinct():
                        enqueue(event)
                    close_old_connections()
                    supervise.last_model = preferences()["model"]
            elif ready == "local_unavailable" and model_status().get("state") not in (
                "error",
                "downloading",
            ):
                private_json(
                    root / "model-status.json",
                    {
                        "state": "unavailable",
                        "message": "Installa e apri Ollama dal sito ufficiale. L’analisi a regole resta utilizzabile.",
                    },
                )
            if request.exists():
                request.unlink()
                pulling = threading.Thread(
                    target=prepare_model, args=(preferences()["model"],), daemon=True
                )
                pulling.start()
            elif pulling is None and ready == "local_model_missing":
                pulling = threading.Thread(
                    target=prepare_model, args=(preferences()["model"],), daemon=True
                )
                pulling.start()


def run():
    root = configure()
    log_setup(root)
    if "--ai-worker" in sys.argv:
        from django.core.management import call_command

        call_command("ai_worker")
        return
    lock = os.open(root / "application.lock", os.O_CREAT | os.O_RDWR, 0o600)
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        for _ in range(30):
            if healthy():
                if "--no-browser" not in sys.argv:
                    open_application()
                os.close(lock)
                return
            time.sleep(1)
        raise RuntimeError("Avvio già in corso.")
    # Refuse an occupied port, never kill an unrelated application.
    with socket.socket() as probe:
        if probe.connect_ex(("127.0.0.1", PORT)) == 0:
            raise RuntimeError("Porta occupata.")
    from django.core.management import call_command
    from django.contrib.auth import get_user_model
    from core.local_runtime import backup_database
    from django.core.wsgi import get_wsgi_application
    from waitress import create_server

    db = root / "event-intelligence.sqlite3"
    needs_migration = True
    if db.exists():
        from django.db.migrations.executor import MigrationExecutor
        from django.db import connection

        executor = MigrationExecutor(connection)
        needs_migration = bool(
            executor.migration_plan(executor.loader.graph.leaf_nodes())
        )
        if needs_migration:
            backup_database(force=True)
    call_command("migrate", interactive=False, verbosity=0)
    db.chmod(0o600)
    from django.db import connection

    with connection.cursor() as cursor:
        cursor.execute("PRAGMA journal_mode=WAL")
    call_command("setup_roles", verbosity=0)
    call_command("collectstatic", interactive=False, verbosity=0)
    user, created = get_user_model().objects.get_or_create(
        username="proprietario_locale",
        defaults={"is_superuser": True, "is_staff": True},
    )
    if created:
        user.set_unusable_password()
        user.save()
    if not user.is_superuser or not user.is_active:
        raise RuntimeError("Account locale non valido.")
    backup_database(force=needs_migration or created)
    with contextlib.suppress(FileNotFoundError):
        (root / "stop-request.json").unlink()
    own_ollama = None
    worker = None
    server = None
    stop = threading.Event()
    signal.signal(signal.SIGTERM, lambda *_: stop.set())
    try:
        own_ollama = start_ollama(root)
        stream = open(root / "logs" / "worker.log", "a")
        worker = subprocess.Popen(
            [sys.executable, str(Path(__file__).resolve()), "--ai-worker"],
            cwd=PROJECT,
            stdout=stream,
            stderr=subprocess.STDOUT,
        )
        stream.close()
        server = create_server(
            get_wsgi_application(),
            host="127.0.0.1",
            port=PORT,
            threads=4,
            clear_untrusted_proxy_headers=True,
        )
        thread = threading.Thread(
            target=supervise, args=(root, server, worker, own_ollama, stop), daemon=True
        )
        thread.start()
        if "--no-browser" not in sys.argv:
            open_application()
        web_thread = threading.Thread(target=server.run, daemon=True)
        web_thread.start()
        while not stop.wait(1):
            if not web_thread.is_alive():
                raise RuntimeError("Server locale arrestato.")
    finally:
        stop.set()
        if server is not None:
            server.close()
            server.task_dispatcher.shutdown()
        for process in (worker, own_ollama):
            if process and process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
        os.close(lock)


if __name__ == "__main__":
    try:
        run()
    except KeyboardInterrupt:
        pass
    except Exception:
        logging.exception("Errore di avvio locale; nessun dato cancellato.")
        error_dialog()
        raise SystemExit(1)
