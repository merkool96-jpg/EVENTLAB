#!/bin/bash
set -euo pipefail
umask 077
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_PATH="$BASE_DIR/Event Intelligence.app"
if [ ! -d "$APP_PATH" ]; then APP_PATH="/Applications/Event Intelligence.app"; fi
DATA_DIR="$HOME/Library/Application Support/Event Intelligence"
PYTHON_BIN=""
for candidate in /Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12 /opt/homebrew/bin/python3.12 /usr/local/bin/python3.12; do
  if [ -x "$candidate" ]; then PYTHON_BIN="$candidate"; break; fi
done
if [ -z "$PYTHON_BIN" ] || [ ! -f "$APP_PATH/Contents/Resources/project/desktop/persistence.py" ]; then
  /usr/bin/osascript -e 'display dialog "Servono Python 3.12 e la nuova Event Intelligence.app accanto a questo file o in Applicazioni." buttons {"OK"}'
  exit 1
fi
BACKUP_DIR=$(/usr/bin/osascript - "$DATA_DIR/backups/updates" <<'APPLESCRIPT'
on run argv
  display dialog "Arresta prima i servizi locali. Il ripristino recupera i dati del backup scelto. Lo stato attuale verrà conservato in una cartella before-restore, senza cancellarlo." buttons {"Annulla", "Scegli backup"} default button "Annulla"
  set chosenFolder to choose folder with prompt "Scegli la cartella del backup completo (contiene manifest.json)" default location (POSIX file (item 1 of argv))
  return POSIX path of chosenFolder
end run
APPLESCRIPT
)
if "$PYTHON_BIN" "$APP_PATH/Contents/Resources/project/desktop/persistence.py" restore "$DATA_DIR" "$BACKUP_DIR"; then
  /usr/bin/osascript -e 'display dialog "Ripristino completato. Riapri Event Intelligence. I dati precedenti al ripristino sono conservati in backups/before-restore." buttons {"OK"}'
else
  /usr/bin/osascript -e 'display dialog "Ripristino interrotto. Non avviare l’app finché non è completato. Consulta il messaggio in questa finestra; i dati precedenti sono conservati." buttons {"OK"}'
  exit 1
fi
