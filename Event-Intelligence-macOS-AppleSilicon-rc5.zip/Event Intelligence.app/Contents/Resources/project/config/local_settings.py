"""Single-user desktop profile; never expose this server on the network."""

from .settings import *  # noqa: F403
from pathlib import Path
import os

EVENT_LOCAL_MODE = True
LOCAL_DATA_DIR = Path(os.environ["EVENTLAB_DATA_DIR"]).expanduser().resolve()
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": LOCAL_DATA_DIR / "event-intelligence.sqlite3",
        "OPTIONS": {"timeout": 30, "transaction_mode": "IMMEDIATE"},
        "TEST": {
            "NAME": os.environ.get(
                "EVENTLAB_TEST_SQLITE", str(LOCAL_DATA_DIR / "test-only.sqlite3")
            )
        },
    }
}
DEBUG = False
ALLOWED_HOSTS = ["127.0.0.1", "localhost"]
CSRF_TRUSTED_ORIGINS = [
    "http://127.0.0.1:" + os.environ.get("EVENTLAB_LOCAL_PORT", "8000")
]
SECURE_SSL_REDIRECT = False
SECURE_HSTS_SECONDS = 0
SECURE_HSTS_PRELOAD = False
SECURE_HSTS_INCLUDE_SUBDOMAINS = False
SECURE_PROXY_SSL_HEADER = None
SESSION_COOKIE_SECURE = False
CSRF_COOKIE_SECURE = False
SESSION_COOKIE_NAME = "eventlab_local_session"
CSRF_COOKIE_NAME = "eventlab_local_csrf"
STATIC_ROOT = LOCAL_DATA_DIR / "static"
MEDIA_ROOT = LOCAL_DATA_DIR / "private"
EVENT_AI_PROVIDER = "ollama"
EVENT_AI_ENABLED = True
EVENT_AI_ALLOW_REQUESTS = False
EVENT_AI_API_KEY = ""
EVENT_AI_ENDPOINT = "http://127.0.0.1:11434/api/chat"
EVENT_AI_MODEL = "qwen3:1.7b"
EVENT_AI_TIMEOUT = 180
EVENT_AI_MAX_OUTPUT_TOKENS = 768
EVENT_AI_DAILY_REQUEST_LIMIT = 100
