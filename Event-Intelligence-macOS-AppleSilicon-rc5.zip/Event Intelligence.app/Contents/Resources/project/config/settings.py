"""Single-organization settings. PostgreSQL is required in every environment."""

import os
from datetime import timedelta
from urllib.parse import urlsplit
from pathlib import Path
from django.core.exceptions import ImproperlyConfigured

BASE_DIR = Path(__file__).resolve().parent.parent


def secret(name, default=""):
    value = os.environ.get(name)
    filename = os.environ.get(name + "_FILE")
    if value and filename:
        raise ImproperlyConfigured(
            f"Configurare {name} oppure {name}_FILE, non entrambi."
        )
    if filename:
        try:
            with open(filename, encoding="utf-8") as file:
                value = file.read(16385).strip()
        except OSError:
            raise ImproperlyConfigured(
                f"File segreto {name} non disponibile."
            ) from None
        if len(value) > 16384:
            raise ImproperlyConfigured(f"File segreto {name} troppo grande.")
    return value or default


SECRET_KEY = secret("DJANGO_SECRET_KEY")
if not SECRET_KEY:
    raise ImproperlyConfigured("Impostare DJANGO_SECRET_KEY; vedere README.md.")
DEBUG = os.environ.get("DJANGO_DEBUG", "0") == "1"
ALLOWED_HOSTS = os.environ.get("DJANGO_ALLOWED_HOSTS", "localhost,127.0.0.1").split(",")
CSRF_TRUSTED_ORIGINS = []
# Exact optional preview origin; never allow every host or disable CSRF.
PREVIEW_ORIGIN = os.environ.get("DJANGO_PREVIEW_ORIGIN", "").rstrip("/")
if PREVIEW_ORIGIN:
    preview = urlsplit(PREVIEW_ORIGIN)
    if (
        preview.scheme not in ("http", "https")
        or not preview.hostname
        or preview.username
        or preview.password
        or preview.path
        or preview.query
        or preview.fragment
        or "*" in preview.netloc
    ):
        raise ImproperlyConfigured(
            "DJANGO_PREVIEW_ORIGIN deve essere una origine HTTP(S) esatta, senza percorso."
        )
    ALLOWED_HOSTS.append(preview.hostname)
    CSRF_TRUSTED_ORIGINS.append(PREVIEW_ORIGIN)
INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "core",
    "axes",
]
MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "axes.middleware.AxesMiddleware",
]
ROOT_URLCONF = "config.urls"
TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ]
        },
    }
]
WSGI_APPLICATION = "config.wsgi.application"
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": os.environ.get("PGDATABASE", "event_intelligence"),
        "USER": os.environ.get("PGUSER", "event_intelligence"),
        "PASSWORD": secret("PGPASSWORD"),
        "HOST": os.environ.get("PGHOST", "127.0.0.1"),
        "PORT": os.environ.get("PGPORT", "55432"),
        "CONN_MAX_AGE": 0,
        "OPTIONS": {
            "sslmode": os.environ.get("PGSSLMODE", "prefer"),
            **(
                {"sslrootcert": os.environ["PGSSLROOTCERT"]}
                if os.environ.get("PGSSLROOTCERT")
                else {}
            ),
        },
    }
}
AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation." + name}
    for name in (
        "UserAttributeSimilarityValidator",
        "MinimumLengthValidator",
        "CommonPasswordValidator",
        "NumericPasswordValidator",
    )
]
LANGUAGE_CODE = "it-it"
TIME_ZONE = "Europe/Rome"
USE_I18N = True
USE_TZ = True
STATIC_URL = "static/"
STATIC_ROOT = BASE_DIR / ".local" / "static"
MEDIA_ROOT = BASE_DIR / ".local" / "private"
FILE_UPLOAD_PERMISSIONS = 0o600
DATA_UPLOAD_MAX_NUMBER_FILES = 10
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
LOGIN_URL = "login"
LOGIN_REDIRECT_URL = "overview"
LOGOUT_REDIRECT_URL = "login"
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SECURE = not DEBUG
CSRF_COOKIE_SECURE = not DEBUG
SECURE_CONTENT_TYPE_NOSNIFF = True
X_FRAME_OPTIONS = "DENY"
if not DEBUG:
    SECURE_SSL_REDIRECT = True
    SECURE_HSTS_SECONDS = 31536000
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SECURE_HSTS_PRELOAD = True

# Enable only behind a reverse proxy you control, which overwrites this header.
if os.environ.get("DJANGO_TRUST_PROXY") == "1":
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")


# Both switches must be explicitly enabled after authorization of provider usage/costs.
EVENT_AI_ENABLED = os.environ.get("EVENT_AI_ENABLED", "0") == "1"
EVENT_AI_ALLOW_REQUESTS = os.environ.get("EVENT_AI_ALLOW_REQUESTS", "0") == "1"
EVENT_AI_API_KEY = secret("EVENT_AI_API_KEY")
EVENT_AI_ENDPOINT = os.environ.get("EVENT_AI_ENDPOINT", "")
EVENT_AI_MODEL = os.environ.get("EVENT_AI_MODEL", "")
EVENT_AI_TIMEOUT = 30
EVENT_AI_MAX_OUTPUT_TOKENS = 2500
EVENT_AI_DAILY_REQUEST_LIMIT = int(os.environ.get("EVENT_AI_DAILY_REQUEST_LIMIT", "5"))
EVENT_AI_MAX_ATTEMPTS = 2

AUTHENTICATION_BACKENDS = [
    "axes.backends.AxesStandaloneBackend",
    "django.contrib.auth.backends.ModelBackend",
]
AXES_FAILURE_LIMIT = 8
AXES_COOLOFF_TIME = timedelta(minutes=15)
AXES_RESET_ON_SUCCESS = True
AXES_LOCKOUT_PARAMETERS = [["username", "ip_address"]]
AXES_LOCKOUT_TEMPLATE = "registration/locked.html"

SECURE_REDIRECT_EXEMPT = [r"^health/$"]

EVENT_AI_PROVIDER = os.environ.get("EVENT_AI_PROVIDER", "openai_compatible")
EVENT_AI_OLLAMA_CONTEXT = 2048
EVENT_AI_OLLAMA_PREDICT = 768
