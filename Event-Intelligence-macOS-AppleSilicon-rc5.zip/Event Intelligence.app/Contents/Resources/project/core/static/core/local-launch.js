(async()=>{
 const token=location.hash.slice(1);history.replaceState(null,'',location.pathname);
 const status=document.getElementById('local-status');
 if(!token){status.textContent='Apri Event Intelligence con doppio clic sull’app del Mac.';return;}
 try{
  const response=await fetch('/local/unlock/',{method:'POST',credentials:'same-origin',headers:{'X-Local-Launch-Token':token,'X-CSRFToken':document.querySelector('#local-launch input').value}});
  if(!response.ok)throw Error();const result=await response.json();location.replace(result.next);
 }catch{status.textContent='Accesso locale scaduto. Riapri Event Intelligence con doppio clic.';}
})();
