from django.core.management.base import BaseCommand
from django.contrib.auth.models import Group, Permission


class Command(BaseCommand):
    help = "Crea/aggiorna ruoli senza creare utenti o password."

    def handle(self, *args, **kwargs):
        viewer, _ = Group.objects.get_or_create(name="Lettura")
        editor, _ = Group.objects.get_or_create(name="Gestione")
        viewer.permissions.set(
            Permission.objects.filter(
                content_type__app_label="core", codename__startswith="view_"
            )
        )
        editor.permissions.set(
            Permission.objects.filter(content_type__app_label="core").exclude(
                codename__startswith="delete_"
            )
        )
        self.stdout.write("Ruoli Lettura e Gestione aggiornati. Nessun utente creato.")
