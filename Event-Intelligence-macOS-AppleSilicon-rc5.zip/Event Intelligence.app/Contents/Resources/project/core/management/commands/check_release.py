from django.conf import settings
from django.core.management.base import BaseCommand, CommandError
from django.db import connection
from core.services.generative_ai import configuration


class Command(BaseCommand):
    help = "Verifica prerequisiti di rilascio senza chiamare API o pubblicare."

    def add_arguments(self, parser):
        parser.add_argument("--require-ai", action="store_true")

    def handle(self, *args, **options):
        if settings.DEBUG:
            raise CommandError("DEBUG deve essere disattivato.")
        if not settings.ALLOWED_HOSTS or "*" in settings.ALLOWED_HOSTS:
            raise CommandError("Configurare host esatti, senza wildcard.")
        if not settings.SESSION_COOKIE_SECURE or not settings.CSRF_COOKIE_SECURE:
            raise CommandError("Cookie Secure obbligatori.")
        db = settings.DATABASES["default"]
        host = db.get("HOST", "")
        if (
            host not in ("db", "localhost", "127.0.0.1", "")
            and not host.startswith("/")
            and db.get("OPTIONS", {}).get("sslmode") != "verify-full"
        ):
            raise CommandError(
                "Database remoto: richiedere sslmode=verify-full e CA attendibile."
            )
        with connection.cursor() as cursor:
            cursor.execute(
                "SELECT rolsuper,rolcreatedb,rolcreaterole FROM pg_roles WHERE rolname=current_user"
            )
            role = cursor.fetchone()
        if role is None or any(role):
            raise CommandError(
                "Il ruolo applicativo non deve essere superuser né poter creare database/ruoli."
            )
        if options["require_ai"] and configuration()["reason"]:
            raise CommandError(
                "AI generativa non pronta: configurazione o autorizzazione mancanti. Nessuna richiesta eseguita."
            )
        self.stdout.write(
            "Prerequisiti verificati. Non sostituisce collaudo HTTPS pubblico, prova del provider e backup offsite."
        )
