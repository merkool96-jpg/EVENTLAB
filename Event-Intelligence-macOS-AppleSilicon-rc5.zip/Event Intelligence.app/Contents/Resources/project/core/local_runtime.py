"""Private desktop state, SQLite online backups and local Ollama preparation."""

import contextlib
import hashlib
import json
import os
from pathlib import Path
import secrets
import sqlite3
import tempfile
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from django.conf import settings
import httpx
from .services.ollama import MODELS


def private_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, temp = tempfile.mkstemp(dir=path.parent, prefix=".eventlab-")
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w") as file:
            json.dump(data, file, ensure_ascii=False)
        os.replace(temp, path)
    finally:
        with contextlib.suppress(FileNotFoundError):
            os.unlink(temp)


def preferences():
    try:
        data = json.loads((settings.LOCAL_DATA_DIR / "preferences.json").read_text())
        model = data.get("model")
    except (OSError, ValueError, AttributeError):
        model = None
    return {"model": model if model in MODELS else MODELS[0]}


def select_model(model):
    if model not in MODELS:
        raise ValueError("Modello non ammesso.")
    private_json(settings.LOCAL_DATA_DIR / "preferences.json", {"model": model})


@contextlib.contextmanager
def launch_lock():
    import fcntl

    path = settings.LOCAL_DATA_DIR / "token.lock"
    fd = os.open(path, os.O_CREAT | os.O_RDWR, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        yield
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def new_launch_token():
    token = secrets.token_urlsafe(32)
    with launch_lock():
        private_json(
            settings.LOCAL_DATA_DIR / "launch-token.json",
            {"sha256": hashlib.sha256(token.encode()).hexdigest()},
        )
    return token


def consume_token(token):
    if not isinstance(token, str) or len(token) > 200:
        return False
    with launch_lock():
        path = settings.LOCAL_DATA_DIR / "launch-token.json"
        try:
            stored = json.loads(path.read_text()).get("sha256", "")
        except (OSError, ValueError, AttributeError):
            return False
        if not secrets.compare_digest(
            stored, hashlib.sha256(token.encode()).hexdigest()
        ):
            return False
        path.unlink()
        return True


def backup_database(force=False):
    data = settings.LOCAL_DATA_DIR
    if not Path(settings.DATABASES["default"]["NAME"]).is_file():
        raise RuntimeError(
            "Database locale non disponibile; nessun backup vuoto creato."
        )
    target = data / "backups"
    target.mkdir(mode=0o700, parents=True, exist_ok=True)
    previous = sorted(
        target.glob("eventlab-*.sqlite3"), key=lambda p: p.stat().st_mtime
    )
    now = datetime.now(ZoneInfo("Europe/Rome"))
    if (
        not force
        and previous
        and datetime.fromtimestamp(
            previous[-1].stat().st_mtime, ZoneInfo("Europe/Rome")
        )
        > now - timedelta(hours=24)
    ):
        return previous[-1]
    name = (
        "eventlab-"
        + now.strftime("%Y%m%dT%H%M%S")
        + "-"
        + secrets.token_hex(3)
        + ".sqlite3"
    )
    path = target / name
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    os.close(fd)
    try:
        with (
            sqlite3.connect(
                settings.DATABASES["default"]["NAME"], timeout=30
            ) as source,
            sqlite3.connect(path) as dest,
        ):
            source.backup(dest)
            if dest.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise RuntimeError("Backup non valido.")
        checksum = hashlib.sha256(path.read_bytes()).hexdigest()
        fd = os.open(str(path) + ".sha256", os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(checksum + "  " + name + "\n")
    except Exception:
        with contextlib.suppress(OSError):
            path.unlink()
        raise
    return path


def prepare_model(model):
    if model not in MODELS:
        raise ValueError("Modello non ammesso.")
    status_path = settings.LOCAL_DATA_DIR / "model-status.json"
    private_json(
        status_path,
        {
            "state": "downloading",
            "message": "Preparazione gratuita del modello locale in corso. Le dashboard restano disponibili.",
        },
    )
    try:
        with httpx.Client(
            timeout=httpx.Timeout(1800, connect=3),
            trust_env=False,
            follow_redirects=False,
        ) as client:
            with client.stream(
                "POST",
                "http://127.0.0.1:11434/api/pull",
                json={"model": model, "stream": True},
            ) as response:
                if response.status_code != 200:
                    raise RuntimeError
                for line in response.iter_lines():
                    if len(line) > 16384:
                        raise RuntimeError
                    if line:
                        row = json.loads(line)
                        if row.get("error"):
                            raise RuntimeError
            tags = client.get("http://127.0.0.1:11434/api/tags").json()
            if model not in {m.get("name") for m in tags.get("models", [])}:
                raise RuntimeError
        private_json(
            status_path, {"state": "ready", "message": "Modello locale disponibile."}
        )
    except Exception:
        private_json(
            status_path,
            {
                "state": "error",
                "message": "Ollama o modello non disponibile. Verifica Ollama e la connessione per il primo download. Rimane attiva l’analisi a regole; il tag opzionale potrebbe non esistere nel catalogo.",
            },
        )


def model_status():
    try:
        return json.loads((settings.LOCAL_DATA_DIR / "model-status.json").read_text())
    except (OSError, ValueError):
        return {"state": "unknown", "message": "Ollama non ancora verificato."}
