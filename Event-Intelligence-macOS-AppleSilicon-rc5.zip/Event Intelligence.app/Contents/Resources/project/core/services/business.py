"""Deterministic financial calculations and automatic reports; no simulated AI."""

import hashlib
import json
from decimal import Decimal, ROUND_CEILING
from django.db import transaction
from core.models import (
    AdObservation,
    OrderRevision,
    AnalysisReport,
    Event,
    CreativeClassification,
)
from .kpis import dashboard, complete_sum


def economics(event):

    orders = list(
        OrderRevision.objects.filter(batch__event=event, batch__status="confirmed")
    )
    # Gross includes refunded orders; refunds are subtracted once, not silently inferred.
    sold = [r for r in orders if r.status in ("completed", "refunded")]
    gross = complete_sum(sold, "gross_revenue")
    fees = complete_sum(sold, "fees")
    refunds = complete_sum(sold, "refunds")
    # Native Eventbrite separates charged totals from ticket revenue. Fee tax can
    # already be included in fees; absent settlement/refund semantics forbid net.
    native = any(r.ticket_revenue is not None for r in sold)
    net = gross - fees - refunds if not native and None not in (gross, fees, refunds) else None
    entries = list(event.economic_entries.all())

    def amount(basis, income=False):
        selected = [
            r.amount
            for r in entries
            if r.basis == basis and (r.category == "other_income") == income
        ]
        return sum(selected, Decimal(0))

    spend = dashboard(event)["kpis"]["spend"]
    actual_cost = amount("actual")
    # Completeness is an explicit user assertion, never inferred from presence of one cost.
    complete = event.costs_complete
    total_cost = actual_cost + spend if spend is not None else None
    margin = (
        net + amount("actual", True) - total_cost
        if net is not None and total_cost is not None
        else None
    )
    contribution = (
        (event.break_even_net_price - event.break_even_variable_cost)
        if event.break_even_net_price is not None
        and event.break_even_variable_cost is not None
        else None
    )
    break_even = None
    if (
        event.break_even_fixed_confirmed
        and contribution is not None
        and contribution > 0
        and total_cost is not None
    ):
        break_even = max(
            0,
            int(
                (
                    (total_cost - amount("actual", True)) / contribution
                ).to_integral_value(rounding=ROUND_CEILING)
            ),
        )
    return dict(
        break_even=break_even,
        contribution=contribution,
        gross=gross,
        ticket_revenue=complete_sum(sold, "ticket_revenue"),
        processing_fees=complete_sum(sold, "processing_fees"),
        fee_tax=complete_sum(sold, "fee_tax"),
        fees=fees,
        refunds=refunds,
        net=net,
        spend=spend,
        actual_cost=actual_cost,
        other_income=amount("actual", True),
        total_cost=total_cost,
        margin=margin,
        complete=complete,
        planned_cost=amount("planned"),
        planned_income=amount("planned", True),
        entries=entries,
    )


def data_fingerprint(event):
    # Includes effective imports, financial entries and confirmed classifications.
    keys = (
        event.imports.filter(status="confirmed")
        .order_by("pk")
        .values_list("pk", "sha256")
    )
    costs = event.economic_entries.order_by("pk").values_list("pk", "updated_at")
    classifications = (
        CreativeClassification.objects.filter(
            source_key__in=AdObservation.objects.filter(
                batch__event=event, batch__status="confirmed"
            ).values("source_key")
        )
        .order_by("pk")
        .values_list("pk", "updated_at")
    )
    return hashlib.sha256(
        json.dumps(
            [
                list(keys),
                list(costs),
                list(classifications),
                event.costs_complete,
                event.planned_budget,
                event.name,
                str(event.date),
                event.mode,
                str(event.brand_id),
                str(event.format_id),
                event.location,
            ],
            default=str,
        ).encode()
    ).hexdigest()


@transaction.atomic
def automatic_report(event):
    event = Event.objects.select_for_update().get(pk=event.pk)
    fingerprint = data_fingerprint(event)
    existing = AnalysisReport.objects.filter(
        event=event, fingerprint=fingerprint, kind="rules"
    ).first()
    if existing:
        from .generative_ai import enqueue

        enqueue(event)
        return existing
    data = dashboard(event)
    k = data["kpis"]
    limits = [
        "Confronti descrittivi: budget, pubblico e durata possono differire. Nessuna conclusione causale.",
        "Gli ordini delle piattaforme e le conversioni Meta sono misure separate.",
    ]
    facts = []
    if k["spend"] is not None:
        facts.append(f"Spesa Meta confermata: {k['spend']:.2f} EUR.")
    if k["clicks"] is not None:
        facts.append(f"Clic sul link: {k['clicks']}.")
    if data["order_count"] is not None:
        facts.append(
            f"Ordini completati: {data['order_count']}; biglietti: {data['tickets']}."
        )
    if not facts:
        facts = [
            "Non sono disponibili importazioni confermate sufficienti per un riepilogo quantitativo."
        ]
    criticisms = []
    if k["clicks"] is None:
        criticisms.append("Clic mancanti: CPC non calcolabile.")
    if k["attributed_purchases"] is None:
        criticisms.append("Acquisti Meta non confrontabili o attribuzione mancante.")
    if data["gross"] is None:
        criticisms.append("Ricavi commerciali mancanti.")
    if not event.costs_complete:
        criticisms.append(
            "Costi organizzativi non dichiarati completi: margine provvisorio."
        )
    comparable = [r for r in data["creatives"] if r["cpc"] is not None]
    comparison = "Dati insufficienti per confrontare il costo per clic."
    if len(comparable) > 1:
        best = min(comparable, key=lambda r: r["cpc"])
        comparison = f"CPC osservato più basso: {best['name']} ({best['cpc']:.3f} EUR). Non dimostra maggiori vendite."
    prior = list(
        Event.objects.filter(brand=event.brand, date__lt=event.date).values_list(
            "name", flat=True
        )[:3]
    )
    body = {
        "summary": facts,
        "performance": facts,
        "worked": [comparison],
        "attention": criticisms
        or [
            "Nessuna anomalia rilevata dalle regole disponibili; non equivale ad assenza di problemi."
        ],
        "creatives": [comparison],
        "previous_events": [
            "Edizioni precedenti nello stesso brand: " + ", ".join(prior)
            if prior
            else "Nessuna edizione precedente disponibile."
        ],
        "anomalies": criticisms,
        "limits": limits,
        "recommendations": [
            "Completare prima i dati mancanti indicati; confrontare inserzioni con obiettivo e periodo omogenei."
        ],
        "actions": [
            "Verificare fonte, copertura temporale e stato degli ordini prima di decidere il budget."
        ],
        "experiments": [
            "Definire un test con stessa audience, obiettivo e durata; registrare ipotesi e risultato."
        ],
        "priorities": [
            "Raccogliere dati commerciali e classificazioni confermate per la prossima edizione."
        ],
    }
    report = AnalysisReport.objects.create(
        event=event,
        fingerprint=fingerprint,
        body=body,
        source_note="Motore deterministico v1; nessun modello AI chiamato.",
    )

    from .generative_ai import enqueue

    enqueue(event)
    return report


def suggestions(name):
    text = name.lower()
    result = {}
    for keyword, value in [
        ("video", "video"),
        ("foto", "image"),
        ("immagine", "image"),
        ("carousel", "carousel"),
    ]:
        if keyword in text:
            result["media_format"] = value
    for keyword, value in [
        ("teaser", "teaser"),
        ("preview", "preview"),
        ("locandina", "poster"),
        ("aftermovie", "aftermovie"),
        ("reminder", "reminder"),
        ("line-up", "lineup"),
    ]:
        if keyword in text:
            result["communication_type"] = value
    return result
