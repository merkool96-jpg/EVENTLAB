"""Initial domain: stable identities, explicit provenance and immutable import revisions."""

import uuid
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.validators import MinValueValidator
from django.db import models
from django.db.models import Q, F


class Record(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class Brand(Record):
    name = models.CharField(max_length=160, unique=True)

    def __str__(self):
        return self.name


class Format(Record):
    brand = models.ForeignKey(Brand, on_delete=models.PROTECT, related_name="formats")
    name = models.CharField(max_length=160)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["brand", "name"], name="format_brand_name")
        ]

    def __str__(self):
        return self.name


class Event(Record):
    class Mode(models.TextChoices):
        FREE = "free", "Gratuito"
        PAID = "paid", "A pagamento"
        MIXED = "mixed", "Misto"

    brand = models.ForeignKey(Brand, on_delete=models.PROTECT, related_name="events")
    format = models.ForeignKey(Format, null=True, blank=True, on_delete=models.PROTECT)
    name = models.CharField("Nome edizione", max_length=200)
    date = models.DateField("Data")
    location = models.CharField("Location", max_length=200, default="Da definire")
    mode = models.CharField("Modalità", max_length=8, choices=Mode.choices)
    break_even_net_price = models.DecimalField(
        "Ricavo netto ipotizzato per biglietto EUR",
        max_digits=12,
        decimal_places=2,
        null=True,
        blank=True,
        validators=[MinValueValidator(0)],
    )
    break_even_variable_cost = models.DecimalField(
        "Costo variabile ipotizzato per biglietto EUR",
        max_digits=12,
        decimal_places=2,
        null=True,
        blank=True,
        validators=[MinValueValidator(0)],
    )
    break_even_fixed_confirmed = models.BooleanField(
        "I costi registrati sono fissi e non includono il costo variabile unitario",
        default=False,
    )
    costs_complete = models.BooleanField("Costi organizzativi completi", default=False)
    currency = models.CharField(max_length=3, default="EUR", choices=[("EUR", "EUR")])
    timezone = models.CharField(max_length=64, default="Europe/Rome")
    planned_budget = models.DecimalField(
        "Budget previsto",
        max_digits=14,
        decimal_places=2,
        null=True,
        blank=True,
        validators=[MinValueValidator(0)],
    )

    class Meta:
        ordering = ["-date", "name"]
        constraints = [
            models.CheckConstraint(
                condition=Q(planned_budget__gte=0) | Q(planned_budget__isnull=True),
                name="event_budget_nonnegative",
            ),
            models.CheckConstraint(
                condition=Q(break_even_net_price__gte=0)
                | Q(break_even_net_price__isnull=True),
                name="event_break_even_price_nonnegative",
            ),
            models.CheckConstraint(
                condition=Q(break_even_variable_cost__gte=0)
                | Q(break_even_variable_cost__isnull=True),
                name="event_break_even_variable_nonnegative",
            ),
        ]

    def clean(self):
        if self.format_id and self.brand_id and self.format.brand_id != self.brand_id:
            raise ValidationError(
                {"format": "Il format deve appartenere al brand selezionato."}
            )
        try:
            ZoneInfo(self.timezone)
        except (ZoneInfoNotFoundError, ValueError):
            raise ValidationError({"timezone": "Fuso orario non valido."})

    def __str__(self):
        return self.name


class ImportBatch(Record):
    class Source(models.TextChoices):
        META = "meta", "Meta Ads"
        EVENTBRITE = "eventbrite", "Eventbrite"
        PARTIFUL = "partiful", "Partiful (tracciato normalizzato)"
        DICE = "dice", "DICE (tracciato normalizzato)"

    class Status(models.TextChoices):
        STAGED = "staged", "Da confermare"
        CONFIRMED = "confirmed", "Confermato"
        REJECTED = "rejected", "Rifiutato"
        REVERTED = "reverted", "Annullato"

    event = models.ForeignKey(Event, on_delete=models.PROTECT, related_name="imports")
    source = models.CharField(max_length=16, choices=Source.choices)
    sha256 = models.CharField(max_length=64)
    filename = models.CharField(max_length=255)
    parser_version = models.CharField(max_length=32)
    payload = models.JSONField(
        default=list
    )  # Whitelisted normalized fields only, never attendee PII.
    confirmed_at = models.DateTimeField(null=True)
    replaces = models.ForeignKey(
        "self",
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="replacements",
    )
    status = models.CharField(
        max_length=16, choices=Status.choices, default=Status.STAGED
    )
    period_start = models.DateField(null=True)
    period_end = models.DateField(null=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)

    def __str__(self):
        return f"{self.filename} · {self.get_source_display()}"

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["event", "source", "sha256"], name="import_event_source_hash"
            ),
            models.CheckConstraint(
                condition=Q(period_end__gte=F("period_start"))
                | Q(period_end__isnull=True)
                | Q(period_start__isnull=True),
                name="import_valid_period",
            ),
        ]


class AdAccount(Record):
    external_id = models.CharField(max_length=100, unique=True)
    name = models.CharField(max_length=200, blank=True)


class Campaign(Record):
    account = models.ForeignKey(AdAccount, on_delete=models.PROTECT)
    external_id = models.CharField(max_length=100)
    name = models.CharField(max_length=255)
    objective = models.CharField(max_length=100, blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["account", "external_id"], name="campaign_identity"
            )
        ]


class AdSet(Record):
    campaign = models.ForeignKey(Campaign, on_delete=models.PROTECT)
    external_id = models.CharField(max_length=100)
    name = models.CharField(max_length=255)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["campaign", "external_id"], name="adset_identity"
            )
        ]


class Creative(Record):
    name = models.CharField(max_length=255)
    # Dimensions are independent. Blank means unknown, never an inferred classification.
    media_format = models.CharField(max_length=40, blank=True)
    communication_type = models.CharField(max_length=80, blank=True)
    promotional_phase = models.CharField(max_length=40, blank=True)
    confirmed = models.BooleanField(default=False)


class Ad(Record):
    adset = models.ForeignKey(AdSet, on_delete=models.PROTECT)
    creative = models.ForeignKey(Creative, on_delete=models.PROTECT, related_name="ads")
    external_id = models.CharField(max_length=100)
    name = models.CharField(max_length=255)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["adset", "external_id"], name="ad_identity")
        ]


class AdObservation(Record):
    batch = models.ForeignKey(
        ImportBatch, on_delete=models.PROTECT, related_name="ad_observations"
    )
    ad = models.ForeignKey(Ad, on_delete=models.PROTECT, null=True, blank=True)
    # Export without IDs remains an observation; no fabricated platform identity.
    source_key = models.CharField(max_length=255)
    creative_name = models.CharField(max_length=255)
    period_start = models.DateField()
    period_end = models.DateField()
    currency = models.CharField(max_length=3)
    spend = models.DecimalField(max_digits=16, decimal_places=2)
    impressions = models.PositiveBigIntegerField(null=True)
    link_clicks = models.PositiveBigIntegerField(null=True)
    attributed_purchases = models.PositiveBigIntegerField(null=True)
    attributed_revenue = models.DecimalField(max_digits=16, decimal_places=2, null=True)
    attribution = models.CharField(max_length=160, blank=True)
    source_row = models.PositiveIntegerField()

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["batch", "source_key", "period_start", "period_end"],
                name="ad_observation_identity",
            ),
            models.CheckConstraint(
                condition=Q(period_end__gte=F("period_start")),
                name="observation_valid_period",
            ),
            models.CheckConstraint(
                condition=Q(spend__gte=0), name="observation_nonnegative_spend"
            ),
        ]


class TicketingEvent(Record):
    event = models.ForeignKey(
        Event, on_delete=models.PROTECT, related_name="ticketing_events"
    )
    platform = models.CharField(max_length=32)
    external_id = models.CharField(max_length=100)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["platform", "external_id"], name="ticketing_event_identity"
            )
        ]


class OrderRevision(Record):
    batch = models.ForeignKey(
        ImportBatch, on_delete=models.PROTECT, related_name="orders"
    )
    ticketing_event = models.ForeignKey(TicketingEvent, on_delete=models.PROTECT)
    external_id = models.CharField(max_length=100)
    status = models.CharField(max_length=40)
    ordered_at = models.DateTimeField(null=True)
    ticket_count = models.PositiveIntegerField()
    gross_revenue = models.DecimalField(max_digits=16, decimal_places=2, null=True)
    ticket_revenue = models.DecimalField(max_digits=16, decimal_places=2, null=True)
    processing_fees = models.DecimalField(max_digits=16, decimal_places=2, null=True)
    fee_tax = models.DecimalField(max_digits=16, decimal_places=2, null=True)
    fees = models.DecimalField(max_digits=16, decimal_places=2, null=True)
    refunds = models.DecimalField(max_digits=16, decimal_places=2, null=True)
    currency = models.CharField(max_length=3)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["batch", "ticketing_event", "external_id"],
                name="order_revision_identity",
            )
        ]


class AuditEntry(Record):
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    event = models.ForeignKey(Event, on_delete=models.PROTECT)
    action = models.CharField(max_length=80)
    details = models.JSONField(default=dict)


# Split by domain while registering all models in the same Django application.
from .business_models import (
    RegistrationRevision as RegistrationRevision,
    CreativeClassification as CreativeClassification,
    EconomicEntry as EconomicEntry,
    CampaignPlan as CampaignPlan,
    PlanActivity as PlanActivity,
    AnalysisReport as AnalysisReport,
    StrategicDecision as StrategicDecision,
)

from .ai_models import AIJob as AIJob
from .ai_models import AIRequest as AIRequest
