from django.contrib import admin
from .models import Brand, Format, Event

admin.site.register([Brand, Format, Event])
