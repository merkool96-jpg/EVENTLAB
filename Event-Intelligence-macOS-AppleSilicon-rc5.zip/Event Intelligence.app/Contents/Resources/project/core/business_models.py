"""Economics, plans, classifications and versioned evidence-based reports."""

from decimal import Decimal
from django.conf import settings
from django.core.validators import MinValueValidator
from django.db import models
from django.db.models import Q
from .models import Record, Event, ImportBatch, TicketingEvent


class RegistrationRevision(Record):
    batch = models.ForeignKey(
        ImportBatch, on_delete=models.PROTECT, related_name="registrations"
    )
    ticketing_event = models.ForeignKey(TicketingEvent, on_delete=models.PROTECT)
    external_id = models.CharField(max_length=100)
    status = models.CharField(
        max_length=24, choices=[("confirmed", "Confermato"), ("cancelled", "Annullato")]
    )
    guests = models.PositiveIntegerField()

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["batch", "ticketing_event", "external_id"],
                name="registration_revision_identity",
            )
        ]


class CreativeClassification(Record):
    source_key = models.CharField(max_length=255, unique=True)
    name = models.CharField(max_length=255)
    media_format = models.CharField(
        "Formato",
        max_length=20,
        choices=[
            ("video", "Video"),
            ("image", "Immagine"),
            ("carousel", "Carosello"),
            ("other", "Altro"),
        ],
        blank=True,
    )
    communication_type = models.CharField(
        "Tipologia",
        max_length=24,
        choices=[
            (k, v)
            for k, v in [
                ("teaser", "Teaser"),
                ("preview", "Preview"),
                ("poster", "Locandina"),
                ("promo", "Promozionale"),
                ("aftermovie", "Aftermovie"),
                ("emotional", "Emozionale"),
                ("lineup", "Line-up"),
                ("reminder", "Reminder"),
                ("other", "Altro"),
            ]
        ],
        blank=True,
    )
    phase = models.CharField(
        "Fase",
        max_length=20,
        choices=[
            ("launch", "Lancio"),
            ("middle", "Intermedia"),
            ("last_days", "Ultimi giorni"),
            ("event_day", "Giorno evento"),
        ],
        blank=True,
    )
    objective = models.CharField(
        "Obiettivo",
        max_length=20,
        choices=[
            ("awareness", "Awareness"),
            ("traffic", "Traffico"),
            ("engagement", "Engagement"),
            ("lead", "Lead"),
            ("sales", "Vendite"),
        ],
        blank=True,
    )
    confirmed_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)


class EconomicEntry(Record):
    event = models.ForeignKey(
        Event, on_delete=models.PROTECT, related_name="economic_entries"
    )
    category = models.CharField(
        "Categoria",
        max_length=24,
        choices=[
            ("location", "Location"),
            ("artists", "Artisti"),
            ("production", "Produzione"),
            ("staff", "Staff"),
            ("other_cost", "Altri costi"),
            ("other_income", "Altre entrate"),
        ],
    )
    description = models.CharField("Descrizione", max_length=200)
    amount = models.DecimalField(
        "Importo EUR",
        max_digits=14,
        decimal_places=2,
        validators=[MinValueValidator(0)],
    )
    basis = models.CharField(
        "Natura",
        max_length=12,
        choices=[("planned", "Preventivo"), ("actual", "Consuntivo")],
    )
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)

    class Meta:
        constraints = [
            models.CheckConstraint(
                condition=Q(amount__gte=0), name="economic_nonnegative"
            )
        ]


class CampaignPlan(Record):
    event = models.ForeignKey(Event, on_delete=models.PROTECT, related_name="plans")
    title = models.CharField("Nome piano", max_length=160)
    budget = models.DecimalField(
        "Budget EUR", max_digits=14, decimal_places=2, validators=[MinValueValidator(0)]
    )
    objective = models.CharField("Obiettivo", max_length=200)
    target_cpc = models.DecimalField(
        "CPC ipotizzato EUR",
        max_digits=10,
        decimal_places=4,
        null=True,
        blank=True,
        validators=[MinValueValidator(Decimal("0.0001"))],
    )
    assumptions = models.TextField(
        "Ipotesi e limiti dello scenario", blank=True, max_length=4000
    )
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)

    class Meta:
        constraints = [
            models.CheckConstraint(condition=Q(budget__gte=0), name="plan_nonnegative"),
            models.CheckConstraint(
                condition=Q(target_cpc__gt=0) | Q(target_cpc__isnull=True),
                name="plan_cpc_positive",
            ),
        ]


class PlanActivity(Record):
    plan = models.ForeignKey(
        CampaignPlan, on_delete=models.PROTECT, related_name="activities"
    )
    title = models.CharField("Attività creativa", max_length=200)
    date = models.DateField("Data")
    phase = models.CharField(
        "Fase",
        max_length=20,
        choices=CreativeClassification._meta.get_field("phase").choices,
    )
    done = models.BooleanField("Completata", default=False)


class AnalysisReport(Record):
    event = models.ForeignKey(Event, on_delete=models.PROTECT, related_name="reports")
    fingerprint = models.CharField(max_length=64)
    kind = models.CharField(
        max_length=20,
        choices=[
            ("rules", "Analisi automatica a regole"),
            ("imported_ai", "Report AI importato"),
            ("generative_ai", "Riflessione AI generativa"),
        ],
        default="rules",
    )
    revision = models.PositiveIntegerField(default=1)
    model_name = models.CharField(max_length=100, blank=True)
    prompt_version = models.CharField(max_length=32, blank=True)
    evidence = models.JSONField(default=dict)
    body = models.JSONField(default=dict)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True
    )
    source_note = models.CharField(max_length=250, blank=True)

    class Meta:
        ordering = ["-created_at"]
        constraints = [
            models.UniqueConstraint(
                fields=["event", "fingerprint", "kind", "revision"],
                name="report_data_kind_identity",
            )
        ]


class StrategicDecision(Record):
    event = models.ForeignKey(Event, on_delete=models.PROTECT, related_name="decisions")
    report = models.ForeignKey(
        AnalysisReport, on_delete=models.PROTECT, null=True, blank=True
    )
    kind = models.CharField(
        "Tipo",
        max_length=20,
        choices=[
            ("decision", "Decisione"),
            ("experiment", "Esperimento"),
            ("recommendation", "Raccomandazione"),
        ],
    )
    description = models.TextField("Azione / ipotesi", max_length=4000)
    outcome = models.TextField(
        "Risultato osservato e limiti", blank=True, max_length=4000
    )
    status = models.CharField(
        "Stato",
        max_length=16,
        choices=[("planned", "Da fare"), ("running", "In corso"), ("done", "Concluso")],
        default="planned",
    )
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
