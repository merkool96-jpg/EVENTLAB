from django import template
from django.utils.formats import number_format

register = template.Library()


@register.filter
def metric(value, decimals=2):
    if value is None:
        return "Non disponibile"
    return number_format(value, decimal_pos=int(decimals), force_grouping=True)


@register.filter
def section_label(value):
    return {
        "summary": "Sintesi",
        "performance": "Panoramica performance",
        "worked": "Cosa ha funzionato",
        "attention": "Criticità e attenzione",
        "creatives": "Confronto creatività",
        "previous_events": "Edizioni precedenti",
        "anomalies": "Anomalie",
        "limits": "Limiti e qualità dati",
        "recommendations": "Raccomandazioni",
        "actions": "Azioni pratiche",
        "experiments": "Esperimenti suggeriti",
        "priorities": "Priorità",
    }.get(value, value)
