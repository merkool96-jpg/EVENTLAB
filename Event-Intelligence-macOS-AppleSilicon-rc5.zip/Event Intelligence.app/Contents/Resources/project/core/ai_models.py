"""Durable, deduplicated requests. A failed request is never silently billed again."""

import uuid
from django.db import models
from .models import Record, Event


class AIJob(Record):
    class Status(models.TextChoices):
        BLOCKED = "blocked", "AI non attivata"
        QUEUED = "queued", "In coda"
        RUNNING = "running", "In elaborazione"
        SUCCEEDED = "succeeded", "Completata"
        FAILED = "failed", "Errore"
        UNCERTAIN = "uncertain", "Esito remoto da verificare"
        SUPERSEDED = "superseded", "Dati superati"

    event = models.ForeignKey(Event, on_delete=models.PROTECT, related_name="ai_jobs")
    fingerprint = models.CharField(max_length=64)
    context_hash = models.CharField(max_length=64)
    config_signature = models.CharField(max_length=64)
    model_name = models.CharField(max_length=100, blank=True)
    prompt_version = models.CharField(max_length=32)
    snapshot = models.JSONField(default=dict)
    status = models.CharField(
        max_length=16, choices=Status.choices, default=Status.BLOCKED
    )
    attempts = models.PositiveIntegerField(default=0)
    error_code = models.CharField(max_length=64, blank=True)
    claim_token = models.UUIDField(null=True)
    request_key = models.UUIDField(default=uuid.uuid4, editable=False)
    started_at = models.DateTimeField(null=True)
    finished_at = models.DateTimeField(null=True)
    lease_until = models.DateTimeField(null=True)
    report = models.OneToOneField(
        "core.AnalysisReport", on_delete=models.PROTECT, null=True
    )

    class Meta:
        ordering = ["-created_at"]
        constraints = [
            models.UniqueConstraint(
                fields=["event", "fingerprint", "context_hash", "config_signature"],
                name="ai_job_evidence_config_identity",
            )
        ]
        indexes = [models.Index(fields=["status", "created_at"])]


class AIRequest(Record):
    job = models.ForeignKey(AIJob, on_delete=models.PROTECT, related_name="requests")
    request_key = models.UUIDField(unique=True)
    outcome = models.CharField(max_length=20, default="reserved")
    finished_at = models.DateTimeField(null=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
