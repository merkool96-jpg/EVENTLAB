from core import forecast_views as f
from core.universal_views import DocumentDetail
from django.contrib import admin
from django.contrib.auth import views as auth
from django.urls import path
from core.views import (
    EventList,
    EventDetail,
    EventCreate,
    ImportUpload,
    ImportDetail,
    ImportAction,
)
from core import workspace_views as w

from core.health import health

urlpatterns = [
    path("forecasts/", f.Forecasts.as_view(), name="forecasts"),
    path("forecasts/new/", f.ForecastEdit.as_view(), name="forecast-create"),
    path("forecasts/preview/", f.ForecastPreview.as_view(), name="forecast-preview"),
    path("forecasts/<uuid:pk>/", f.ForecastDetail.as_view(), name="forecast-detail"),
    path("forecasts/<uuid:pk>/edit/", f.ForecastEdit.as_view(), name="forecast-edit"),
    path("forecast-revisions/<uuid:pk>/explain/", f.ForecastExplain.as_view(), name="forecast-explain"),
    path("health/", health, name="health"),
    path("ai/jobs/<uuid:pk>/retry/", w.AIRetry.as_view(), name="ai-retry"),
    path(
        "events/<uuid:pk>/break-even/",
        w.BreakEvenSettings.as_view(),
        name="break-even-settings",
    ),
    path("plans/<uuid:pk>/edit/", w.PlanEdit.as_view(), name="plan-edit"),
    path("activities/<uuid:pk>/edit/", w.ActivityEdit.as_view(), name="activity-edit"),
    path("decisions/<uuid:pk>/edit/", w.DecisionEdit.as_view(), name="decision-edit"),
    path(
        "imports/template/<str:platform>/",
        w.NormalizedTemplate.as_view(),
        name="normalized-template",
    ),
    path("dashboard/", w.Overview.as_view(), name="overview-alias"),
    path("brands/", w.Brands.as_view(), name="brands"),
    path("events/<uuid:pk>/edit/", w.EventEdit.as_view(), name="event-edit"),
    path("imports/", w.ImportCenter.as_view(), name="imports"),
    path("documents/<uuid:pk>/", DocumentDetail.as_view(), name="document-detail"),
    path("creatives/", w.Creatives.as_view(), name="creatives"),
    path("creatives/<str:key>/", w.Classify.as_view(), name="classify"),
    path("economy/", w.Economy.as_view(), name="economy"),
    path("events/<uuid:pk>/costs/new/", w.CostCreate.as_view(), name="cost-create"),
    path("costs/<uuid:pk>/edit/", w.CostEdit.as_view(), name="cost-edit"),
    path(
        "events/<uuid:pk>/costs/complete/",
        w.CostsComplete.as_view(),
        name="costs-complete",
    ),
    path("planning/", w.Planning.as_view(), name="planning"),
    path("events/<uuid:pk>/plans/new/", w.PlanCreate.as_view(), name="plan-create"),
    path(
        "plans/<uuid:pk>/activities/new/",
        w.ActivityCreate.as_view(),
        name="activity-create",
    ),
    path("reflections/", w.Reflections.as_view(), name="reflections"),
    path("events/<uuid:pk>/analyze/", w.Analyze.as_view(), name="analyze"),
    path(
        "events/<uuid:pk>/decisions/new/",
        w.DecisionCreate.as_view(),
        name="decision-create",
    ),
    path(
        "events/<uuid:pk>/analysis/export/",
        w.AnalysisExport.as_view(),
        name="analysis-export",
    ),
    path(
        "events/<uuid:pk>/analysis/import/",
        w.AnalysisImport.as_view(),
        name="analysis-import",
    ),
    path("events/<uuid:pk>/imports/new/", ImportUpload.as_view(), name="import-upload"),
    path("imports/<uuid:pk>/", ImportDetail.as_view(), name="import-detail"),
    path(
        "imports/<uuid:pk>/<str:action>/", ImportAction.as_view(), name="import-action"
    ),
    path("admin/", admin.site.urls),
    path("accounts/login/", auth.LoginView.as_view(), name="login"),
    path("accounts/logout/", auth.LogoutView.as_view(), name="logout"),
    path("", w.Overview.as_view(), name="overview"),
    path("events/", EventList.as_view(), name="event-list"),
    path("events/new/", EventCreate.as_view(), name="event-create"),
    path("events/<uuid:pk>/", EventDetail.as_view(), name="event-detail"),
]

from django.conf import settings

if getattr(settings, "EVENT_LOCAL_MODE", False):
    from core import local_views

    urlpatterns += [
        path("local/launch/", local_views.launch, name="local-launch"),
        path("local/unlock/", local_views.unlock, name="local-unlock"),
        path("local/settings/", local_views.settings_page, name="local-settings"),
    ]
