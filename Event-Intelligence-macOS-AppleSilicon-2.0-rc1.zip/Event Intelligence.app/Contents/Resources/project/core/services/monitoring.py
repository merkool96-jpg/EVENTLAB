"""Read-only directional metrics; missing values and coverage stay explicit."""
from collections import defaultdict
from decimal import Decimal
from core.models import ParticipationRecord, OrderRevision
from django.utils import timezone
from .business import economics


def monitoring(rows):
    brands = {}
    coverage = {key: 0 for key in ('advertising', 'clicks', 'commercial', 'margin')}
    for row in rows:
        event = row['event']
        financial = economics(event)
        row['verified_margin'] = financial['margin'] if financial['complete'] else None
        row['costs_complete'] = financial['complete']
        coverage['advertising'] += row['kpis']['spend'] is not None
        coverage['clicks'] += row['kpis']['clicks'] is not None
        coverage['commercial'] += row['conversions']['has_data']
        coverage['margin'] += row['verified_margin'] is not None
        brand = brands.setdefault(event.brand_id, dict(name=event.brand.name, events=0,
            spend=Decimal(0), spend_events=0, actions=0, action_events=0))
        brand['events'] += 1
        if row['kpis']['spend'] is not None:
            brand['spend'] += row['kpis']['spend']; brand['spend_events'] += 1
        if row['conversions']['has_data']:
            brand['actions'] += row['conversions']['total_actions']; brand['action_events'] += 1
    for brand in brands.values():
        if not brand['spend_events']: brand['spend'] = None
        if not brand['action_events']: brand['actions'] = None
    linked = defaultdict(set)
    # Only an exact linked contact with an email key; never merge names.
    records = ParticipationRecord.objects.filter(batch__event__in=[r['event'] for r in rows],
        batch__status='confirmed', contact__email_key__isnull=False).values_list('contact_id', 'batch__event_id')
    for contact, event in records:
        linked[contact].add(event)
    days = {}
    orders = OrderRevision.objects.filter(batch__event__in=[r['event'] for r in rows],
        batch__status='confirmed', status='completed')
    missing_dates = orders.filter(ordered_at__isnull=True).count()
    for order in orders.exclude(ordered_at__isnull=True):
        day = timezone.localdate(order.ordered_at).isoformat()
        values = days.setdefault(day, dict(date=day, orders=0, tickets=0, revenue=Decimal(0), missing=0))
        values['orders'] += 1; values['tickets'] += order.ticket_count
        if order.ticket_revenue is None: values['missing'] += 1
        else: values['revenue'] += order.ticket_revenue
    for values in days.values():
        if values['missing']: values['revenue'] = None
    return dict(sales_days=[days[key] for key in sorted(days)], orders_without_date=missing_dates, coverage=coverage, brands=list(brands.values()),
        linked_contacts=len(linked), returning_contacts=sum(len(events)>1 for events in linked.values()),
        total_events=len(rows))
