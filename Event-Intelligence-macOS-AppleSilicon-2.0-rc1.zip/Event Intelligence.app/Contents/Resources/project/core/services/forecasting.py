"""Conditional economics, not demand prediction. All money uses Decimal."""
from decimal import Decimal, ROUND_CEILING
from django.utils import timezone
from core.models import Event, ParticipationRecord, OrderRevision, RegistrationRevision
from .kpis import dashboard
from .business import data_fingerprint, economics

FORMULA_VERSION = 'conditional-1'
MONEY = ('price','ad_budget','fixed_cost','variable_cost','fee','other_income','desired_margin')


def simulate(inputs):
    d = dict(inputs)
    for key in MONEY: d[key] = Decimal(str(d[key]))
    def scenario(quantity, override=None):
        v = {**d, **(override or {})}
        income = quantity*v['price'] + v['other_income']
        costs = v['fixed_cost']+v['ad_budget']+quantity*(v['variable_cost']+v['fee'])
        return dict(quantity=quantity, ticket_revenue=quantity*v['price'], revenue=income, costs=costs, margin=income-costs)
    contribution = d['price']-d['variable_cost']-d['fee']
    gap = d['fixed_cost']+d['ad_budget']-d['other_income']
    def required(extra=0):
        if contribution <= 0: return None
        return max(0,int(((gap+extra)/contribution).to_integral_value(rounding=ROUND_CEILING)))
    scenarios = [dict(name=label, **scenario(d[key])) for key,label in
        (('prudent','Prudente'),('central','Centrale'),('optimistic','Ottimistico'))]
    sensitivity = []
    factor = Decimal(d['stress'])/100
    for key,label in (('price','Ricavo unitario'),('fixed_cost','Costi fissi'),('variable_cost','Costo variabile'),('ad_budget','Budget pubblicitario')):
        sensitivity.append(dict(label=label, low=scenario(d['central'],{key:d[key]*(1-factor)})['margin'],
            high=scenario(d['central'],{key:d[key]*(1+factor)})['margin']))
    warnings = ['Domanda futura non determinabile con affidabilità: quantità inserite manualmente, nessun intervallo statistico.']
    if not d.get('costs_reviewed'): warnings.append('Categorie di costo da completare: i margini sono provvisori.')
    if contribution <= 0: warnings.append('Contributo unitario nullo o negativo: il pareggio tramite volume non è determinabile.')
    breakeven = required()
    if breakeven is not None and breakeven > d['capacity']: warnings.append('Pareggio oltre capienza: modificare costi, prezzo o altri ricavi.')
    if required(d['desired_margin']) is not None and required(d['desired_margin']) > d['capacity']: warnings.append('Il margine desiderato richiede quantità oltre capienza.')
    if scenarios[0]['margin'] < 0: warnings.append('Lo scenario prudente è in perdita: prevedere copertura o ridurre i costi.')
    cpa = Decimal(str(d['assumed_cpa'])) if d.get('assumed_cpa') else None
    return dict(scenarios=scenarios, contribution=contribution, breakeven=breakeven,
        units_for_margin=required(d['desired_margin']), target_margin=scenario(d['target'])['margin'],
        required_price=max(Decimal(0),((gap+d['target']*(d['variable_cost']+d['fee'])+d['desired_margin'])/d['target']).quantize(Decimal('0.01'),rounding=ROUND_CEILING)) if d['target'] else None,
        additional_income=max(Decimal(0),d['desired_margin']-scenario(d['target'])['margin']),
        conditional_actions=d['ad_budget']/cpa if cpa else None,
        conditional_budget=d['target']*cpa if cpa else None,
        sensitivity=sensitivity, warnings=warnings,
        recommendations=['Verifica i costi mancanti prima di impegnare il budget.',
            'Confronta solo edizioni con modalità e format compatibili; conserva le ipotesi prima dell’evento.',
            'Usa i risultati importati per confrontare lo scenario, senza attribuire automaticamente le vendite alla pubblicità.'])


def actuals(event, goal):
    data = dashboard(event)
    conv = data['conversions']
    records = ParticipationRecord.objects.filter(batch__event=event,batch__status='confirmed')
    if goal in ('tickets','ticket_paid'):
        available = OrderRevision.objects.filter(batch__event=event,batch__status='confirmed').exists() or records.filter(kind__in=['ticket_paid','ticket_free','ticket_unknown']).exists()
        quantity = conv['ticket_paid'] if goal=='ticket_paid' else conv['ticket_paid']+conv['ticket_free']+conv['ticket_unclassified']
        if goal=='ticket_paid' and conv['ticket_unclassified']: available=False
    elif goal=='rsvp':
        available=RegistrationRevision.objects.filter(batch__event=event,batch__status='confirmed').exists() or records.filter(kind='rsvp').exists()
        quantity=conv['rsvp']
    else:
        available=records.filter(kind='free_registration').exists();quantity=conv['free_registration']
    financial=economics(event)
    return dict(quantity=quantity if available else None, spend=data['kpis']['spend'],
        ticket_revenue=data['ticket_revenue'] if data['ticket_revenue'] is not None else conv['standalone_ticket_revenue'],
        gross=data['gross'], margin=financial['margin'] if financial['complete'] else None)


def historical_sources(event, goal):
    comparable=Event.objects.filter(brand=event.brand,mode=event.mode,date__lt=min(event.date,timezone.localdate())).exclude(pk=event.pk)
    if event.format_id: comparable=comparable.filter(format_id=event.format_id)
    else: comparable=comparable.filter(format__isnull=True)
    sources=[]
    for past in comparable.order_by('-date','pk')[:30]:
        sources.append(dict(id=str(past.pk),name=past.name,date=past.date.isoformat(),brand=past.brand.name,
            mode=past.mode,format=str(past.format) if past.format_id else '',fingerprint=data_fingerprint(past),
            imports=list(past.imports.filter(status='confirmed').values('sha256','parser_version')),
            costs_complete=past.costs_complete, actuals=actuals(past,goal)))
    return sources


def assess_history(sources):
    """Descriptive benchmarks, never automated scenario quantities or confidence."""
    pairs=[(Decimal(str(s['actuals']['spend'])),s['actuals']['quantity']) for s in sources
        if s['actuals']['spend'] is not None and s['actuals']['quantity'] is not None]
    quantity=sum(q for _,q in pairs)
    margins=sum(s['actuals']['margin'] is not None for s in sources)
    recommendations=[]
    if not sources:
        recommendations.append('Nessuna edizione storica comparabile: verifica tutte le quantità con una raccolta di evidenze prima di impegnare i costi.')
    elif margins<len(sources):
        recommendations.append('Completa costi e incassi netti delle edizioni comparabili prima di usare lo storico per valutare la redditività.')
    if len(pairs)<len(sources):
        recommendations.append('Lo storico pubblicitario e commerciale non ha copertura uniforme: confronta prima le fonti e i periodi disponibili.')
    recommendations.append('Le edizioni disponibili non validano un modello di domanda: usa i benchmark soltanto come contesto descrittivo delle ipotesi manuali.')
    return dict(events=len(sources), comparable_pairs=len(pairs), verifiable_margins=margins,
        descriptive_cost_per_unit=sum((spend for spend,_ in pairs),Decimal(0))/quantity if quantity else None,
        recommendations=recommendations)
