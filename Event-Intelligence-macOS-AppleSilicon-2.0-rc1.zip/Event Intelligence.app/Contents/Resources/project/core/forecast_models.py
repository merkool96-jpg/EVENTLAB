"""Append-only scenario versions; existing business data is never rewritten."""
from django.conf import settings
from django.db import models
from .models import Record, Event


class ForecastPlan(Record):
    event = models.ForeignKey(Event, on_delete=models.PROTECT, related_name='forecasts')
    title = models.CharField('Nome simulazione', max_length=160)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)

    class Meta:
        ordering = ['-created_at']


class ForecastRevision(Record):
    plan = models.ForeignKey(ForecastPlan, on_delete=models.PROTECT, related_name='revisions')
    number = models.PositiveIntegerField()
    inputs = models.JSONField()
    results = models.JSONField()
    sources = models.JSONField(default=list)
    formula_version = models.CharField(max_length=32, default='conditional-1')
    explanation = models.JSONField(default=dict)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)

    class Meta:
        ordering = ['-number']
        constraints = [models.UniqueConstraint(fields=['plan', 'number'], name='forecast_revision_number')]
