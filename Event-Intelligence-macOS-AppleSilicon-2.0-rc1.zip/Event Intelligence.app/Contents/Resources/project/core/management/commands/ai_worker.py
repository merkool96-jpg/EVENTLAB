import time
from django.core.management.base import BaseCommand, CommandError
from django.db import close_old_connections
from core.services.generative_ai import process_one


class Command(BaseCommand):
    help = "Elabora la coda AI. Nessuna chiamata se non esplicitamente attivata/autorizzata."

    def add_arguments(self, parser):
        parser.add_argument("--once", action="store_true")
        parser.add_argument("--poll-seconds", type=int, default=3)

    def handle(self, *args, **options):
        if not 1 <= options["poll_seconds"] <= 60:
            raise CommandError("Intervallo ammesso: da uno a sessanta secondi.")
        while True:
            close_old_connections()
            try:
                from core.services.mapping_ai import process_mapping_task
                from core.services.forecast_ai import process_forecast_task
                processed = process_mapping_task() or process_forecast_task() or process_one()
            except KeyboardInterrupt:
                return
            except Exception:
                # Do not expose provider bodies, Authorization headers, or secret settings.
                raise CommandError(
                    "Worker interrotto per errore operativo. Verificare database e stato coda; nessun reinvio automatico delle richieste incerte."
                ) from None
            if options["once"]:
                self.stdout.write(
                    "Ciclo AI completato; richieste inviate solo se configurate e autorizzate."
                )
                return
            if not processed:
                time.sleep(options["poll_seconds"])
