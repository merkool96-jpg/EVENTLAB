import json
from django.contrib import messages
from django.core.serializers.json import DjangoJSONEncoder
from django.db import transaction
from django.db.models import Max
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from .models import ForecastPlan, ForecastRevision, AuditEntry
from .forecast_forms import ForecastForm
from .workspace_views import SecurePage, require
from .services.forecasting import simulate, actuals, historical_sources, assess_history


def serial(value):
    return json.loads(json.dumps(value, cls=DjangoJSONEncoder))


class Forecasts(SecurePage):
    def get(self, request):
        return render(request,'forecast/list.html',{'plans':ForecastPlan.objects.select_related('event','event__brand')})


class ForecastEdit(SecurePage):
    def get(self, request, pk=None):
        plan=get_object_or_404(ForecastPlan,pk=pk) if pk else None
        revision=plan.revisions.first() if plan else None
        initial=dict(revision.inputs,event=plan.event_id,title=plan.title) if revision else {'event':request.GET.get('event')}
        return render(request,'forecast/form.html',{'form':ForecastForm(initial=initial),'plan':plan,'revision':revision})

    def post(self, request, pk=None):
        require(request.user,'change_forecastplan' if pk else 'add_forecastplan')
        form=ForecastForm(request.POST)
        plan=get_object_or_404(ForecastPlan,pk=pk) if pk else None
        if form.is_valid():
            values=dict(form.cleaned_data)
            event=values.pop('event');title=values.pop('title')
            if plan and plan.event_id!=event.pk:
                form.add_error('event','L’evento di una simulazione esistente non può cambiare. Crea una nuova simulazione.')
            else:
                result=simulate(values);sources=serial(historical_sources(event,values['goal']))
                result['historical_quality']=assess_history(sources)
                result['recommendations'].extend(result['historical_quality']['recommendations'])
                result=serial(result)
                # Freeze event identity too: editing its name/date later cannot change the hypotheses.
                values['event_snapshot']=dict(id=str(event.pk),name=event.name,brand=event.brand.name,
                    format=str(event.format) if event.format_id else '',date=event.date.isoformat(),location=event.location,mode=event.mode)
                with transaction.atomic():
                    if plan:
                        plan=ForecastPlan.objects.select_for_update().get(pk=plan.pk)
                        plan.title=title;plan.save(update_fields=['title','updated_at'])
                    else: plan=ForecastPlan.objects.create(event=event,title=title,created_by=request.user)
                    number=(plan.revisions.aggregate(n=Max('number'))['n'] or 0)+1
                    revision=ForecastRevision.objects.create(plan=plan,number=number,inputs=serial(values),
                        results=result,sources=sources,created_by=request.user)
                    AuditEntry.objects.create(actor=request.user,event=event,action='forecast.revision',details={'revision':str(revision.pk)})
                messages.success(request,'Scenario salvato: le revisioni precedenti sono conservate.')
                return redirect('forecast-detail',pk=plan.pk)
        return render(request,'forecast/form.html',{'form':form,'plan':plan},status=400)


class ForecastPreview(SecurePage):
    def post(self, request):
        require(request.user,'add_forecastplan')
        form=ForecastForm(request.POST)
        if not form.is_valid(): return JsonResponse({'errors':form.errors.get_json_data()},status=400)
        values=dict(form.cleaned_data);values.pop('event');values.pop('title')
        return JsonResponse(serial(simulate(values)))


class ForecastDetail(SecurePage):
    def get(self, request, pk):
        plan=get_object_or_404(ForecastPlan.objects.select_related('event','event__brand','event__format'),pk=pk)
        revisions=plan.revisions.all()
        revision=get_object_or_404(revisions,pk=request.GET['revision']) if request.GET.get('revision') else revisions.first()
        observed=actuals(plan.event,revision.inputs['goal'])
        target=revision.inputs['target']
        delta=observed['quantity']-target if observed['quantity'] is not None else None
        saved_date=revision.inputs['event_snapshot']['date']
        eligible=timezone.localdate(revision.created_at).isoformat()<saved_date and saved_date==plan.event.date.isoformat() and saved_date<timezone.localdate().isoformat()
        errors=[]
        if eligible and observed['quantity'] is not None:
            errors=[dict(name=s['name'],error=observed['quantity']-s['quantity']) for s in revision.results['scenarios']]
        return render(request,'forecast/detail.html',dict(plan=plan,revision=revision,revisions=revisions,
            observed=observed,delta=delta,backtest=errors,eligible=eligible,
            assumptions=[(field.label, revision.inputs.get(name)) for name,field in ForecastForm.base_fields.items() if name not in ('event','title','goal')],
            goal_label=dict(ForecastForm.base_fields['goal'].choices).get(revision.inputs['goal'])))


class ForecastExplain(SecurePage):
    def post(self, request, pk):
        require(request.user,'change_forecastplan')
        from .services.forecast_ai import request_explanation
        revision=get_object_or_404(ForecastRevision,pk=pk)
        request_explanation(revision)
        return redirect('forecast-detail',pk=revision.plan_id)
