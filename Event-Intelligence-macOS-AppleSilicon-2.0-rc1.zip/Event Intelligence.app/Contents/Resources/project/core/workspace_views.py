"""Seven server-rendered sections over the same persistent data store."""

import json
from collections import defaultdict
from decimal import Decimal
from django import forms
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.core.exceptions import PermissionDenied, ValidationError
from django.core.serializers.json import DjangoJSONEncoder
from django.db import transaction
from django.http import JsonResponse, HttpResponseRedirect
from django.shortcuts import get_object_or_404, render
from django.urls import reverse
from django.views import View
from django.views.generic import UpdateView
from .models import (
    AIJob,
    Brand,
    Format,
    Event,
    AdObservation,
    ImportBatch,
    CreativeClassification,
    EconomicEntry,
    CampaignPlan,
    PlanActivity,
    AnalysisReport,
    StrategicDecision,
    AuditEntry,
)
from .forms import (
    BrandForm,
    EventForm,
    EconomicForm,
    PlanForm,
    ActivityForm,
    ClassificationForm,
    DecisionForm,
    AnalysisFileForm,
    BreakEvenForm,
)
from .services.kpis import dashboard, advertising, ratio
from .services.monitoring import monitoring
from .services.business import (
    economics,
    automatic_report,
    suggestions,
    data_fingerprint,
)


class ScopeForm(forms.Form):
    platform = forms.ChoiceField(
        label="Fonte presente nell’evento",
        choices=[
            ("", "Tutte"),
            ("meta", "Meta Ads"),
            ("eventbrite", "Eventbrite"),
            ("partiful", "Partiful"),
            ("dice", "DICE"),
        ],
        required=False,
    )
    brand = forms.ModelChoiceField(
        label="Brand", queryset=Brand.objects.all(), required=False
    )
    event = forms.ModelChoiceField(
        label="Evento", queryset=Event.objects.select_related("brand"), required=False
    )
    format = forms.ModelChoiceField(
        label="Format", queryset=Format.objects.all(), required=False
    )
    start = forms.DateField(
        label="Data evento dal",
        required=False,
        widget=forms.DateInput(attrs={"type": "date"}),
    )
    end = forms.DateField(
        label="Data evento al",
        required=False,
        widget=forms.DateInput(attrs={"type": "date"}),
    )

    def clean(self):
        values = super().clean()
        if (
            values.get("start")
            and values.get("end")
            and values["start"] > values["end"]
        ):
            raise ValidationError("Intervallo date invertito.")
        return values


class CreativeScopeForm(ScopeForm):
    media_format = forms.ChoiceField(
        label="Formato confermato",
        choices=[("", "Tutti")]
        + list(CreativeClassification._meta.get_field("media_format").choices),
        required=False,
    )
    communication_type = forms.ChoiceField(
        label="Tipologia confermata",
        choices=[("", "Tutte")]
        + list(CreativeClassification._meta.get_field("communication_type").choices),
        required=False,
    )
    phase = forms.ChoiceField(
        label="Fase confermata",
        choices=[("", "Tutte")]
        + list(CreativeClassification._meta.get_field("phase").choices),
        required=False,
    )
    objective = forms.ChoiceField(
        label="Obiettivo confermato",
        choices=[("", "Tutti")]
        + list(CreativeClassification._meta.get_field("objective").choices),
        required=False,
    )


def scope(request, form_class=ScopeForm):
    form = form_class(request.GET)
    events = Event.objects.select_related("brand", "format")
    if form.is_valid():
        d = form.cleaned_data
        for field in ("brand", "format"):
            if d.get(field):
                events = events.filter(**{field: d[field]})
        if d.get("platform"):
            events = events.filter(
                imports__source=d["platform"], imports__status="confirmed"
            ).distinct()
        if d.get("event"):
            events = events.filter(pk=d["event"].pk)
        if d.get("start"):
            events = events.filter(date__gte=d["start"])
        if d.get("end"):
            events = events.filter(date__lte=d["end"])
    else:
        events = events.none()
    return form, events


class SecurePage(LoginRequiredMixin, PermissionRequiredMixin, View):
    permission_required = "core.view_event"


def require(user, permission):
    if not user.has_perm("core." + permission):
        raise PermissionDenied


class Overview(SecurePage):
    def get(self, request):
        filters, events = scope(request)
        rows = [dict(event=e, **dashboard(e)) for e in events]
        alerts = []
        for row in rows:
            event = row["event"]
            k = row["kpis"]
            if k["spend"] is not None and k["spend"] > 0 and k["clicks"] == 0:
                alerts.append(
                    {"event": event, "message": "Spesa registrata senza clic sul link."}
                )
            if (
                k["spend"] is not None
                and event.planned_budget is not None
                and k["spend"] > event.planned_budget
            ):
                alerts.append(
                    {
                        "event": event,
                        "message": "Budget pubblicitario previsto superato.",
                    }
                )
            if row["order_count"] is None and row["registrations"] is None and not row["conversions"]["total_actions"]:
                alerts.append(
                    {
                        "event": event,
                        "message": "Risultati commerciali non ancora disponibili.",
                    }
                )
        ads = list(
            AdObservation.objects.filter(
                batch__event__in=events, batch__status="confirmed"
            )
        )
        dates = defaultdict(Decimal)
        for row in ads:
            if row.period_start == row.period_end:
                dates[row.period_start.isoformat()] += row.spend
        chart = [
            {"label": day, "value": float(value)}
            for day, value in sorted(dates.items())
        ]
        totals = dict(
            events=len(rows),
            kpis=advertising(ads),
            orders=sum(r["order_count"] for r in rows if r["order_count"] is not None),
            tickets=sum(r["tickets"] for r in rows if r["tickets"] is not None),
            gross=sum((r["gross"] for r in rows if r["gross"] is not None), Decimal(0)),
            registrations=sum(
                r["registrations"] for r in rows if r["registrations"] is not None
            ),
            commercial_events=sum(
                r["order_count"] is not None or r["registrations"] is not None
                for r in rows
            ),
        )
        totals['conversions']={key:sum(r['conversions'][key] for r in rows) for key in
            ('ticket_paid','ticket_free','ticket_unclassified','rsvp','free_registration','orders','contact_rows','total_actions')}
        totals['conversions']['marketing_granted_contacts']=None
        totals['conversions']['has_data']=any(r['conversions']['has_data'] for r in rows)
        totals['conversions']['potential_overlap']=any(r['conversions']['potential_overlap'] for r in rows)
        count=totals['conversions']['total_actions']
        totals['conversions']['cost_per_action']=totals['kpis']['spend']/count if count and totals['kpis']['spend'] is not None else None
        return render(
            request,
            "workspace/overview.html",
            dict(
                monitoring=monitoring(rows),
                alerts=alerts[:10],
                filters=filters,
                rows=rows,
                totals=totals,
                chart=chart,
                has_aggregate=any(r.period_start != r.period_end for r in ads),
            ),
        )


class Brands(SecurePage):
    def get(self, request):
        return render(
            request,
            "workspace/brands.html",
            {"brands": Brand.objects.all(), "form": BrandForm()},
        )

    def post(self, request):
        require(request.user, "add_brand")
        form = BrandForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse("brands"))
        return render(
            request,
            "workspace/brands.html",
            {"brands": Brand.objects.all(), "form": form},
        )


class EventEdit(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    permission_required = "core.change_event"
    model = Event
    form_class = EventForm
    template_name = "workspace/edit.html"

    @transaction.atomic
    def form_valid(self, form):
        if not form.has_changed():
            return HttpResponseRedirect(self.get_success_url())
        before = {
            f: str(getattr(Event.objects.get(pk=self.object.pk), f))
            for f in form.changed_data
        }
        response = super().form_valid(form)
        AuditEntry.objects.create(
            actor=self.request.user,
            event=self.object,
            action="event.updated",
            details={"before": before},
        )
        automatic_report(self.object)
        return response

    def get_success_url(self):
        return reverse("event-detail", args=[self.object.pk])


class ImportCenter(SecurePage):
    permission_required = ("core.view_event", "core.view_importbatch")

    def get(self, request):
        from .universal_views import CenterUploadForm
        from .models import ImportDocument
        filters, events = scope(request)
        if request.GET.get("begin"):
            selected = events.filter(pk=request.GET.get("event")).first() if request.GET.get("event") else None
            source = request.GET.get("source")
            if selected and source in {"meta", "eventbrite", "partiful", "dice"}:
                return HttpResponseRedirect(reverse("import-upload", args=[selected.pk]) + "?source=" + source)

        return render(
            request,
            "workspace/imports.html",
            dict(
                filters=filters,
                events=events,
                upload_form=CenterUploadForm(events=events),
                documents=ImportDocument.objects.filter(event__in=events).select_related('event','batch').order_by('-created_at')[:200],
                imports=ImportBatch.objects.filter(event__in=events)
                .select_related("event")
                .order_by("-created_at")[:200],
            ),
        )

    def post(self,request):
        require(request.user,'add_importbatch')
        from .universal_views import CenterUploadForm,start_documents
        filters,events=scope(request)
        form=CenterUploadForm(request.POST,request.FILES,events=events)
        if form.is_valid(): return start_documents(request,form.cleaned_data['event'],form.cleaned_data['file'])
        messages.error(request,'Verifica evento e file: '+str(form.errors.as_text()))
        return HttpResponseRedirect(reverse('imports'))


class Creatives(SecurePage):
    permission_required = ("core.view_event", "core.view_creativeclassification")

    def get(self, request):
        filters, events = scope(request, CreativeScopeForm)
        observations = AdObservation.objects.filter(
            batch__event__in=events, batch__status="confirmed"
        )
        groups = defaultdict(list)
        for row in observations:
            if row.extra_metrics.get('level') == 'campaign': continue
            groups[row.source_key].append(row)
        saved = {
            r.source_key: r
            for r in CreativeClassification.objects.filter(source_key__in=groups)
        }
        rows = [
            dict(
                key=key,
                name=items[0].creative_name,
                metrics=advertising(items),
                classification=saved.get(key),
                suggestion=", ".join(
                    {
                        "video": "Video",
                        "image": "Immagine",
                        "carousel": "Carosello",
                        "teaser": "Teaser",
                        "preview": "Preview",
                        "poster": "Locandina",
                        "aftermovie": "Aftermovie",
                        "reminder": "Reminder",
                        "lineup": "Line-up",
                    }.get(value, value)
                    for value in suggestions(items[0].creative_name).values()
                ),
                count=len({r.batch.event_id for r in items}),
            )
            for key, items in groups.items()
        ]
        if filters.is_valid():
            for field in ("media_format", "communication_type", "phase", "objective"):
                selected = filters.cleaned_data.get(field)
                if selected:
                    rows = [
                        r
                        for r in rows
                        if r["classification"]
                        and getattr(r["classification"], field) == selected
                    ]
        return render(
            request, "workspace/creatives.html", dict(filters=filters, rows=rows)
        )


class Classify(SecurePage):
    def get(self, request, key):
        require(request.user, "change_creativeclassification")
        row = (
            AdObservation.objects.filter(source_key=key, batch__status="confirmed")
            .order_by("pk")
            .first()
        )
        if row is None:
            from django.http import Http404

            raise Http404
        saved = CreativeClassification.objects.filter(source_key=key).first()
        form = ClassificationForm(
            instance=saved,
            initial=suggestions(row.creative_name) if not saved else None,
        )
        return render(
            request, "workspace/classify.html", dict(form=form, row=row, saved=saved)
        )

    @transaction.atomic
    def post(self, request, key):
        require(request.user, "change_creativeclassification")
        row = AdObservation.objects.filter(
            source_key=key, batch__status="confirmed"
        ).first()
        if row is None:
            from django.http import Http404

            raise Http404
        saved = (
            CreativeClassification.objects.select_for_update()
            .filter(source_key=key)
            .first()
        )
        before = (
            {f: getattr(saved, f) for f in ClassificationForm.Meta.fields}
            if saved
            else {}
        )
        if request.FILES:
            try:
                raw = request.FILES["file"].read(20001)
                if len(raw) > 20000:
                    raise ValueError
                payload = json.loads(raw)
                if payload.pop("source_key") != key or set(payload) != set(
                    ClassificationForm.Meta.fields
                ):
                    raise ValueError
                form = ClassificationForm(payload, instance=saved)
                if not form.is_valid():
                    raise ValueError
                messages.info(
                    request,
                    "Classificazione esterna caricata come proposta. Verifica i campi e conferma; nessun dato ancora salvato.",
                )
                return render(
                    request,
                    "workspace/classify.html",
                    dict(form=form, row=row, saved=saved, external=True),
                )
            except (
                ValueError,
                KeyError,
                TypeError,
                AttributeError,
                UnicodeDecodeError,
            ):
                form = ClassificationForm(instance=saved)
                form.add_error(
                    None,
                    "JSON non valido: usare source_key e i quattro campi di classificazione con valori ammessi.",
                )
                return render(
                    request,
                    "workspace/classify.html",
                    dict(form=form, row=row, saved=saved),
                )
        form = ClassificationForm(request.POST, instance=saved)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.source_key = key
            obj.name = row.creative_name
            obj.confirmed_by = request.user
            obj.full_clean()
            obj.save()
            AuditEntry.objects.create(
                actor=request.user,
                event=row.batch.event,
                action="creative.classified",
                details={
                    "key": key,
                    "before": before,
                    "after": form.cleaned_data,
                    "provenance": "external_reviewed"
                    if request.POST.get("external")
                    else "manual_or_rules_reviewed",
                },
            )
            for event in Event.objects.filter(
                imports__ad_observations__source_key=key, imports__status="confirmed"
            ).distinct():
                automatic_report(event)
            return HttpResponseRedirect(reverse("creatives"))
        return render(
            request, "workspace/classify.html", dict(form=form, row=row, saved=saved)
        )


class Economy(SecurePage):
    permission_required = ("core.view_event", "core.view_economicentry")

    def get(self, request):
        filters, events = scope(request)
        return render(
            request,
            "workspace/economy.html",
            dict(
                filters=filters,
                rows=[
                    dict(
                        event=e,
                        break_even_form=BreakEvenForm(instance=e),
                        **economics(e),
                    )
                    for e in events
                ],
            ),
        )


class CostCreate(SecurePage):
    def get(self, request, pk):
        require(request.user, "add_economicentry")
        return render(
            request,
            "workspace/edit.html",
            dict(
                form=EconomicForm(),
                event=get_object_or_404(Event, pk=pk),
                title="Aggiungi costo o entrata",
            ),
        )

    @transaction.atomic
    def post(self, request, pk):
        require(request.user, "add_economicentry")
        event = get_object_or_404(Event, pk=pk)
        form = EconomicForm(request.POST)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.event = event
            obj.created_by = request.user
            obj.save()
            AuditEntry.objects.create(
                actor=request.user,
                event=event,
                action="economy.created",
                details={"entry": str(obj.pk), "amount": str(obj.amount)},
            )
            automatic_report(event)
            return HttpResponseRedirect(reverse("economy") + "?event=" + str(pk))
        return render(
            request,
            "workspace/edit.html",
            dict(form=form, event=event, title="Aggiungi costo o entrata"),
        )


class CostEdit(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    permission_required = "core.change_economicentry"
    model = EconomicEntry
    form_class = EconomicForm
    template_name = "workspace/edit.html"

    @transaction.atomic
    def form_valid(self, form):
        if not form.has_changed():
            return HttpResponseRedirect(self.get_success_url())
        before = EconomicEntry.objects.get(pk=self.object.pk)
        details = {f: str(getattr(before, f)) for f in form.changed_data}
        result = super().form_valid(form)
        AuditEntry.objects.create(
            actor=self.request.user,
            event=self.object.event,
            action="economy.updated",
            details={"entry": str(self.object.pk), "before": details},
        )
        automatic_report(self.object.event)
        return result

    def get_success_url(self):
        return reverse("economy") + "?event=" + str(self.object.event_id)


class CostsComplete(SecurePage):
    @transaction.atomic
    def post(self, request, pk):
        require(request.user, "change_event")
        event = get_object_or_404(Event.objects.select_for_update(), pk=pk)
        event.costs_complete = request.POST.get("complete") == "yes"
        event.save(update_fields=["costs_complete", "updated_at"])
        AuditEntry.objects.create(
            actor=request.user,
            event=event,
            action="economy.completeness",
            details={"complete": event.costs_complete},
        )
        automatic_report(event)
        return HttpResponseRedirect(reverse("economy") + "?event=" + str(pk))


class Planning(SecurePage):
    permission_required = ("core.view_event", "core.view_campaignplan")

    def get(self, request):
        filters, events = scope(request)
        rows = []
        for plan in (
            CampaignPlan.objects.filter(event__in=events)
            .select_related("event")
            .prefetch_related("activities")
        ):
            actual = dashboard(plan.event)["kpis"]["spend"]
            previous = Event.objects.filter(
                brand=plan.event.brand, date__lt=plan.event.date, mode=plan.event.mode
            )
            historical = advertising(
                list(
                    AdObservation.objects.filter(
                        batch__event__in=previous, batch__status="confirmed"
                    )
                )
            )
            rows.append(
                dict(
                    plan=plan,
                    historical_cpc=historical["cpc"],
                    click_scenario=ratio(plan.budget, plan.target_cpc),
                    actual=actual,
                    variance=actual - plan.budget if actual is not None else None,
                )
            )
        return render(
            request,
            "workspace/planning.html",
            dict(filters=filters, events=events, rows=rows),
        )


class PlanCreate(SecurePage):
    def get(self, request, pk):
        require(request.user, "add_campaignplan")
        return render(
            request,
            "workspace/edit.html",
            dict(
                form=PlanForm(),
                event=get_object_or_404(Event, pk=pk),
                title="Nuovo piano campagna",
            ),
        )

    @transaction.atomic
    def post(self, request, pk):
        require(request.user, "add_campaignplan")
        event = get_object_or_404(Event, pk=pk)
        form = PlanForm(request.POST)
        if form.is_valid():
            plan = form.save(commit=False)
            plan.event = event
            plan.created_by = request.user
            plan.save()
            AuditEntry.objects.create(
                actor=request.user,
                event=event,
                action="plan.created",
                details={"plan": str(plan.pk)},
            )
            return HttpResponseRedirect(reverse("planning") + "?event=" + str(pk))
        return render(
            request,
            "workspace/edit.html",
            dict(form=form, event=event, title="Nuovo piano campagna"),
        )


class ActivityCreate(SecurePage):
    def get(self, request, pk):
        require(request.user, "add_planactivity")
        return render(
            request,
            "workspace/edit.html",
            dict(
                form=ActivityForm(),
                title="Attività del piano",
                plan=get_object_or_404(CampaignPlan, pk=pk),
            ),
        )

    def post(self, request, pk):
        require(request.user, "add_planactivity")
        plan = get_object_or_404(CampaignPlan, pk=pk)
        form = ActivityForm(request.POST)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.plan = plan
            obj.save()
            return HttpResponseRedirect(
                reverse("planning") + "?event=" + str(plan.event_id)
            )
        return render(
            request,
            "workspace/edit.html",
            dict(form=form, title="Attività del piano", plan=plan),
        )


class Reflections(SecurePage):
    permission_required = ("core.view_event", "core.view_analysisreport")

    def get(self, request):
        filters, events = scope(request)
        reports = list(
            AnalysisReport.objects.filter(event__in=events).select_related("event")[
                :100
            ]
        )
        fingerprints = {e.pk: data_fingerprint(e) for e in events}
        for report in reports:
            report.stale = report.fingerprint != fingerprints[report.event_id]
        from .services.generative_ai import configuration, ERRORS

        config = configuration()
        ai_status = ERRORS.get(
            config["reason"], "Configurata e autorizzata; elaborazione tramite worker."
        )
        if config.get("provider") == "ollama":
            ai_status = "Ollama locale, nessun servizio cloud. " + (
                "Controlla le Impostazioni locali se il modello non è pronto."
            )
        jobs = list(
            AIJob.objects.filter(event__in=events)
            .select_related("event")
            .order_by("-created_at")[:100]
        )
        for job in jobs:
            job.message = ERRORS.get(job.error_code, "")
            if config.get("provider") == "ollama":
                job.message = {
                    "worker_interrupted": "Worker locale interrotto. Puoi riprovare senza costi; l’analisi a regole resta disponibile.",
                    "daily_limit": "Limite di analisi locali raggiunto per oggi.",
                    "configuration_missing": "Configurare il modello Ollama locale nelle impostazioni.",
                }.get(job.error_code, job.message)
        return render(
            request,
            "workspace/reflections.html",
            dict(
                local_ai=config.get("provider") == "ollama",
                ai_jobs=jobs,
                ai_status=ai_status,
                filters=filters,
                events=events,
                reports=reports,
                decisions=StrategicDecision.objects.filter(
                    event__in=events
                ).select_related("event")[:100],
            ),
        )


class Analyze(SecurePage):
    def post(self, request, pk):
        require(request.user, "add_analysisreport")
        automatic_report(get_object_or_404(Event, pk=pk))
        return HttpResponseRedirect(reverse("reflections") + "?event=" + str(pk))


class DecisionCreate(SecurePage):
    def get(self, request, pk):
        require(request.user, "add_strategicdecision")
        return render(
            request,
            "workspace/edit.html",
            dict(
                form=DecisionForm(),
                event=get_object_or_404(Event, pk=pk),
                title="Registra decisione o esperimento",
            ),
        )

    def post(self, request, pk):
        require(request.user, "add_strategicdecision")
        event = get_object_or_404(Event, pk=pk)
        form = DecisionForm(request.POST)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.event = event
            obj.created_by = request.user
            obj.save()
            return HttpResponseRedirect(reverse("reflections") + "?event=" + str(pk))
        return render(
            request,
            "workspace/edit.html",
            dict(form=form, event=event, title="Registra decisione o esperimento"),
        )


class AnalysisExport(SecurePage):
    def get(self, request, pk):
        require(request.user, "view_analysisreport")
        event = get_object_or_404(Event, pk=pk)
        fingerprint = data_fingerprint(event)
        report = AnalysisReport.objects.filter(
            event=event, fingerprint=fingerprint, kind="rules"
        ).first()
        template = (
            report.body
            if report
            else {
                key: []
                for key in (
                    "summary",
                    "performance",
                    "worked",
                    "attention",
                    "creatives",
                    "previous_events",
                    "anomalies",
                    "limits",
                    "recommendations",
                    "actions",
                    "experiments",
                    "priorities",
                )
            }
        )
        payload = {
            "event_id": str(event.pk),
            "fingerprint": fingerprint,
            "metrics": dashboard(event),
            "instructions": "Non inventare dati o attribuzioni. Restituisci event_id, fingerprint e sections (le stesse chiavi del template), con elenchi di stringhe. Testo interpretativo esterno da verificare.",
            "template": template,
        }
        response = JsonResponse(payload, encoder=DjangoJSONEncoder)
        response["Content-Disposition"] = (
            'attachment; filename="analisi-aggregata.json"'
        )
        return response


class AnalysisImport(SecurePage):
    def get(self, request, pk):
        require(request.user, "add_analysisreport")
        return render(
            request,
            "workspace/edit.html",
            dict(
                form=AnalysisFileForm(),
                event=get_object_or_404(Event, pk=pk),
                title="Importa riflessione AI esterna",
            ),
        )

    @transaction.atomic
    def post(self, request, pk):
        require(request.user, "add_analysisreport")
        event = get_object_or_404(Event.objects.select_for_update(), pk=pk)
        form = AnalysisFileForm(request.POST, request.FILES)
        if form.is_valid():
            try:
                raw = form.cleaned_data["file"].read(200001)
                if len(raw) > 200000:
                    raise ValueError("Report massimo 200 KB.")
                data = json.loads(raw)
                fingerprint = data_fingerprint(event)
                if (
                    data.get("event_id") != str(pk)
                    or data.get("fingerprint") != fingerprint
                ):
                    raise ValueError(
                        "Evento o versione dati non corrispondente. Esportare nuovamente i dati."
                    )
                body = data["sections"]
                from .services.generative_ai import SECTIONS

                expected = SECTIONS
                if not isinstance(body, dict) or set(body) != set(expected):
                    raise ValueError("Sezioni mancanti o sconosciute.")
                if any(
                    not isinstance(v, list)
                    or len(v) > 20
                    or any(not isinstance(t, str) or len(t) > 2000 for t in v)
                    for v in body.values()
                ):
                    raise ValueError(
                        "Ogni sezione richiede un elenco di massimo 20 testi brevi."
                    )
                obj, created = AnalysisReport.objects.get_or_create(
                    event=event,
                    fingerprint=fingerprint,
                    kind="imported_ai",
                    defaults={
                        "body": body,
                        "created_by": request.user,
                        "source_note": "Report esterno dichiarato AI; contenuto interpretativo non verificato automaticamente.",
                    },
                )
                if not created:
                    raise ValueError(
                        "Esiste già un report esterno per questa versione; nessun contenuto sovrascritto."
                    )
                return HttpResponseRedirect(
                    reverse("reflections") + "?event=" + str(pk)
                )
            except (
                ValueError,
                KeyError,
                TypeError,
                AttributeError,
                UnicodeDecodeError,
            ):
                form.add_error(
                    None,
                    "Report non valido, duplicato o riferito a dati superati. Usare lo schema del file esportato.",
                )
        return render(
            request,
            "workspace/edit.html",
            dict(form=form, event=event, title="Importa riflessione AI esterna"),
        )


class NormalizedTemplate(SecurePage):
    def get(self, request, platform):
        from django.http import HttpResponse, Http404

        headers = {
            "partiful": "platform,registration_id,event_id,status,guests\n",
            "dice": "platform,order_id,event_id,order status,quantity,gross sales,currency,platform fees,refunds\n",
        }
        if platform not in headers:
            raise Http404
        response = HttpResponse(
            headers[platform], content_type="text/csv; charset=utf-8"
        )
        response["Content-Disposition"] = (
            f'attachment; filename="{platform}-tracciato-normalizzato.csv"'
        )
        return response


class DomainUpdate(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    template_name = "workspace/edit.html"

    @transaction.atomic
    def form_valid(self, form):
        if not form.has_changed():
            return HttpResponseRedirect(self.get_success_url())
        previous = self.model.objects.get(pk=self.object.pk)
        before = {f: str(getattr(previous, f)) for f in form.changed_data}
        response = super().form_valid(form)
        event = (
            self.object.plan.event
            if isinstance(self.object, PlanActivity)
            else self.object.event
        )
        AuditEntry.objects.create(
            actor=self.request.user,
            event=event,
            action=self.model._meta.model_name + ".updated",
            details={"object": str(self.object.pk), "before": before},
        )
        return response


class PlanEdit(DomainUpdate):
    permission_required = "core.change_campaignplan"
    model = CampaignPlan
    form_class = PlanForm

    def get_success_url(self):
        return reverse("planning") + "?event=" + str(self.object.event_id)


class ActivityEdit(DomainUpdate):
    permission_required = "core.change_planactivity"
    model = PlanActivity
    form_class = ActivityForm

    def get_success_url(self):
        return reverse("planning") + "?event=" + str(self.object.plan.event_id)


class DecisionEdit(DomainUpdate):
    permission_required = "core.change_strategicdecision"
    model = StrategicDecision
    form_class = DecisionForm

    def get_success_url(self):
        return reverse("reflections") + "?event=" + str(self.object.event_id)


class BreakEvenSettings(SecurePage):
    @transaction.atomic
    def post(self, request, pk):
        require(request.user, "change_event")
        event = get_object_or_404(Event.objects.select_for_update(), pk=pk)
        before = {key: str(getattr(event, key)) for key in BreakEvenForm.Meta.fields}
        form = BreakEvenForm(request.POST, instance=event)
        if form.is_valid():
            form.save()
            AuditEntry.objects.create(
                actor=request.user,
                event=event,
                action="economy.scenario",
                details={"before": before},
            )
            return HttpResponseRedirect(reverse("economy") + "?event=" + str(pk))
        return render(
            request,
            "workspace/edit.html",
            dict(form=form, event=event, title="Ipotesi break-even"),
        )


class AIRetry(SecurePage):
    def post(self, request, pk):
        require(request.user, "change_aijob")
        job = get_object_or_404(AIJob, pk=pk)
        from .services.generative_ai import retry, configuration

        if (
            job.status == "uncertain"
            and configuration()["provider"] != "ollama"
            and request.POST.get("acknowledge") != "yes"
        ):
            messages.error(
                request,
                "Verificare prima il consumo remoto e confermare il nuovo tentativo.",
            )
        else:
            try:
                retry(job)
                AuditEntry.objects.create(
                    actor=request.user,
                    event=job.event,
                    action="ai.retry_requested",
                    details={"job": str(job.pk)},
                )
                messages.success(
                    request,
                    "Nuovo tentativo messo in coda. Nessuna esecuzione nel processo web.",
                )
            except ValueError as exc:
                messages.error(request, str(exc))
        return HttpResponseRedirect(
            reverse("reflections") + "?event=" + str(job.event_id)
        )
