// Accessible current-section marker, no external scripts or tracking.
const path=window.location.pathname;
document.querySelectorAll('.main-nav a').forEach(link=>{
 const target=new URL(link.href).pathname;
 if((target==='/'&&(path==='/'||path==='/dashboard/'))||(target!=='/'&&path.startsWith(target)))link.setAttribute('aria-current','page');
});
