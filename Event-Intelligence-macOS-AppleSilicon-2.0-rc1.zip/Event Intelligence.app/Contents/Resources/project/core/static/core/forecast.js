// Server-authoritative Decimal calculations; no financial arithmetic in JavaScript.
const forecastForm=document.querySelector('.forecast-form');
if(forecastForm){
 let timer,controller,sequence=0;
 const output=document.getElementById('forecast-preview');
 const format=value=>value===null?'Non disponibile':new Intl.NumberFormat('it-IT',{minimumFractionDigits:2,maximumFractionDigits:2}).format(Number(value));
 async function refresh(){
  const current=++sequence;if(controller)controller.abort();controller=new AbortController();
  if(!forecastForm.checkValidity()){output.textContent='Completa correttamente tutti i campi per ricalcolare.';return;}
  try{
   const response=await fetch(forecastForm.dataset.previewUrl,{method:'POST',body:new FormData(forecastForm),signal:controller.signal,headers:{'X-Requested-With':'XMLHttpRequest'}});
   const data=await response.json();if(current!==sequence)return;
   output.replaceChildren();
   if(!response.ok){output.textContent=Object.values(data.errors||{}).flat().map(e=>e.message).join(' ');return;}
   data.scenarios.forEach(row=>{const p=document.createElement('p');p.textContent=`${row.name}: ${row.quantity} unità · ricavi ${format(row.revenue)} € · costi ${format(row.costs)} € · margine ${format(row.margin)} €`;output.append(p);});
   const p=document.createElement('p');p.textContent=`Pareggio: ${data.breakeven===null?'non determinabile':data.breakeven+' unità'}.`;output.append(p);
  }catch(error){if(error.name!=='AbortError'&&current===sequence)output.textContent='Ricalcolo non disponibile. Puoi salvare per ottenere il calcolo completo.';}
 }
 forecastForm.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(refresh,300);});refresh();
}
