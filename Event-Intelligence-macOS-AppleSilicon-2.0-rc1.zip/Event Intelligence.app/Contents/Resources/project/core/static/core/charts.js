// Local, dependency-free, accessible bar chart from deterministic server aggregates.
document.querySelectorAll('[data-chart]').forEach(container => {
 const node=document.getElementById(container.dataset.chart);
 const data=JSON.parse(node.textContent); const max=Math.max(...data.map(r=>r.value),1);
 data.forEach(row=>{
  const line=document.createElement('div');line.className='chart-row';
  const label=document.createElement('span');label.textContent=new Intl.DateTimeFormat('it-IT').format(new Date(row.label+'T12:00:00Z'));
  const bar=document.createElement('div');bar.className='chart-bar';bar.style.width=(row.value/max*100)+'%';
  const value=document.createElement('span');value.textContent=new Intl.NumberFormat('it-IT',{style:'currency',currency:'EUR'}).format(row.value);
  line.tabIndex=0;line.setAttribute('aria-label',label.textContent+': '+value.textContent);line.title=label.textContent+': '+value.textContent;line.append(label,bar,value);container.append(line);
 });
});
