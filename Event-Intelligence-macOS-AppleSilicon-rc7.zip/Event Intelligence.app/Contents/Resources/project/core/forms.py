from django import forms
from .models import Event, ImportBatch


class EventForm(forms.ModelForm):
    class Meta:
        model = Event
        fields = [
            "name",
            "brand",
            "format",
            "date",
            "location",
            "mode",
            "planned_budget",
            "checkin_enabled",
        ]
        widgets = {"date": forms.DateInput(attrs={"type": "date"})}


class MultipleFileInput(forms.ClearableFileInput):
    allow_multiple_selected = True


class MultipleFileField(forms.FileField):
    def clean(self, data, initial=None):
        files = data if isinstance(data, (list, tuple)) else [data]
        return [super(MultipleFileField, self).clean(file, initial) for file in files]


class ImportForm(forms.Form):
    source = forms.ChoiceField(
        label="Fonte dei file", required=False,
        choices=[("", "Analisi automatica · nessuna piattaforma obbligatoria"), ("meta", "Meta Ads"),
                 ("eventbrite", "Eventbrite"), ("partiful", "Partiful"), ("dice", "DICE")],
        help_text="Tutti i file di questo caricamento devono appartenere alla fonte scelta.",
    )
    replaces = forms.ModelChoiceField(
        label="Sostituisci un report precedente (facoltativo)",
        queryset=ImportBatch.objects.none(),
        required=False,
        help_text="Solo un file sostitutivo completo. Il precedente resta attivo fino alla conferma atomica.",
    )

    def __init__(self, *args, event=None, **kwargs):
        super().__init__(*args, **kwargs)
        if event:
            from .models import ImportBatch

            self.fields["replaces"].queryset = ImportBatch.objects.filter(
                event=event, status="confirmed"
            ).order_by("-created_at")

    def clean(self):
        data = super().clean()
        if len(data.get("file", [])) > 10:
            self.add_error("file", "Seleziona al massimo 10 file per caricamento.")
        if data.get("replaces") and len(data.get("file", [])) != 1:
            self.add_error(
                "replaces", "Per sostituire un report selezionare un solo file."
            )
        return data

    file = MultipleFileField(
        label="File della fonte selezionata",
        widget=MultipleFileInput(attrs={"accept": ".csv,.xls,.xlsx"}),
    )


from .models import (
    Brand,
    EconomicEntry,
    CampaignPlan,
    PlanActivity,
    CreativeClassification,
    StrategicDecision,
)


class BrandForm(forms.ModelForm):
    class Meta:
        model = Brand
        fields = ["name"]
        labels = {"name": "Nome brand"}


class EconomicForm(forms.ModelForm):
    class Meta:
        model = EconomicEntry
        fields = ["category", "description", "amount", "basis"]


class PlanForm(forms.ModelForm):
    class Meta:
        model = CampaignPlan
        fields = ["title", "objective", "budget", "target_cpc", "assumptions"]

    def clean(self):
        data = super().clean()
        if data.get("target_cpc") and not data.get("assumptions"):
            self.add_error(
                "assumptions", "Descrivere le ipotesi prima di creare uno scenario."
            )
        return data


class ActivityForm(forms.ModelForm):
    class Meta:
        model = PlanActivity
        fields = ["title", "date", "phase", "done"]
        widgets = {"date": forms.DateInput(attrs={"type": "date"})}


class ClassificationForm(forms.ModelForm):
    class Meta:
        model = CreativeClassification
        fields = ["media_format", "communication_type", "phase", "objective"]


class DecisionForm(forms.ModelForm):
    class Meta:
        model = StrategicDecision
        fields = ["kind", "description", "status", "outcome"]


class AnalysisFileForm(forms.Form):
    file = forms.FileField(
        label="Report AI esterno JSON",
        widget=forms.ClearableFileInput(attrs={"accept": ".json"}),
    )


class BreakEvenForm(forms.ModelForm):
    class Meta:
        model = Event
        fields = [
            "break_even_net_price",
            "break_even_variable_cost",
            "break_even_fixed_confirmed",
        ]

    def clean(self):
        data = super().clean()
        price = data.get("break_even_net_price")
        variable = data.get("break_even_variable_cost")
        if (price is None) != (variable is None):
            raise forms.ValidationError(
                "Indicare entrambi gli importi oppure lasciarli entrambi vuoti."
            )
        return data
