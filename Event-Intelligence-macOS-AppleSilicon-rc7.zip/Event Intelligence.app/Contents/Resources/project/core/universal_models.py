"""Additive import provenance and consent-aware contact/event relationships."""
import uuid
from django.conf import settings
from django.db import models
from .models import Record, Event, ImportBatch


def private_document(instance, filename):
    from pathlib import Path
    return 'documents/' + str(uuid.uuid4()) + Path(filename).suffix.lower()


class ImportDocument(Record):
    event = models.ForeignKey(Event,on_delete=models.PROTECT,related_name='documents')
    file = models.FileField(upload_to=private_document)
    filename = models.CharField(max_length=255)
    sha256 = models.CharField(max_length=64)
    mapping = models.JSONField(default=dict)
    options = models.JSONField(default=dict)
    diagnostics = models.JSONField(default=dict)
    batch = models.OneToOneField(ImportBatch,on_delete=models.PROTECT,null=True,blank=True,related_name='document')
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.PROTECT)
    class Meta:
        constraints=[models.UniqueConstraint(fields=['event','sha256'],name='document_event_hash')]


class MappingProfile(Record):
    signature = models.CharField(max_length=64,unique=True)
    mapping = models.JSONField(default=dict)
    kind = models.CharField(max_length=24)
    confirmed_by = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.PROTECT)


class Contact(Record):
    email = models.EmailField(blank=True,max_length=254)
    email_key = models.CharField(max_length=64,null=True,unique=True)
    full_name = models.CharField(max_length=255,blank=True)
    first_name = models.CharField(max_length=160,blank=True)
    last_name = models.CharField(max_length=160,blank=True)

    @property
    def marketing_consent(self):
        if self.records.filter(consent='denied').exists(): return 'denied'
        values=set(self.records.filter(batch__status='confirmed').values_list('consent',flat=True))
        return 'granted' if 'granted' in values else 'unknown'


class ParticipationRecord(Record):
    batch = models.ForeignKey(ImportBatch,on_delete=models.PROTECT,related_name='participations')
    contact = models.ForeignKey(Contact,on_delete=models.PROTECT,null=True,blank=True,related_name='records')
    source_row = models.PositiveIntegerField()
    kind = models.CharField(max_length=24)
    status = models.CharField(max_length=24,default='unknown')
    quantity = models.PositiveIntegerField(default=1)
    external_id = models.CharField(max_length=255,blank=True)
    consent = models.CharField(max_length=12,default='unknown')
    checkin_count = models.PositiveIntegerField(null=True)
    evidence = models.JSONField(default=dict)  # Local provenance; never sent to the AI.
    class Meta:
        constraints=[models.UniqueConstraint(fields=['batch','source_row'],name='participation_source_row')]
