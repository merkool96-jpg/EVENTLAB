from decimal import Decimal
from django import forms
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin,PermissionRequiredMixin
from django.core.exceptions import ValidationError
from django.shortcuts import get_object_or_404,render,redirect
from django.views import View
from .models import ImportDocument
from .services import universal as engine


class MappingForm(forms.Form):
    kind=forms.ChoiceField(label='Tipo di dati',choices=list(engine.KINDS.items()))
    sheet=forms.ChoiceField(label='Foglio')
    header_row=forms.IntegerField(label='Riga intestazioni',min_value=1,max_value=50)
    number_format=forms.ChoiceField(label='Formato numerico',required=False,choices=[('','Automatico, se non ambiguo'),('it','Migliaia punto · decimali virgola'),('en','Migliaia virgola · decimali punto')])
    no_header=forms.BooleanField(label='Il file non ha intestazioni: la prima riga contiene dati',required=False)
    origin=forms.CharField(label='Origine o descrizione (facoltativa)',required=False,max_length=60)
    currency=forms.ChoiceField(label='Valuta se non indicata nel file',required=False,choices=[('','Non indicata'),('EUR','EUR')])
    confirmed_list=forms.BooleanField(label='In assenza di stato, dichiaro che questa lista rappresenta conferme',required=False)
    overlap_ack=forms.BooleanField(label='Ho verificato le possibili sovrapposizioni: conteggio le azioni, non persone uniche',required=False)
    ambiguity_ack=forms.BooleanField(label='Ho verificato le associazioni ambigue o lasciate non associate',required=False)
    remember=forms.BooleanField(label='Ricorda queste associazioni per file con le stesse colonne',required=False)

    def __init__(self,*args,analysis,document,**kwargs):
        initial=dict(kind=analysis['kind'],sheet=analysis.get('sheet',''),header_row=analysis.get('header_row',0)+1,**{k:v for k,v in document.options.items() if k not in ('kind','sheet','header_row')})
        super().__init__(*args,initial=initial,**kwargs)
        self.initial['remember']=document.options.get('remember_requested',False)
        self.fields['sheet'].choices=[('', 'Seleziona il foglio')]+[(v,v) for v in analysis['sheets']]
        by_index={i:k for k,i in analysis['mapping'].items()}
        self.status_fields={}
        if 'status' in analysis['mapping']:
            index=analysis['mapping']['status']
            unknown={engine.norm(r[index]) for r in analysis['rows'] if index<len(r) and r[index] not in ('',None)} - engine.CONFIRMED - engine.CANCELLED
            for status in sorted(unknown)[:50]:
                import hashlib
                field='state_'+hashlib.sha256(status.encode()).hexdigest()[:12]
                self.status_fields[field]=status
                self.fields[field]=forms.ChoiceField(label='Significato dello stato: '+status[:100],required=False,
                    choices=[('unknown','Da chiarire'),('confirmed','Confermato'),('cancelled','Annullato / non confermato')],
                    initial=analysis.get('status_mapping',{}).get(status,'unknown'))
        choices=[('','Non associare · conserva nel file originale')]+sorted(engine.FIELDS.items(),key=lambda v:v[1])
        for i,h in enumerate(analysis['headers']):
            self.fields['col_'+str(i)]=forms.ChoiceField(label=f'{i+1}. {h or "Senza intestazione"}',required=False,choices=choices,initial=by_index.get(i,''))

    def clean(self):
        values=super().clean()
        selected=[v for k,v in values.items() if k.startswith('col_') and v]
        if len(selected)!=len(set(selected)): raise forms.ValidationError('Due colonne associate allo stesso campo: scegli quella corretta, senza sommarle.')
        return values


def preview(document,analysis):
    rows,warnings,overlap=engine.normalize(document,analysis)
    kind=analysis['kind']
    if kind in ('ads','campaigns'):
        _,_,data=engine.legacy.parse(engine.ad_upload(document,analysis,rows))
        return dict(valid_rows=len(data),conversions=None,spend=sum(Decimal(r['spend']) for r in data),
                    clicks=sum(r['clicks'] for r in data if r['clicks'] is not None),
                    warnings=warnings+['Celle vuote conservate come mancanti; clic mostrati sui valori presenti. ID mancanti: righe omonime non unite.'],overlap=False)
    confirmed=rows if kind in ('ads','campaigns') else [r for r in rows if r['status']=='confirmed']
    def total(key):
        values=[r['amounts'].get(key) for r in confirmed]
        return sum((Decimal(v) for v in values),Decimal(0)) if values and all(v is not None for v in values) else None
    return dict(valid_rows=len(rows),conversions=sum(r['quantity'] for r in confirmed) if kind not in ('contacts','guestlist','invited','ads','campaigns','checkin') else None,
                spend=total('spend') if kind in ('ads','campaigns') else None,confirmed_rows=len(confirmed),gross=total('gross'),ticket_revenue=total('ticket_revenue'),warnings=warnings,overlap=overlap)


class DocumentDetail(LoginRequiredMixin,PermissionRequiredMixin,View):
    permission_required=('core.view_importbatch','core.view_event')

    def get(self,request,pk): return self.handle(request,pk)
    def post(self,request,pk):
        if not request.user.has_perm('core.add_importbatch'):
            from django.core.exceptions import PermissionDenied
            raise PermissionDenied
        return self.handle(request,pk)

    def handle(self,request,pk):
        document=get_object_or_404(ImportDocument.objects.select_related('event','batch'),pk=pk)
        if request.method=='POST' and request.POST.get('action')=='revert' and document.batch_id:
            from .services.imports import revert
            try:
                revert(document.batch,request.user)
                messages.success(request,'Importazione annullata; storico e file conservati.')
            except ValidationError as exc: messages.error(request,' '.join(exc.messages))
            return redirect('document-detail',pk=document.pk)
        if request.method=='POST' and document.batch_id:
            if request.POST.get('action')=='reconfirm' and document.batch.status=='reverted':
                try:
                    if request.POST.get('overlap_ack'):
                        document.options['overlap_ack']=True;document.save(update_fields=['options'])
                    engine.confirm_document(document,request.user)
                    messages.success(request,'Contributo originale riattivato; associazioni e storico invariati.')
                except ValidationError as exc: messages.error(request,' '.join(exc.messages))
            else: messages.error(request,'Associazioni già nello storico: non vengono riscritte dopo la conferma.')
            return redirect('document-detail',pk=document.pk)
        if request.method=='POST' and request.POST.get('action')=='suggest_ai':
            from .services.mapping_ai import request_suggestions
            document.diagnostics['ai_mapping']=request_suggestions(document)
            document.save(update_fields=['diagnostics'])
            return redirect('document-detail',pk=document.pk)
        if request.method=='POST' and request.POST.get('action')=='apply_ai':
            task=document.diagnostics.get('ai_mapping',{})
            if document.batch_id: messages.error(request,'Associazioni storiche non modificabili dopo la conferma.')
            elif task.get('state')=='done':
                proposed=dict(engine.analyze(document)['mapping'])
                for item in task.get('mapping',[]):
                    if item['field'] not in proposed and item['column'] not in proposed.values():
                        proposed[item['field']]=item['column']
                document.mapping=proposed
                document.options.update(manual_mapping=True,mapping_reviewed=True,ai_applied=True)
                document.save(update_fields=['mapping','options','updated_at'])
                messages.info(request,'Proposta applicata alla sola anteprima. Verifica i campi prima della conferma finale.')
            return redirect('document-detail',pk=document.pk)
        analysis=engine.analyze(document)
        form=MappingForm(request.POST if request.method=='POST' else None,analysis=analysis,document=document)
        error=None;summary=None
        if request.method=='POST' and form.is_valid():
            try:
                if request.POST.get('action')=='revert' and document.batch_id:
                    from .services.imports import revert
                    revert(document.batch,request.user);messages.success(request,'Importazione annullata; dati e storico conservati.')
                    return redirect('document-detail',pk=document.pk)
                if document.batch_id and document.batch.status=='confirmed':
                    raise ValidationError('Importazione già confermata. Le associazioni storiche non vengono riscritte: annulla e verifica un nuovo documento.')
                values=form.cleaned_data
                mapping={v:int(k[4:]) for k,v in values.items() if k.startswith('col_') and v}
                old_options=dict(document.options)
                mapping_changed=mapping!=analysis['mapping'] or values['kind']!=analysis['kind']
                statuses={status:values.get(key) or 'unknown' for key,status in form.status_fields.items()}
                semantic_changed=(mapping_changed or values['sheet']!=analysis.get('sheet') or values['header_row']-1!=analysis.get('header_row')
                    or any(values[k] != old_options.get(k,False if k in ('confirmed_list','no_header') else '') for k in ('origin','currency','number_format','confirmed_list','no_header'))
                    or statuses!=analysis.get('status_mapping',{}))
                manual=mapping_changed or analysis.get('profile_used',False) or old_options.get('manual_mapping',False)
                document.mapping=mapping
                document.options={k:values[k] for k in ('kind','sheet','origin','currency','number_format','no_header','confirmed_list','overlap_ack')}
                document.options.update(status_mapping=statuses,remember_requested=values['remember'])
                document.options.update(header_row=values['header_row']-1,manual_mapping=manual,mapping_reviewed=(not analysis['ambiguous'] or values['ambiguity_ack'] or mapping_changed))
                document.save(update_fields=['mapping','options','updated_at'])
                analysis=engine.analyze(document)
                summary=preview(document,analysis)
                if request.POST.get('action')=='confirm' and not semantic_changed:
                    if analysis['ambiguous'] and not values['ambiguity_ack'] and not document.options.get('mapping_reviewed'): raise ValidationError('Verifica le associazioni ambigue e conferma la verifica.')
                    engine.confirm_document(document,request.user,remember=values['remember'])
                    messages.success(request,'Importazione confermata. Conversioni e informazioni disponibili aggiornate.')
                    return redirect('document-detail',pk=document.pk)
                if request.POST.get('action')=='confirm' and semantic_changed:
                    messages.info(request,'Anteprima aggiornata: verifica risultati e associazioni, poi conferma. Nessun dato è ancora applicato.')
                form=MappingForm(analysis=analysis,document=document)
            except ValidationError as exc: error=' '.join(exc.messages)
        if summary is None and not analysis['needs_sheet']:
            try: summary=preview(document,analysis)
            except ValidationError as exc: error=' '.join(exc.messages)
        column_fields=[form['col_'+str(i)] for i in range(len(analysis['headers']))]
        return render(request,'core/document_detail.html',dict(document=document,analysis=analysis,form=form,column_fields=column_fields,
                    status_fields=[form[key] for key in form.status_fields],summary=summary,error=error,kind_label=engine.KINDS.get(analysis['kind']),samples=analysis['rows'][:3]))


from .forms import MultipleFileField,MultipleFileInput
class CenterUploadForm(forms.Form):
    file=MultipleFileField(label='Documenti CSV, XLS o XLSX',widget=MultipleFileInput(attrs={'accept':'.csv,.xls,.xlsx'}))
    event=forms.ModelChoiceField(queryset=None,label='Evento a cui collegare i dati')
    def __init__(self,*args,events,**kwargs):
        kwargs.setdefault('auto_id','upload_%s')
        super().__init__(*args,**kwargs);self.fields['event'].queryset=events
    def clean_file(self):
        files=self.cleaned_data['file']
        if len(files)>10: raise forms.ValidationError('Seleziona al massimo dieci file.')
        return files


def start_documents(request,event,files):
    documents=[]
    for upload in files:
        try:
            document,created=engine.create_document(event,upload,request.user)
            documents.append(document)
            if not created: messages.info(request,'Documento già presente: aperta la sua anteprima, senza duplicare i dati.')
        except ValidationError as exc: messages.error(request,' '.join(exc.messages))
    if len(documents)==1: return redirect('document-detail',pk=documents[0].pk)
    if documents: messages.success(request,'Documenti analizzati: verifica e conferma ogni file separatamente nello storico.')
    return redirect('imports')
