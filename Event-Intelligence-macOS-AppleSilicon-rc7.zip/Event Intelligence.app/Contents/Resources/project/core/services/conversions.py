"""New metrics only. Never changes historical sales, RSVP or money calculations."""
from decimal import Decimal
from core.models import OrderRevision,RegistrationRevision,ParticipationRecord,Contact


def conversion_metrics(event,spend=None):
    orders=list(OrderRevision.objects.filter(batch__event=event,batch__status='confirmed',status='completed'))
    paid=free=unclassified=0
    for row in orders:
        basis=row.ticket_revenue if row.ticket_revenue is not None else row.gross_revenue
        if basis is None: unclassified+=row.ticket_count
        elif basis==0: free+=row.ticket_count
        else: paid+=row.ticket_count
    records=list(ParticipationRecord.objects.filter(batch__event=event,batch__status='confirmed').select_related('batch'))
    confirmed=[r for r in records if r.status=='confirmed']
    for row in confirmed:
        if row.kind=='ticket_paid': paid+=row.quantity
        elif row.kind=='ticket_free': free+=row.quantity
        elif row.kind=='ticket_unknown': unclassified+=row.quantity
    legacy_rsvp=RegistrationRevision.objects.filter(batch__event=event,batch__status='confirmed',status='confirmed')
    rsvp=sum(r.guests for r in legacy_rsvp)+sum(r.quantity for r in confirmed if r.kind=='rsvp' and r.batch.source=='generic')
    registrations=sum(r.quantity for r in confirmed if r.kind=='free_registration')
    ticket_records=[r for r in confirmed if r.kind in ('ticket_paid','ticket_free','ticket_unknown')]
    receipts=[]
    for row in ticket_records:
        amounts=row.evidence.get('amounts',{})
        value=amounts.get('ticket_revenue')
        if value is None and amounts.get('price') is not None and (row.quantity==1 or row.evidence.get('price_unit_explicit')):
            value=Decimal(amounts['price'])*row.quantity
        receipts.append(Decimal(value) if value is not None and row.evidence.get('currency')=='EUR' else None)
    standalone_revenue=sum(receipts,Decimal(0)) if receipts and all(v is not None for v in receipts) else None
    total=paid+free+unclassified+rsvp+registrations
    contacts=sum(1 for r in records if r.contact_id is not None)
    ids=[r.contact_id for r in records if r.contact_id]
    marketing=Contact.objects.filter(records__batch__event=event,records__batch__status='confirmed',email_key__isnull=False).filter(records__consent='granted',records__batch__status='confirmed').exclude(records__consent='denied').distinct().count()
    sources={r.batch.source for r in confirmed}|{r.ticketing_event.platform for r in orders}|{r.ticketing_event.platform for r in legacy_rsvp}
    overlap=len(ids)!=len(set(ids)) or len(sources)>1
    checkins=None
    if event.checkin_enabled:
        values=[r.checkin_count for r in records if r.kind!='checkin' and r.checkin_count is not None]
        values += [r.quantity for r in confirmed if r.kind=='checkin']
        checkins=sum(values) if values else None
    def cost(n): return Decimal(spend)/n if spend is not None and n else None
    has_data=bool(records and any(r.kind in ('orders','rsvp','free_registration','ticket_paid','ticket_free','ticket_unknown') for r in records)) or OrderRevision.objects.filter(batch__event=event,batch__status='confirmed').exists() or RegistrationRevision.objects.filter(batch__event=event,batch__status='confirmed').exists()
    return dict(marketing_granted_contacts=marketing,has_data=has_data,ticket_paid=paid,ticket_free=free,ticket_unclassified=unclassified,rsvp=rsvp,
                free_registration=registrations,orders=len(orders),contact_rows=contacts,
                standalone_ticket_revenue=standalone_revenue,total_actions=total,potential_overlap=overlap,checkins=checkins,checkin_enabled=event.checkin_enabled,
                cost_per_action=cost(total),cost_per_ticket=cost(paid+free+unclassified),
                cost_per_rsvp=cost(rsvp),cost_per_free_registration=cost(registrations))
