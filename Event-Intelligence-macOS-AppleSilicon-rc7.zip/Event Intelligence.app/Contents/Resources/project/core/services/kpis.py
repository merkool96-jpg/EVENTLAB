"""Deterministic KPIs over confirmed revisions only. Missing is never zero."""

from decimal import Decimal
from core.models import AdObservation, OrderRevision, RegistrationRevision


def ratio(numerator, denominator, factor=1):
    if numerator is None or denominator is None or denominator == 0:
        return None
    return Decimal(numerator) / Decimal(denominator) * Decimal(factor)


def complete_sum(rows, field):
    values = [getattr(r, field) for r in rows]
    if not values or any(v is None for v in values):
        return None
    return sum(values)


def advertising(rows):
    spend = complete_sum(rows, "spend")
    clicks = complete_sum(rows, "link_clicks")
    impressions = complete_sum(rows, "impressions")
    purchases = complete_sum(rows, "attributed_purchases")
    revenue = complete_sum(rows, "attributed_revenue")
    attribution_compatible = (
        bool(rows)
        and len({r.attribution for r in rows}) == 1
        and bool(rows[0].attribution)
    )
    return dict(
        spend=spend,
        clicks=clicks,
        impressions=impressions,
        cpc=ratio(spend, clicks),
        ctr=ratio(clicks, impressions, 100),
        cpm=ratio(spend, impressions, 1000),
        attributed_purchases=purchases if attribution_compatible else None,
        roas=ratio(revenue, spend) if attribution_compatible else None,
    )


def dashboard(event):
    ads = list(
        AdObservation.objects.filter(
            batch__event=event, batch__status="confirmed"
        ).order_by("creative_name", "period_start")
    )
    orders = list(
        OrderRevision.objects.filter(batch__event=event, batch__status="confirmed")
    )
    completed = [r for r in orders if r.status == "completed"]
    groups = {}
    for row in ads:
        if row.extra_metrics.get('level') == 'campaign': continue
        groups.setdefault(row.source_key, []).append(row)
    creatives = [
        dict(key=key, name=rows[0].creative_name, **advertising(rows))
        for key, rows in groups.items()
    ]
    from collections import defaultdict

    daily = defaultdict(Decimal)
    for row in ads:
        if row.period_start == row.period_end:
            daily[row.period_start.isoformat()] += row.spend
    timeline = [
        {"label": day, "value": float(value)} for day, value in sorted(daily.items())
    ]
    registrations = list(
        RegistrationRevision.objects.filter(
            batch__event=event, batch__status="confirmed"
        )
    )
    from .conversions import conversion_metrics
    conversions=conversion_metrics(event,advertising(ads)['spend'])
    return dict(
        conversions=conversions,
        timeline=timeline,
        registrations=sum(r.guests for r in registrations if r.status == "confirmed")
        if registrations
        else None,
        kpis=advertising(ads),
        creatives=creatives,
        order_count=len(completed) if orders else None,
        tickets=sum(r.ticket_count for r in completed) if orders else None,
        gross=complete_sum(completed, "gross_revenue"),
        ticket_revenue=complete_sum(completed, "ticket_revenue"),
        fees=complete_sum(completed, "fees"),
        processing_fees=complete_sum(completed, "processing_fees"),
        fee_tax=complete_sum(completed, "fee_tax"),
        meta_rows=len(ads),
        order_rows=len(orders),
    )
