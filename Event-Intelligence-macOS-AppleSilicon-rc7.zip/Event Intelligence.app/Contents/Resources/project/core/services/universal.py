"""File -> semantic mapping -> typed records. AI is never required; no PII sent out."""
import csv
import hashlib
import io
import json
import re
import zipfile
from pathlib import Path
from decimal import Decimal
from datetime import datetime
from django.core.exceptions import ValidationError
from django.core.files.base import ContentFile
from django.core.files.uploadedfile import SimpleUploadedFile
from django.core.validators import validate_email
from django.db import transaction
from core.models import (Event,ImportDocument,MappingProfile,ImportBatch,Contact,ParticipationRecord,AuditEntry)
from . import imports as legacy

CONFIRMED={'going','confirmed','completed','complete','eventbrite completed','paid','yes','true','si','confermato','confermata','completato','accepted','registered','attending','joined','confirme','iscritto','iscritta','partecipo'}
CANCELLED={'cancelled','canceled','declined','not going','no','false','annullato','rimborsato','refunded','eventbrite refunded','eventbrite cancelled'}

KINDS={'contacts':'Contatti / altra lista','guestlist':'Guestlist','invited':'Invitati',
       'rsvp':'RSVP','free_registration':'Registrazioni gratuite','tickets':'Biglietti',
       'orders':'Ordini','ads':'Dati pubblicitari','campaigns':'Report di campagna','checkin':'Check-in'}
EXTRA_ALIASES={
 'full_name':['name','full name','fullname','guest name','attendee name','customer name','what is your name','your name','nome ospite','nome del partecipante','nome e cognome','nome completo','nombre completo'],
 'first_name':['first name','firstname','given name','nome','prenom','nombre'],
 'last_name':['last name','lastname','surname','cognome','nom de famille','apellido'],
 'email':['email','e-mail','e mail','mail','email address','indirizzo email','what is your email?','correo electronico'],
 'record_id':['registration id','id registrazione','guest id','ticket id','codice biglietto','codice registrazione'],
 'quantity':['guests','partecipanti','guest count','attendees','number of guests','numero partecipanti','n biglietti'],
 'status':['rsvp','rsvp status','attendance status','registration status','response','risposta','stato registrazione','going'],
 'gross':['total charged','totale addebitato','total paid','importo totale'],
 'ticket_revenue':['ticket revenue','ricavi biglietti','ricavi ticket'],
 'price':['unit price','prezzo unitario','price','ticket price','prezzo','prezzo biglietto','ticket price (eur)'],
 'consent':['marketing consent','consenso marketing','consenso promozionale','consent to marketing'],
 'checkin_count':['check-ins','checkins','check-in count','checked in','scans','scansionati','ingressi verificati'],
 'day':['day','giorno','data','date'],
 'reach':['reach','copertura'], 'results':['results','risultati'],
 'result_type':['result type','indicatore di risultato'],
 'cost_per_result':['cost per result','costo per risultati','costo per risultato'],
}
FIELDS={key:key.replace('_',' ').capitalize() for key in set(legacy.ALIASES)|set(EXTRA_ALIASES)}
FIELDS.pop('registration_id',None)
FIELDS.pop('guests',None)
FIELDS.update(ad='Nome inserzione',ad_id='ID inserzione',campaign='Campagna',adset='Gruppo inserzioni',
 start='Inizio periodo',end='Fine periodo',spend='Spesa pubblicitaria',currency='Valuta',
 clicks='Clic sul link',impressions='Impression',reach='Copertura',purchases='Acquisti attribuiti pubblicitari',
 attributed_revenue='Ricavi attribuiti pubblicitari',attribution='Finestra di attribuzione',order_id='ID ordine',
 event_id='ID evento nella fonte',event_name='Nome evento nella fonte',fees='Commissioni piattaforma',
 refunds='Rimborsi',platform='Piattaforma dichiarata',processing_fees='Commissioni pagamento',
 fee_tax='IVA commissioni riportata',price='Prezzo dichiarato',results='Risultati pubblicitari',
 day='Data di riferimento (giorno del report)',result_type='Tipo di risultato pubblicitario',cost_per_result='Costo per risultato originale')
FIELDS.update(full_name='Nome completo',first_name='Nome',last_name='Cognome',email='Email',
              quantity='Quantità / partecipanti',gross='Totale addebitato / lordo ordini',
              ticket_revenue='Ricavi biglietti',status='Stato',consent='Consenso marketing esplicito',
              record_id='ID registrazione / biglietto',checkin_count='Check-in rilevati')


def norm(value):
    text=re.sub(r'([A-Z]+)([A-Z][a-z])',r'\1 \2',str(value))
    text=re.sub(r'([a-z])([A-Z])',r'\1 \2',text)
    return re.sub(r'[^\w]+',' ',legacy.normalized(text)).strip()


def read_sheets(upload):
    data=upload.read(legacy.MAX_BYTES+1)
    if not data or len(data)>legacy.MAX_BYTES: raise ValidationError('File vuoto o superiore a 10 MB.')
    suffix=Path(upload.name).suffix.lower()
    if suffix=='.csv':
        try: text=data.decode('utf-16' if data.startswith((bytes([255,254]),bytes([254,255]))) else 'utf-8-sig')
        except UnicodeDecodeError:
            try: text=data.decode('cp1252')
            except UnicodeDecodeError: raise ValidationError('Codifica CSV non riconosciuta.')
        try: dialect=csv.Sniffer().sniff(text[:8192],delimiters=',;\t|')
        except csv.Error: dialect=csv.excel
        try: rows=legacy.list_row_limit(csv.reader(io.StringIO(text),dialect))
        except csv.Error: raise ValidationError('CSV non valido.')
        if len(rows)<2: raise ValidationError('Nessuna riga dati disponibile.')
        return data,{'CSV':rows}
    if suffix=='.xlsx':
        from openpyxl import load_workbook
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as archive:
                if sum(x.file_size for x in archive.infolist())>50*1024*1024: raise ValidationError('Excel troppo grande dopo decompressione.')
            book=load_workbook(io.BytesIO(data),read_only=True,data_only=False)
            if len(book.worksheets)>20: raise ValidationError('Massimo venti fogli per file.')
            sheets={}
            for sheet in book:
                # Dimension metadata is optional and may be stale in third-party exports.
                sheet.reset_dimensions()
                rows=legacy.list_row_limit(sheet.values)
                if len(rows)>1: sheets[sheet.title]=rows
            book.close()
        except ValidationError: raise
        except Exception: raise ValidationError('XLSX non leggibile; nessun dato importato.') from None
    elif suffix=='.xls':
        import xlrd
        try:
            book=xlrd.open_workbook(file_contents=data,on_demand=True)
            if book.nsheets>20: raise ValidationError('Massimo venti fogli per file.')
            sheets={s.name:legacy.list_row_limit(s.row_values(i) for i in range(s.nrows)) for s in book.sheets() if s.nrows>1}
            book.release_resources()
        except xlrd.XLRDError: raise ValidationError('XLS non leggibile; nessun dato importato.') from None
    else: raise ValidationError('Usa CSV, XLS oppure XLSX.')
    if not sheets: raise ValidationError('Nessun foglio dati disponibile.')
    return data,sheets


def signature(headers):
    return hashlib.sha256(json.dumps(sorted(norm(h) for h in headers)).encode()).hexdigest()


def suggest(headers,rows):
    aliases={k:{norm(k),*(norm(a) for a in legacy.ALIASES.get(k,[])),*(norm(a) for a in EXTRA_ALIASES.get(k,[]))} for k in FIELDS}
    candidates={key:[i for i,h in enumerate(headers) if norm(h) in values] for key,values in aliases.items()}
    for i,h in enumerate(headers):
        if re.search(r'\b(e ?mail|correo electronico)\b',norm(h)) and i not in candidates['email']:
            candidates['email'].append(i)
    if len(candidates['email'])>1:
        shaped=[]
        for index in candidates['email']:
            values=[str(r[index]).strip() for r in rows[:100] if index<len(r) and r[index] not in ('',None)]
            if values and all(re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',v) for v in values): shaped.append(index)
        if len(shaped)==1: candidates['email']=shaped
    # Value shape can identify email locally even with previously unseen headings.
    if not candidates['email']:
        for i in range(len(headers)):
            values=[str(r[i]).strip() for r in rows[:100] if i<len(r) and r[i] not in ('',None)]
            if values and all(re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',v) for v in values): candidates['email'].append(i)
    mapping={key:indices[0] for key,indices in candidates.items() if len(indices)==1}
    ambiguous=[FIELDS[k] for k,v in candidates.items() if len(v)>1]
    used={i:[k for k,v in mapping.items() if v==i] for i in set(mapping.values())}
    for i,keys in used.items():
        if len(keys)>1:
            for k in keys: mapping.pop(k,None)
            ambiguous.append('Colonna '+str(i+1)+' con più significati')
    return mapping,ambiguous


def infer_kind(mapping,headers,rows):
    if 'ad' in mapping and 'spend' in mapping and ('day' in mapping or all(k in mapping for k in ('start','end'))): return 'ads'
    if 'campaign' in mapping and 'spend' in mapping and ('day' in mapping or all(k in mapping for k in ('start','end'))): return 'campaigns'
    if all(k in mapping for k in ('order_id','quantity')): return 'orders'
    if 'record_id' in mapping and any(term in norm(headers[mapping['record_id']]) for term in ('ticket','bigliett','boleto')): return 'tickets'
    if 'status' in mapping:
        values={norm(r[mapping['status']]) for r in rows[:100] if mapping['status']<len(r)}
        if 'going' in values or 'rsvp' in norm(headers[mapping['status']]): return 'rsvp'
        if 'registration' in norm(headers[mapping['status']]): return 'free_registration'
    if 'platform' in mapping and any(norm(r[mapping['platform']])=='partiful' for r in rows[:100] if mapping['platform']<len(r)): return 'rsvp'
    return 'contacts'


def analyze(document):
    with document.file.open('rb') as file:
        data,sheets=read_sheets(SimpleUploadedFile(document.filename,file.read()))
    selected=document.options.get('sheet')
    if selected not in sheets:
        selected=next(iter(sheets)) if len(sheets)==1 else None
    if selected is None: return {'sheets':list(sheets),'needs_sheet':True,'headers':[],'rows':[],'mapping':{},'kind':'contacts','ambiguous':['Scegli il foglio da analizzare.']}
    table=sheets[selected]
    if not table: raise ValidationError('Foglio vuoto.')
    header=document.options.get('header_row')
    if header is None:
        scores=[len(suggest([str(v or '') for v in row],[])[0]) for row in table[:20]]
        header=scores.index(max(scores)) if max(scores)>=2 else 0
    if not isinstance(header,int) or header<0 or header>=min(50,len(table)-1): raise ValidationError('Riga intestazioni non valida.')
    no_header=bool(document.options.get('no_header'))
    width=max(len(r) for r in table)
    headers=[('Colonna '+str(i+1)) for i in range(width)] if no_header else [str(v or '').strip() for v in table[header]]
    headers+=['']*(width-len(headers))
    start=0 if no_header else header+1
    rows=[list(r)+['']*max(0,len(headers)-len(r)) for r in table[start:] if any(v not in ('',None) for v in r)]
    mapping,ambiguous=suggest(headers,rows)
    saved=MappingProfile.objects.filter(signature=signature(headers)).first() if not no_header else None
    if saved and not document.mapping:
        positions={norm(h):i for i,h in enumerate(headers) if sum(norm(x)==norm(h) for x in headers)==1}
        mapping={k:positions[h] for k,h in saved.mapping.items() if k in FIELDS and isinstance(h,str) and h in positions}
    if document.mapping:
        mapping=document.mapping
        if document.options.get('mapping_reviewed'): ambiguous=[]
    if not document.options.get('mapping_reviewed') and not saved and 'full_name' in mapping and 'spend' in mapping and ('day' in mapping or ('start' in mapping and 'end' in mapping)) and 'ad' not in mapping and 'campaign' not in mapping:
        ambiguous.append('Nome con spesa e periodo: può essere un contatto, una campagna o un’inserzione. Verifica tipo e associazione del nome.')
    inferred=infer_kind(mapping,headers,rows)
    kind=document.options.get('kind') or (saved.kind if saved else inferred)
    if kind in ('rsvp','free_registration') and 'quantity' in mapping and not document.options.get('mapping_reviewed') and not saved:
        label=norm(headers[mapping['quantity']])
        normalized_contract=('platform' in mapping and 'record_id' in mapping and 'event_id' in mapping
            and all(norm(r[mapping['platform']])=='partiful' for r in rows[:100]))
        if label in ('guests','guest count','number of guests','partecipanti') and not normalized_contract:
            ambiguous.append('Quantità ospiti: verifica se sono conferme totali o soli accompagnatori. Non associare gli accompagnatori al numero di conversioni.')

    if not no_header and not saved and not suggest(headers,[])[0] and not document.options.get('mapping_reviewed'):
        ambiguous.append('Intestazioni non riconosciute: verifica se la prima riga è un’intestazione o dati.')
    if saved and saved.kind!=inferred and not document.options.get('mapping_reviewed'):
        ambiguous.append('Tipologia proposta da un profilo precedente: verifica il significato della lista.')
    status_mapping=document.options.get('status_mapping',saved.mapping.get('__status_mapping__',{}) if saved else {})
    return dict(sheets=list(sheets),sheet=selected,header_row=header,headers=headers,rows=rows,mapping=mapping,kind=kind,ambiguous=ambiguous,needs_sheet=False,profile_used=bool(saved),status_mapping=status_mapping,first_data_row=(1 if no_header else header+2))


def create_document(event,upload,user):
    data,_=read_sheets(upload)
    digest=hashlib.sha256(data).hexdigest()
    old=ImportDocument.objects.filter(event=event,sha256=digest).first()
    if old: return old,False
    document=ImportDocument(event=event,filename=Path(upload.name).name[:255],sha256=digest,created_by=user)
    document.file.save(document.filename,ContentFile(data),save=False)
    try: document.save()
    except Exception:
        document.file.delete(save=False);raise
    return document,True


def recognized_adapter(document,analysis):
    # Do not label generic orders Eventbrite merely because they are not ads.
    headers={legacy.normalized(h) for h in analysis['headers']}
    if analysis['header_row']!=0 or len(analysis['sheets'])!=1: return None
    known=(analysis['kind']=='ads' or {'gross revenue (eur)','ticket revenue (eur)','event name'}.issubset(headers)
           or 'platform' in headers)
    if not known: return None
    with document.file.open('rb') as f:
        data=f.read()
    try:
        source,_,_=legacy.parse(SimpleUploadedFile(document.filename,data))
    except ValidationError: return None
    return source


def normalize(document,analysis):
    if analysis['needs_sheet']: raise ValidationError('Seleziona un foglio.')
    mapping=analysis['mapping'];headers=analysis['headers'];kind=analysis['kind']
    if kind not in KINDS: raise ValidationError('Tipo dati non valido.')
    if any(k not in FIELDS or not isinstance(i,int) or i<0 or i>=len(headers) for k,i in mapping.items()): raise ValidationError('Associazione colonne non valida.')
    if len(set(mapping.values()))!=len(mapping): raise ValidationError('Una colonna non può alimentare due campi diversi.')
    if kind=='checkin' and not document.event.checkin_enabled: raise ValidationError('Il check-in è disattivato per questo evento. Abilitalo nella Scheda Evento oppure scegli un altro tipo di dati.')
    if kind=='orders' and 'quantity' not in mapping: raise ValidationError('Associa il numero di biglietti; una riga ordine non equivale a un biglietto.')
    if kind in ('ads','campaigns'):
        missing=[k for k in (('ad','spend') if kind=='ads' else ('campaign','spend')) if k not in mapping]
        if 'day' not in mapping: missing += [k for k in ('start','end') if k not in mapping]
        if missing: raise ValidationError('Per i dati pubblicitari associa nome inserzione, periodo e spesa.')
    output=[];warnings=list(analysis['ambiguous']);seen=set()
    monetary=('gross','ticket_revenue','fees','processing_fees','fee_tax','refunds','price','spend')
    separators=set()
    for row in analysis['rows']:
        for field in monetary:
            if field in mapping:
                value=str(row[mapping[field]] or '').strip()
                if isinstance(row[mapping[field]],str):
                    match=re.search(r'([,.])\d{1,2}$',value)
                    if match: separators.add(match.group(1))
    if len(separators)>1: raise ValidationError('Separatori monetari discordanti: correggi l’associazione o verifica il file.')
    sep={'it':',','en':'.'}.get(document.options.get('number_format')) or next(iter(separators),None)
    def numeric(value,integer=False,optional=True):
        if isinstance(value,bool): raise ValueError('Conteggio booleano non interpretabile come quantità')
        text=str(value if value is not None else '').strip()
        thousands='.' if sep==',' else ',' if sep=='.' else None
        if thousands and re.fullmatch(r'\d{1,3}(?:'+re.escape(thousands)+r'\d{3})+',text): text=text.replace(thousands,'')
        elif re.fullmatch(r'\d{1,3}[,.]\d{3}',text): raise ValueError('Separatore numerico ambiguo: scegli il formato numerico nell’anteprima, senza modificare il file')
        return legacy.number(text,integer=integer,optional=optional)
    for offset,row in enumerate(analysis['rows'],analysis.get('first_data_row',analysis['header_row']+2)):
        def get(k):
            if k not in mapping: return ''
            value=row[mapping[k]]
            if value is None: return ''
            if isinstance(value,datetime): return value.date().isoformat() if k in ('start','end','day') and kind in ('ads','campaigns') else value.isoformat()
            if k.endswith('_id') and isinstance(value,(float,int)) and float(value).is_integer(): return str(int(value))
            return str(value).strip()
        try:
            status=norm(get('status'))
            state='confirmed' if status in CONFIRMED else 'cancelled' if status in CANCELLED else analysis.get('status_mapping',{}).get(status,'unknown')
            if state not in ('confirmed','cancelled','unknown'): raise ValueError('Mappatura stato non valida')
            if not status and document.options.get('confirmed_list'): state='confirmed'
            if status and state=='unknown' and kind not in ('contacts','guestlist','invited','ads','campaigns'): raise ValueError('Stato non riconosciuto: indica il significato prima di confermare')
            quantity=numeric(get('quantity'),integer=True,optional=False) if 'quantity' in mapping else numeric(get('checkin_count'),integer=True,optional=False) if kind=='checkin' and 'checkin_count' in mapping else 1
            if quantity>2147483647: raise ValueError('Quantità fuori intervallo')
            email=get('email')
            if email:
                try: validate_email(email)
                except ValidationError:
                    if kind not in ('orders','tickets','ads','campaigns'): raise
                    warnings.append(f'Riga {offset}: email facoltativa non valida, non collegata a un contatto. Il valore originale resta nel documento privato.')
                    email=''
            name=get('full_name');first=get('first_name');last=get('last_name')
            if len(email)>254 or len(name)>255 or len(first)>160 or len(last)>160: raise ValueError('Identificativo contatto troppo lungo')
            # Full names are not split by a heuristic that could corrupt compound names.
            fullname=name or ' '.join(x for x in (first,last) if x)
            if kind in ('contacts','guestlist','invited') and not any((fullname,email,get('record_id'))): raise ValueError('La riga non contiene un contatto identificabile')
            amounts={k:numeric(get(k)) for k in monetary if k in mapping}
            period={};ad_counts={}
            if kind in ('ads','campaigns'):
                period={'start':legacy.parse_date(get('start') or get('day')),'end':legacy.parse_date(get('end') or get('day'))}
                if period['end']<period['start']: raise ValueError('Periodo invertito')
                label=get('ad') if kind=='ads' else get('campaign')
                if not label or len(label)>240: raise ValueError('Nome inserzione/campagna mancante o troppo lungo')
                if amounts.get('spend') is None: raise ValueError('Spesa pubblicitaria mancante')
                ad_counts={k:numeric(get(k),integer=True) for k in ('clicks','impressions','reach','purchases') if k in mapping}

            currency=get('currency').upper() or document.options.get('currency','')
            if currency in ('€','EURO','EUROS'): currency='EUR'
            if not currency and any('€' in get(k) for k in amounts): currency='EUR'
            if not currency and any('eur' in norm(headers[mapping[k]]) for k in amounts): currency='EUR'
            if any(v is not None for v in amounts.values()) and currency!='EUR': raise ValueError('Seleziona la valuta EUR; nessuna conversione monetaria automatica')
            role=kind
            if kind=='tickets':
                price=amounts.get('price')
                role='ticket_unknown' if price is None else 'ticket_free' if Decimal(price)==0 else 'ticket_paid'
            consent=norm(get('consent'))
            consent='granted' if consent in {'yes','si','true','granted','accepted','consento'} else 'denied' if consent in {'no','false','denied','rifiuto'} else 'unknown'
            external=get('order_id') if kind=='orders' else get('record_id')
            if len(external)>100: raise ValueError('ID troppo lungo; massimo cento caratteri')
            if external and (kind,external) in seen: raise ValueError('ID ripetuto nello stesso file: nessuna somma automatica')
            if external: seen.add((kind,external))
            raw_checkin=norm(get('checkin_count'))
            if raw_checkin in {'yes','true','si','checked in','no','false'}:
                checkin=(1 if raw_checkin in {'yes','true','si','checked in'} else 0) if quantity==1 else None
                if quantity!=1: warnings.append('Check-in booleano con quantità multipla: conteggio non dedotto.')
            else:
                try: checkin=numeric(get('checkin_count'),integer=True) if 'checkin_count' in mapping else None
                except ValueError:
                    if kind=='checkin': raise
                    checkin=None;warnings.append('Check-in facoltativo non interpretabile: non usato, vendite e registrazioni restano indipendenti.')
            if checkin is not None and checkin>quantity:
                if kind=='checkin': raise ValueError('Check-in maggiori della quantità nella riga')
                checkin=None;warnings.append('Check-in non coerenti con la quantità: non utilizzati come ingressi verificati.')
            price_unit_explicit='price' in mapping and any(v in norm(headers[mapping['price']]) for v in ('unit','per ticket','prezzo biglietto'))
            if kind=='tickets' and quantity>1 and not price_unit_explicit and 'price' in mapping:
                warnings.append('Prezzo con quantità multipla: non viene moltiplicato senza indicazione esplicita di prezzo unitario. Puoi associare un totale alla colonna ricavi biglietti.')
            output.append(dict(source_fields={k:get(k) for k in mapping if k not in ('email','full_name','first_name','last_name')},source_date=get('day'),period=period,ad_counts=ad_counts,price_unit_explicit=price_unit_explicit,row=offset,kind=role,status=state,quantity=quantity,external_id=external,
                email=email,full_name=fullname,first_name=first,last_name=last,consent=consent,
                amounts=amounts,currency=currency,checkin_count=checkin,
                extra={str(i+1)+': '+(headers[i] or 'Senza intestazione'):str(v) if v is not None else '' for i,v in enumerate(row[:len(headers)]) if i not in mapping.values()}))
        except (ValueError,ValidationError) as error:
            raise ValidationError(f'Riga {offset}: {error.messages[0] if isinstance(error,ValidationError) else error}.') from None
    if not output: raise ValidationError('Nessuna riga dati valida.')
    if any(r['status']=='unknown' for r in output) and kind not in ('contacts','guestlist','invited','ads','campaigns'): warnings.append('Stati mancanti: queste righe non generano conversioni finché non indichi che la lista rappresenta conferme.')
    if kind in ('rsvp','free_registration','tickets','orders') and not any(r['external_id'] for r in output): warnings.append('ID assenti: identità limitata alla riga del file; non sono persone uniche verificate.')
    emails=[r['email'].casefold() for r in output if r['email']]
    previous=ParticipationRecord.objects.filter(batch__event=document.event,batch__status='confirmed').exclude(batch_id=document.batch_id)
    scope=document.options.get('origin','').strip() or signature(headers)[:16]
    ids=[r['external_id'] for r in output if r['external_id']]
    incoming_ids={(r['kind'],r['external_id']) for r in output if r['external_id']}
    previous_ids=list(previous.exclude(external_id='').values_list('kind','external_id','evidence__origin')) if ids else []
    if any((kind,external) in incoming_ids and origin==scope for kind,external,origin in previous_ids):
        raise ValidationError('Identificativi già presenti per lo stesso evento, tipo e origine. Verifica o annulla il report precedente; nessun doppio conteggio applicato.')
    id_overlap=any((kind,external) in incoming_ids for kind,external,origin in previous_ids)
    previous_email_keys=set(previous.exclude(contact__email_key=None).values_list('contact__email_key',flat=True)) if emails else set()
    incoming_email_keys={hashlib.sha256(e.encode()).hexdigest() for e in emails}
    overlap=bool(id_overlap or len(set(emails))<len(emails) or previous_email_keys.intersection(incoming_email_keys))
    if overlap: warnings.append('Identificativi o email ripetuti tra liste/fonti: possibile sovrapposizione. Le righe restano distinte e le azioni non sono persone uniche.')
    return output,warnings,overlap


@transaction.atomic
def confirm_document(document,user,remember=False):
    document=ImportDocument.objects.select_for_update().get(pk=document.pk)
    Event.objects.select_for_update().get(pk=document.event_id)
    if document.batch_id:
        batch=document.batch
        if batch.status=='confirmed': return batch
        if batch.status!='reverted': raise ValidationError('Stato importazione non confermabile.')
        current_analysis=analyze(document)
        _,_,overlap=normalize(document,current_analysis)
        if overlap and not document.options.get('overlap_ack'): raise ValidationError('Verifica le sovrapposizioni prima di riconfermare.')
        if batch.payload: legacy.confirm(batch,user)
        else:
            batch.status='confirmed';batch.save(update_fields=['status','updated_at'])
            AuditEntry.objects.create(actor=user,event=document.event,action='import.confirmed',details={'batch':str(batch.pk)})
            from .business import automatic_report
            automatic_report(document.event)
        return batch
    analysis=analyze(document)
    if analysis['ambiguous'] and not document.options.get('mapping_reviewed'):
        raise ValidationError('Associazioni ambigue: verifica le colonne prima di confermare.')
    # Existing exact adapters keep their checked arithmetic and semantics intact.
    identified_source=recognized_adapter(document,analysis)
    adapter=identified_source if not document.options.get('manual_mapping') and not analysis.get('profile_used') else None
    existing=ImportBatch.objects.filter(event=document.event,sha256=document.sha256).first()
    if existing:
        if document.options.get('manual_mapping'):
            raise ValidationError('Questo file è già nello storico: le associazioni storiche non vengono riscritte. Verifica e annulla la vecchia importazione prima di una nuova interpretazione.')
        legacy.confirm(existing,user,generate_analysis=False) if existing.status!='confirmed' else None
        batch=existing
        rows=[] if analysis['kind'] in ('ads','campaigns') else normalize(document,analysis)[0]
    elif adapter:
        with document.file.open('rb') as f:
            batch,_=legacy.stage(document.event,SimpleUploadedFile(document.filename,f.read()),user)
        legacy.confirm(batch,user,generate_analysis=False)
        rows=[] if analysis['kind'] in ('ads','campaigns') else normalize(document,analysis)[0]
    else:
        rows,warnings,overlap=normalize(document,analysis)
        if overlap and not document.options.get('overlap_ack'): raise ValidationError('Verifica la possibile sovrapposizione e confermala esplicitamente prima di importare.')
        kind=analysis['kind'];scope=document.options.get('origin','').strip() or signature(analysis['headers'])[:16]
        eid='local:'+str(document.event_id)+':'+hashlib.sha256(scope.encode()).hexdigest()[:16]
        payload=[]
        if kind in ('ads','campaigns'):
            # Reuse deterministic Meta parser on manually mapped canonical columns.
            upload=ad_upload(document,analysis,rows)
            batch,created=legacy.stage(document.event,upload,user)
            if created:
                batch.sha256=document.sha256
                batch.source=identified_source or 'generic'
                for entry in batch.payload:
                    if batch.source=='generic': entry['kind']='ad_observation'
                    entry.setdefault('extra_metrics',{})['origin']=document.options.get('origin','') or batch.get_source_display()
                    if kind=='campaigns': entry['extra_metrics']['level']='campaign'
                batch.save(update_fields=['sha256','payload','source'])
            legacy.confirm(batch,user,generate_analysis=False)
        else:
            if kind=='orders':
                for r in rows:
                    amounts=r['amounts']
                    payload.append(dict(order_id=r['external_id'] or ('local-'+document.sha256[:32]+'-'+str(r['row'])),event_id=eid,
                        status='completed' if r['status']=='confirmed' else 'cancelled' if r['status']=='cancelled' else 'unknown',
                        quantity=r['quantity'],gross=amounts.get('gross'),ticket_revenue=amounts.get('ticket_revenue'),
                        fees=amounts.get('fees'),processing_fees=amounts.get('processing_fees'),fee_tax=amounts.get('fee_tax'),
                        refunds=amounts.get('refunds'),currency=r['currency'],row=r['row']))
                legacy.conflicts(document.event,'generic',payload)
            batch=ImportBatch.objects.create(event=document.event,source='generic',sha256=document.sha256,filename=document.filename,
                 parser_version='universal-1',payload=payload,created_by=user)
            if kind=='orders': legacy.confirm(batch,user,generate_analysis=False)
            else:
                from django.utils import timezone
                batch.status='confirmed';batch.confirmed_at=timezone.now();batch.save(update_fields=['status','confirmed_at','updated_at'])
    if analysis['kind'] not in ('ads','campaigns') and not batch.participations.exists():
        persist_records(batch,rows,document.options.get('origin','').strip() or signature(analysis['headers'])[:16])
    if ImportDocument.objects.filter(batch=batch).exclude(pk=document.pk).exists():
        raise ValidationError('Dati normalizzati già collegati a un altro documento: nessun duplicato importato.')
    document.batch=batch;document.save(update_fields=['batch','updated_at'])
    if remember and not document.options.get('no_header'):
        MappingProfile.objects.update_or_create(signature=signature(analysis['headers']),defaults={
            'mapping':{**{k:norm(analysis['headers'][i]) for k,i in analysis['mapping'].items()},'__status_mapping__':analysis.get('status_mapping',{})},'kind':analysis['kind'],'confirmed_by':user})
    AuditEntry.objects.create(actor=user,event=document.event,action='document.confirmed',details={'document':str(document.pk),'batch':str(batch.pk)})
    from .business import automatic_report
    automatic_report(document.event)
    return batch


def persist_records(batch,rows,scope):
    records=[]
    for r in rows:
        contact=None
        if r['email']:
            canonical=r['email'].strip().casefold();key=hashlib.sha256(canonical.encode()).hexdigest()
            contact,_=Contact.objects.get_or_create(email_key=key,defaults={k:r[k] for k in ('email','full_name','first_name','last_name')})
        elif r['full_name']:
            contact=Contact.objects.create(**{k:r[k] for k in ('email','full_name','first_name','last_name')})
        records.append(ParticipationRecord(batch=batch,contact=contact,source_row=r['row'],kind=r['kind'],status=r['status'],
            quantity=r['quantity'],external_id=r['external_id'],consent=r['consent'],checkin_count=r['checkin_count'],
            evidence={'source_fields':r.get('source_fields',{}),'source_date':r.get('source_date',''),'price_unit_explicit':r.get('price_unit_explicit',False),'origin':scope,'amounts':r['amounts'],'currency':r['currency'],'original_names':{k:r[k] for k in ('full_name','first_name','last_name')},'extra':r['extra']}))
    ParticipationRecord.objects.bulk_create(records)


def ad_upload(document,analysis,rows=None):
    rows=rows or normalize(document,analysis)[0]
    kind=analysis['kind']
    fields=[k for k in analysis['mapping'] if k in legacy.ALIASES and not (kind=='campaigns' and k=='ad_id')]
    for key in ('start','end'):
        if key not in fields: fields.append(key)
    if kind=='campaigns' and 'ad' not in fields: fields.append('ad')
    stream=io.StringIO();writer=csv.writer(stream)
    writer.writerow([legacy.ALIASES[k][0] for k in fields])
    for raw,row in zip(analysis['rows'],rows):
        values=[]
        for key in fields:
            if key in row['period']: value=row['period'][key]
            elif key=='spend': value=row['amounts']['spend']
            elif key in row['ad_counts']: value=row['ad_counts'][key]
            elif kind=='campaigns' and key=='ad': value='[Campagna] '+str(raw[analysis['mapping']['campaign']])
            else: value=raw[analysis['mapping'][key]]
            values.append(value)
        writer.writerow(values)
    return SimpleUploadedFile('mapped.csv',stream.getvalue().encode())
