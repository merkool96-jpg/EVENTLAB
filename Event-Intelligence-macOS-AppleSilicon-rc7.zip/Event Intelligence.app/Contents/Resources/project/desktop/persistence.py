"""Standard-library recovery guard: runs before dependency installation/Django.

Never resets a database. Snapshot failure blocks upgrades. No automatic restore.
"""
import contextlib
import fcntl
import hashlib
import json
import os
from pathlib import Path
import secrets
import shutil
import sqlite3
import sys
import tempfile
from datetime import datetime, timezone

BUILD = 7
DB = 'event-intelligence.sqlite3'
STATE = 'installation-state.json'
EXCLUDED = {'backups', 'runtime', 'logs', 'static', DB, DB+'-wal', DB+'-shm', DB+'-journal',
            'application.lock', 'configuration.lock', 'token.lock', 'launch-token.json',
            'stop-request.json', 'model-request.json', 'model-status.json'}


def file_digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def atomic_json(path, value):
    fd, temp = tempfile.mkstemp(prefix='.guard-', dir=path.parent)
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, 'w') as stream:
            json.dump(value, stream, ensure_ascii=False)
        os.replace(temp, path)
    finally:
        with contextlib.suppress(FileNotFoundError): os.unlink(temp)


def state(root):
    path = root / STATE
    if not path.exists(): return {}
    try:
        value = json.loads(path.read_text())
        if not isinstance(value, dict): raise ValueError
        return value
    except (OSError, ValueError) as error:
        raise RuntimeError('Stato installazione illeggibile: nessuna inizializzazione eseguita. Ripristinare un backup.') from error


def fingerprint(project):
    project = Path(project)
    digest = hashlib.sha256()
    files = []
    for name in ('config', 'core', 'templates', 'desktop'):
        folder = project / name
        if folder.is_dir(): files.extend(folder.rglob('*'))
    if (project / 'manage.py').is_file(): files.append(project / 'manage.py')
    if not files: files = list(project.glob('*.py')) + list(project.glob('*.html'))
    for path in sorted(files):
        if '__pycache__' in path.parts or path.suffix == '.pyc' or not path.is_file(): continue
        digest.update(str(path.relative_to(project)).encode())
        digest.update(file_digest(path).encode())
    # Detect dependency-only/bundle-version updates as well as source changes.
    extras = [project/'pyproject.toml', project/'uv.lock']
    if project.name == 'project' and project.parent.name == 'Resources':
        extras.extend([project.parent/'requirements-macos.txt',
                       project.parent.parent/'Info.plist',
                       project.parent.parent/'MacOS'/'EventIntelligence'])
    for index, path in enumerate(extras):
        if path.is_file():
            digest.update(('manifest:'+str(index)).encode())
            digest.update(file_digest(path).encode())
    return digest.hexdigest()


def check_database(path):
    if path.is_symlink(): raise RuntimeError('Database con link simbolico: avvio interrotto per proteggere i dati.')
    if not path.is_file(): raise RuntimeError('Database mancante: nessun nuovo archivio creato.')
    with contextlib.closing(sqlite3.connect(path.resolve().as_uri()+'?mode=ro', uri=True)) as db:
        required = {'django_migrations', 'auth_user', 'core_event', 'core_brand', 'core_importbatch', 'core_orderrevision', 'core_analysisreport'}
        tables = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not required.issubset(tables):
            raise RuntimeError('Database vuoto o estraneo: nessuna reinizializzazione consentita.')
        if db.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
            raise RuntimeError('Database non integro: avvio interrotto, ripristinare un backup.')


def copy_user_files(root, dest):
    for path in sorted(root.iterdir()):
        if path.name in EXCLUDED or path.name.startswith('.guard-'): continue
        entries = [path, *path.rglob('*')] if path.is_dir() else [path]
        for item in entries:
            if item.is_symlink(): raise RuntimeError('File utente con link simbolico: backup interrotto, nessun dato modificato.')
            relative = item.relative_to(root)
            target = dest / relative
            if item.is_dir(): target.mkdir(parents=True, exist_ok=True, mode=0o700)
            elif item.is_file():
                before = file_digest(item)
                target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
                shutil.copy2(item, target); target.chmod(0o600)
                if file_digest(target) != before or file_digest(item) != before:
                    raise RuntimeError('Un file è cambiato durante il backup: riprovare.')


def snapshot(root, reason='manual'):
    root = Path(root).resolve()
    check_database(root / DB)
    directory = root / 'backups' / 'updates'
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    temp = Path(tempfile.mkdtemp(prefix='.pending-', dir=directory)); temp.chmod(0o700)
    try:
        target = temp / DB
        with contextlib.closing(sqlite3.connect((root / DB).as_uri()+'?mode=ro', uri=True, timeout=30)) as source:
            with contextlib.closing(sqlite3.connect(target)) as dest:
                source.backup(dest)
        target.chmod(0o600); check_database(target)
        files = temp / 'files'; files.mkdir(mode=0o700)
        copy_user_files(root, files)
        hashes = {str(p.relative_to(temp)): file_digest(p)
                  for p in temp.rglob('*') if p.is_file()}
        atomic_json(temp / 'manifest.json', {'format':1, 'reason':reason, 'state':state(root), 'sha256':hashes})
        name = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+secrets.token_hex(4)
        final = directory / name
        temp.rename(final)
        return final
    except Exception:
        # Keep incomplete output for diagnosis; never advertise it as a backup.
        raise


@contextlib.contextmanager
def offline_lock(root):
    fd = os.open(root / 'application.lock', os.O_CREAT | os.O_RDWR, 0o600)
    try:
        try: fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise RuntimeError('Arresta i servizi locali dalla vecchia app prima di aggiornare o ripristinare.') from error
        yield
    finally:
        os.close(fd)


def prepare(root, project):
    root = Path(root).resolve(); root.mkdir(parents=True, exist_ok=True, mode=0o700)
    # Reject data paths inside the application, even with an environment override.
    project = Path(project).resolve()
    if root == project or project in root.parents or any(part.endswith('.app') for part in root.parts):
        raise RuntimeError('La cartella dati deve essere esterna al pacchetto applicazione.')
    if (root / 'restore-in-progress.json').exists():
        raise RuntimeError('Ripristino interrotto: completarlo prima di avviare l’app.')
    current = state(root)
    db = root / DB
    previous_files = any(p.name not in EXCLUDED | {STATE, 'private'} for p in root.iterdir())
    if not db.exists() and (current.get('initialized') or (root / 'django-secret').exists()
                            or previous_files or any((root / 'private').rglob('*'))):
        raise RuntimeError('Database già inizializzato ma ora mancante: avvio bloccato. Ripristinare un backup, non creare nuovi dati.')
    if current.get('installed_build',0) > BUILD:
        raise RuntimeError('Versione precedente al database: usare il backup e la versione corrispondente.')
    release = fingerprint(project)
    if current.get('installed_release') == release:
        if db.exists(): check_database(db)
        return
    with offline_lock(root):
        current = state(root)
        backup = snapshot(root, 'before-update') if db.exists() else None
        if current.get('prepared_release') != release:
            current['original_update_backup'] = str(backup) if backup else None
        current.update(prepared_release=release, initialized=db.exists(),
                       last_update_backup=str(backup) if backup else None)
        atomic_json(root / STATE, current)


def completed(root, project):
    root = Path(root); check_database(root / DB)
    current = state(root)
    current.update(initialized=True, installed_release=fingerprint(Path(project)),
                   installed_build=BUILD, prepared_release=None)
    atomic_json(root / STATE, current)


def restore(root, backup):
    root = Path(root).resolve(); backup = Path(backup).resolve()
    if backup.parent != root / 'backups' / 'updates':
        raise RuntimeError('Selezionare un backup completo nella cartella backups/updates.')
    manifest = json.loads((backup / 'manifest.json').read_text())
    if manifest.get('format') != 1 or DB not in manifest.get('sha256',{}):
        raise RuntimeError('Formato backup non riconosciuto.')
    for name, checksum in manifest['sha256'].items():
        path = backup / name
        if path.resolve().is_relative_to(backup) is False or path.is_symlink() or not path.is_file() or file_digest(path) != checksum:
            raise RuntimeError('Backup incompleto o checksum non valido: ripristino annullato.')
    actual = {str(p.relative_to(backup)) for p in backup.rglob('*') if p.is_file() or p.is_symlink()}
    if actual != set(manifest['sha256']) | {'manifest.json'}:
        raise RuntimeError('Contenuto del backup alterato: ripristino annullato.')
    check_database(backup / DB)
    with offline_lock(root):
        # Preserve current state even when its SQLite file is corrupt. No deletion.
        rescue = root / 'backups' / ('before-restore-'+secrets.token_hex(8))
        rescue.mkdir(mode=0o700)
        copy_user_files(root, rescue)
        for name in (DB, DB+'-wal', DB+'-shm', DB+'-journal'):
            if (root / name).exists(): shutil.copy2(root / name, rescue / name)
        atomic_json(root / 'restore-in-progress.json', {'backup':str(backup), 'rescue':str(rescue)})
        restore_files = backup / 'files'
        for path in restore_files.rglob('*'):
            dest = root / path.relative_to(restore_files)
            if not dest.resolve().is_relative_to(root) or dest.is_symlink():
                raise RuntimeError('Destinazione con link simbolico: ripristino interrotto in sicurezza.')
            if path.is_dir(): dest.mkdir(parents=True, exist_ok=True, mode=0o700)
            else:
                dest.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
                fd, temp = tempfile.mkstemp(prefix='.guard-', dir=dest.parent); os.close(fd)
                shutil.copy2(path, temp); os.chmod(temp,0o600); os.replace(temp,dest)
        # Sidecars preserved in rescue before removal; never applied to restored DB.
        for name in (DB+'-wal',DB+'-shm',DB+'-journal'):
            with contextlib.suppress(FileNotFoundError): (root / name).unlink()
        fd, temp = tempfile.mkstemp(prefix='.guard-', dir=root); os.close(fd)
        shutil.copy2(backup / DB,temp); os.chmod(temp,0o600); os.replace(temp,root / DB)
        restored = manifest.get('state',{})
        restored.update(initialized=True, prepared_release=None)
        atomic_json(root / STATE,restored)
        (root / 'restore-in-progress.json').unlink()
        return rescue


if __name__ == '__main__':
    try:
        action, root, argument = sys.argv[1:]
        if action == 'prepare': prepare(root,argument)
        elif action == 'restore': print('Ripristino completato. Stato precedente conservato in:',restore(root,argument))
        else: raise RuntimeError('Operazione non ammessa.')
    except Exception as error:
        print(str(error),file=sys.stderr)
        raise SystemExit(1)
