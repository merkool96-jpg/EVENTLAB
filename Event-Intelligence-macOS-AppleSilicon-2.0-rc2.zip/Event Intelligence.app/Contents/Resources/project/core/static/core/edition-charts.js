// Only bar geometry uses floating point; all financial labels are server formatted.
(()=>{
 const node=document.getElementById('edition-chart-data');
 const chart=document.querySelector('[data-edition-chart]');
 const selector=document.getElementById('edition-metric');
 if(!node||!chart||!selector)return;
 const rows=JSON.parse(node.textContent);
 function draw(){
  const key=selector.value;const available=rows.filter(row=>row.values[key].value!==null);
  const max=Math.max(...available.map(row=>Number(row.values[key].value)),1);
  chart.replaceChildren();
  document.querySelector('[data-edition-status]').textContent=`Copertura: ${available.length} di ${rows.length} edizioni. ${selector.selectedOptions[0].textContent}.`;
  rows.forEach(row=>{
   const metric=row.values[key];const line=document.createElement('div');line.className='chart-row edition-row';
   const link=document.createElement('a');link.href=row.url;link.textContent=row.label;
   const bar=document.createElement('div');bar.className='chart-bar';bar.style.minWidth='0';
   bar.style.width=metric.value===null?'0':(Number(metric.value)/max*100)+'%';
   const value=document.createElement('span');value.textContent=metric.display;
   line.title=row.label+': '+metric.display;line.append(link,bar,value);chart.append(line);
  });
  if(!rows.length){const empty=document.createElement('p');empty.textContent='Nessuna edizione selezionata.';chart.append(empty);}
 }
 selector.addEventListener('change',draw);draw();
})();
