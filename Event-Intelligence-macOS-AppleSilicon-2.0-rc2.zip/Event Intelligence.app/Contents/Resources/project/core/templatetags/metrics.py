from django import template
from django.utils.formats import number_format

register = template.Library()


@register.filter
def metric(value, decimals=2):
    if value is None:
        return "Non disponibile"
    return number_format(value, decimal_pos=int(decimals), force_grouping=True)


@register.filter
def section_label(value):
    return {
        "summary": "Sintesi",
        "performance": "Panoramica performance",
        "worked": "Cosa ha funzionato",
        "attention": "Criticità e attenzione",
        "creatives": "Confronto creatività",
        "previous_events": "Edizioni precedenti",
        "anomalies": "Anomalie",
        "limits": "Limiti e qualità dati",
        "recommendations": "Raccomandazioni",
        "actions": "Azioni pratiche",
        "experiments": "Esperimenti suggeriti",
        "priorities": "Priorità",
    }.get(value, value)


@register.filter
def goal_label(value):
    return {'tickets':'Biglietti (tutti)','ticket_paid':'Biglietti pagati','rsvp':'RSVP confermati','free_registration':'Registrazioni gratuite'}.get(value,value)


@register.filter
def evidence_label(value):
    return {'omogeneo':'Edizione omogenea','tipo':'Natura','scenario':'Scenario','quantita':'Quantità','ricavi':'Ricavi EUR','costi':'Costi EUR','margine':'Margine EUR','spesa':'Spesa EUR','costi_completi':'Costi completi','quantita_obiettivo':'Quantità obiettivo','budget_massimo':'Budget massimo EUR','costi_fissi_massimi':'Costi fissi massimi EUR','costi_verificati':'Categorie di costo verificate','budget':'Budget EUR','prezzo':'Ricavo unitario EUR','capienza':'Capienza','tipo_risultato':'Tipo risultato'}.get(value,value)


@register.filter
def evidence_value(value):
    if isinstance(value,bool):return 'Sì' if value else 'No'
    return goal_label(value) if isinstance(value,str) else value
