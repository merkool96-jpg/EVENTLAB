"""Deterministic operating levers and observed progress. No demand extrapolation."""
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR
from django.utils import timezone


def operating_levers(inputs, result):
    d={key:Decimal(str(inputs[key])) for key in ('price','variable_cost','fee','fixed_cost','ad_budget','other_income','desired_margin')}
    target=inputs['target'];capacity=inputs['capacity']
    contribution=d['price']-d['variable_cost']-d['fee']
    ad_limit=(target*contribution+d['other_income']-d['fixed_cost']-d['desired_margin']).quantize(Decimal('.01'),rounding=ROUND_FLOOR)
    fixed_limit=(target*contribution+d['other_income']-d['ad_budget']-d['desired_margin']).quantize(Decimal('.01'),rounding=ROUND_FLOOR)
    headroom=ad_limit-d['ad_budget']
    result_margin=Decimal(str(result['target_margin']))
    actions=[]
    if result_margin<d['desired_margin']:
        actions.append(dict(priority='Alta',title='Colmare il divario economico',
            action='Riduci i costi complessivi o aggiungi ricavi per questo importo; confronta anche il prezzo unitario necessario.',
            value=d['desired_margin']-result_margin,unit='EUR'))
    else:
        actions.append(dict(priority='Monitoraggio',title='Margine di sicurezza rispetto all’obiettivo economico',
            action='Questo cuscinetto vale solo se la quantità obiettivo e tutte le ipotesi si realizzano.',
            value=result_margin-d['desired_margin'],unit='EUR'))
    if headroom<0:
        actions.append(dict(priority='Alta',title='Riduzione di costo necessaria al target',
            action='La voce pubblicitaria può assorbire la riduzione solo entro il budget disponibile; per la parte restante agisci su altri costi o ricavi.',
            value=-headroom,unit='EUR'))
    if result['breakeven'] is not None:
        actions.append(dict(priority='Operativa',title='Soglia di pareggio da monitorare',
            action='Confronta le quantità confermate con questa soglia, rispettando lo stesso tipo di risultato.',
            value=result['breakeven'],unit='unità'))
    downside=max(Decimal(0),-Decimal(str(result['scenarios'][0]['margin'])))
    if downside:
        actions.append(dict(priority='Alta',title='Copertura della perdita prudente',action='Prevedi questa copertura se si realizza la quantità prudente, oppure riduci gli impegni fissi.',value=downside,unit='EUR'))
    if not inputs.get('costs_reviewed'):
        actions.insert(0,dict(priority='Alta',title='Completare il preventivo',action='Conferma categorie di costo, commissioni e altri ricavi prima di considerare sostenibile il piano.',value=None,unit=''))
    return dict(ad_budget_ceiling=ad_limit if ad_limit>=0 else None,fixed_cost_ceiling=fixed_limit if fixed_limit>=0 else None,
        funding_gap_without_ads=max(Decimal(0),-ad_limit),ad_headroom=headroom,
        break_even_occupancy=Decimal(result['breakeven'])*100/capacity if result['breakeven'] is not None else None,
        target_occupancy=Decimal(target)*100/capacity,downside_loss=downside,
        scenario_occupancy=[dict(name=s['name'],percent=Decimal(s['quantity'])*100/capacity) for s in result['scenarios']],
        actions=actions)


def progress(inputs, results, observed, event_date, today=None):
    today=today or timezone.localdate()
    quantity=observed['quantity'];target=inputs['target'];spend=observed['spend']
    budget=Decimal(str(inputs['ad_budget']))
    days=max(0,(event_date-today).days)
    remaining=max(0,target-quantity) if quantity is not None else None
    actions_day=int((Decimal(remaining)/days).to_integral_value(rounding=ROUND_CEILING)) if remaining is not None and days>0 else None
    return dict(days=days,finished=event_date<today,target=target,
        completion=Decimal(quantity)*100/target if quantity is not None and target else None,
        remaining=remaining,required_daily=actions_day,
        remaining_budget=budget-spend if spend is not None else None,
        budget_consumption=spend*100/budget if spend is not None and budget else None,
        scenarios=[dict(name=s['name'],quantity=s['quantity'],margin=s['margin'],
            delta=quantity-s['quantity'] if quantity is not None else None) for s in results['scenarios']],
        rules=[dict(label='Consuntivo importato',quantity=quantity,spend=spend),
            dict(label='Obiettivo manuale',quantity=target,spend=budget)])


def revision_evolution(revisions, observed):
    rows=[]
    for revision in reversed(list(revisions)):
        central=next(s for s in revision.results['scenarios'] if s['name']=='Centrale')
        goal=revision.inputs['goal']
        actual=observed.get(goal)
        rows.append(dict(number=revision.number,id=revision.pk,date=revision.created_at,goal=goal,
            quantity=central['quantity'],margin=central['margin'],budget=revision.inputs['ad_budget'],
            actual=actual['quantity'] if actual else None,
            error=actual['quantity']-central['quantity'] if actual and actual['quantity'] is not None else None))
    return rows


def historical_position(inputs, sources):
    """Compare assumptions to frozen observations, not an adoption recommendation."""
    rows=[]
    for source in sources:
        observed=source['actuals'];quantity=observed['quantity'];spend=observed['spend']
        unit_price=Decimal(str(observed['ticket_revenue']))/quantity if inputs['goal'] in ('tickets','ticket_paid') and quantity and observed.get('ticket_revenue') is not None else None
        rows.append(dict(name=source['name'],id=source['id'],compatible=source.get('compatible',True),limits=source.get('comparison_limits',[]),quantity=quantity,spend=spend,
            quantity_gap=inputs['target']-quantity if quantity is not None else None,
            spend_gap=Decimal(str(inputs['ad_budget']))-Decimal(str(spend)) if spend is not None else None,
            observed_unit_revenue=unit_price,
            unit_revenue_gap=Decimal(str(inputs['price']))-unit_price if unit_price is not None else None,
            margin=observed['margin'],costs_complete=source['costs_complete']))
    return rows


def alternatives(inputs, results):
    from core.forecast_forms import ForecastForm
    from django.core.exceptions import ValidationError
    levers=results.get('operational') or operating_levers(inputs,results)
    candidates=[('ad_budget',levers['ad_budget_ceiling'],'Simula budget sostenibile'),
                ('fixed_cost',levers['fixed_cost_ceiling'],'Simula tetto dei costi fissi')]
    if inputs['goal'] in ('tickets','ticket_paid'):
        candidates.append(('price',results['required_price'],'Simula prezzo necessario'))
    choices=[]
    for field,value,label in candidates:
        if value is None or Decimal(str(value))==Decimal(str(inputs[field])):continue
        try: value=ForecastForm.base_fields[field].clean(value)
        except ValidationError: continue
        choices.append(dict(field=field,value=value,label=label))
    return choices
