"""Optional local explanation; immutable numeric snapshots, no cloud or math by AI."""
import json
import re
import uuid
from datetime import timedelta
import httpx
from django.db import transaction
from django.utils import timezone
from core.models import ForecastRevision
from .generative_ai import configuration
from .ollama import valid_endpoint, readiness


def local_config():
    cfg=configuration()
    if cfg.get('reason') or cfg.get('provider')!='ollama' or not valid_endpoint(cfg.get('endpoint','')):
        raise ValueError('Ollama non configurato')
    return cfg


def request_explanation(revision):
    with transaction.atomic():
        revision=ForecastRevision.objects.select_for_update().get(pk=revision.pk)
        if revision.explanation.get('state') in ('queued','running'): return
        history=list(revision.explanation.get('history',[]))
        if revision.explanation.get('state')=='done':
            history.append({key:value for key,value in revision.explanation.items() if key!='history'})
        try: local_config()
        except ValueError:
            revision.explanation={'state':'error','message':'Ollama locale non configurato. I consigli a regole restano disponibili.'}
        else:
            revision.explanation={'state':'queued','token':str(uuid.uuid4()),'message':'Spiegazione in coda; puoi continuare a utilizzare l’app.'}
        revision.explanation['history']=history
        revision.save(update_fields=['explanation','updated_at'])


def facts(revision):
    # Explicit assumptions only. Never send original files, contacts or user free text.
    evidence={f's{i}':dict(tipo='ipotesi condizionale',scenario=s['name'],quantita=s['quantity'],
        ricavi=s['revenue'],costi=s['costs'],margine=s['margin']) for i,s in enumerate(revision.results['scenarios'])}
    # Bounded historical context. No names, contacts, files or user free text.
    for index,source in enumerate(revision.sources[:3]):
        actual=source['actuals']
        evidence[f'h{index}']=dict(tipo='osservazione storica comparabile',quantita=actual['quantity'],
            spesa=actual['spend'],margine=actual['margin'],costi_completi=source['costs_complete'],omogeneo=source.get('compatible',True))
    from .forecast_advice import operating_levers
    levers=revision.results.get('operational') or operating_levers(revision.inputs,revision.results)
    # Stringify Decimal before the Ollama JSON transport; calculations stay in Python.
    def number(value):return str(value) if value is not None else None
    evidence['l0']=dict(tipo='limite condizionale calcolato',quantita_obiettivo=revision.inputs['target'],
        budget_massimo=number(levers['ad_budget_ceiling']),costi_fissi_massimi=number(levers['fixed_cost_ceiling']),
        costi_verificati=bool(revision.inputs.get('costs_reviewed')))
    evidence['l1']=dict(tipo='ipotesi manuale',budget=revision.inputs['ad_budget'],prezzo=revision.inputs['price'],
        capienza=revision.inputs['capacity'],tipo_risultato=revision.inputs['goal'])
    return evidence


def process_forecast_task(transport=None):
    with transaction.atomic():
        # An interrupted worker must not leave the interface permanently queued.
        ForecastRevision.objects.filter(explanation__state='running',updated_at__lt=timezone.now()-timedelta(minutes=5)).update(
            explanation={'state':'error','message':'Elaborazione interrotta. Nessun reinvio automatico; puoi richiedere un nuovo tentativo.'})
        revision=ForecastRevision.objects.select_for_update().filter(explanation__state='queued').order_by('created_at').first()
        if not revision: return False
        token=revision.explanation['token']
        revision.explanation={**revision.explanation,'state':'running','message':'Ollama sta spiegando gli scenari in background.'}
        revision.save(update_fields=['explanation','updated_at'])
    result={'state':'error','message':'Ollama non disponibile, timeout o risposta non valida. Usa i consigli a regole oppure riprova.'}
    try:
        cfg=local_config()
        if readiness(cfg,transport=transport): raise ValueError
        evidence=facts(revision)
        item={'type':'object','properties':{'text':{'type':'string','maxLength':240},
            'evidence_ids':{'type':'array','minItems':1,'maxItems':3,'items':{'type':'string','enum':list(evidence)}}},
            'required':['text','evidence_ids'],'additionalProperties':False}
        schema={'type':'object','properties':{'items':{'type':'array','minItems':1,'maxItems':3,'items':item}},'required':['items'],'additionalProperties':False}
        payload={'model':cfg['model'],'stream':False,'think':False,'keep_alive':0,'format':schema,
            'options':{'num_ctx':2048,'num_predict':512,'num_thread':4,'temperature':0},
            'messages':[{'role':'system','content':'/no_think Spiega in italiano rischi e scelte degli scenari condizionali, considerando i limiti economici e lo storico osservato se presente. Distingui ipotesi manuali da fatti storici; omogeneo falso indica soltanto contesto, non un benchmark da replicare; costi incompleti impediscono conclusioni sulla redditività. Nessuna domanda futura stimata, nessuna probabilità o causalità pubblicitaria. Non inventare dati: nessuna cifra nel testo, cita gli id forniti. Una frase per consiglio, JSON conforme allo schema.'},
                        {'role':'user','content':json.dumps(evidence,ensure_ascii=False)}]}
        with httpx.Client(timeout=90,trust_env=False,follow_redirects=False,transport=transport) as client:
            with client.stream('POST',cfg['endpoint'],json=payload) as response:
                response.raise_for_status();raw=bytearray()
                for chunk in response.iter_bytes():
                    raw.extend(chunk)
                    if len(raw)>128000: raise ValueError
        body=json.loads(raw)
        if body.get('done') is not True or body.get('done_reason') not in (None,'stop'): raise ValueError
        answer=json.loads(body['message']['content'])
        if set(answer)!={'items'} or not isinstance(answer['items'],list) or not 1<=len(answer['items'])<=3: raise ValueError
        for item in answer['items']:
            if set(item)!={'text','evidence_ids'} or not isinstance(item['text'],str) or not 1<=len(item['text'])<=240 or re.search(r'\d',item['text']): raise ValueError
            ids=item['evidence_ids']
            if not isinstance(ids,list) or not 1<=len(ids)<=3 or any(not isinstance(i,str) or i not in evidence for i in ids): raise ValueError
        result={'state':'done','message':'Interpretazione AI delle ipotesi, da verificare. Nessun numero è calcolato dal modello.',
            'items':answer['items'],'model':cfg['model'],'prompt_version':'forecast-local-2','facts':evidence,'completed_at':timezone.now().isoformat()}
    except (httpx.HTTPError,ValueError,TypeError,KeyError,OSError): pass
    with transaction.atomic():
        fresh=ForecastRevision.objects.select_for_update().get(pk=revision.pk)
        if fresh.explanation.get('token')==token:
            fresh.explanation={**result,'token':token,'history':fresh.explanation.get('history',[])};fresh.save(update_fields=['explanation','updated_at'])
    return True
