"""Explain observed changes and their coverage, without causal or demand claims."""
from collections import defaultdict
from decimal import Decimal
from django.utils import timezone
from django.utils.formats import number_format
from django.urls import reverse
from core.models import ParticipationRecord, StrategicDecision

LABELS = dict(spend='Spesa pubblicitaria', tickets='Biglietti', rsvp='RSVP',
              registrations='Registrazioni gratuite', revenue='Ricavi biglietti', margin='Margine verificabile')


def difference(current, previous):
    if current is None or previous is None:
        return None
    delta=Decimal(current)-Decimal(previous)
    return dict(before=previous,after=current,delta=delta,
                percent=delta/abs(Decimal(previous))*100 if previous else None)


def directional(rows):
    ids=[r['event'].pk for r in rows]
    kinds=defaultdict(set)
    for event_id,kind in ParticipationRecord.objects.filter(batch__event_id__in=ids,batch__status='confirmed').values_list('batch__event_id','kind'):
        kinds[event_id].add(kind)
    observations=[]
    for row in rows:
        event=row['event'];conv=row['conversions'];available=kinds[event.pk]
        has_tickets=bool(row['order_rows']) or bool(available & {'ticket_paid','ticket_free','ticket_unknown'})
        has_rsvp=row['registrations'] is not None or 'rsvp' in available
        revenue=row['ticket_revenue']
        standalone=conv['standalone_ticket_revenue']
        if available & {'ticket_paid','ticket_free','ticket_unknown'}:
            revenue=(revenue+standalone if revenue is not None and standalone is not None else None) if row['order_rows'] else standalone
        values=dict(spend=row['kpis']['spend'],tickets=conv['ticket_paid']+conv['ticket_free']+conv['ticket_unclassified'] if has_tickets else None,
            rsvp=conv['rsvp'] if has_rsvp else None,registrations=conv['free_registration'] if 'free_registration' in available else None,
            revenue=revenue,margin=row.get('verified_margin'))
        observations.append(dict(event=event,values=values,overlap=conv['potential_overlap'],finished=event.date<timezone.localdate()))
    observations.sort(key=lambda row:(row['event'].date,str(row['event'].pk)))
    previous={};comparisons=[];priorities=[]
    for item in observations:
        event=item['event'];values=item['values']
        if values['margin'] is not None and values['margin']<0:
            priorities.append(dict(event=event,title='Perdita economica verificabile',value=-values['margin'],unit='EUR',action='Verifica costi e ricavi prima di replicare il modello economico.'))
        if values['spend'] is not None and event.planned_budget is not None and values['spend']>event.planned_budget:
            priorities.append(dict(event=event,title='Budget pubblicitario superato',value=values['spend']-event.planned_budget,unit='EUR',action='Rivedi il budget residuo prima di aumentare l’investimento.'))
        if not item['finished']: continue
        key=(event.brand_id,event.format_id,event.mode)
        prior=previous.get(key)
        if prior and prior['event'].date<event.date:
            changes=[]
            for metric,label in LABELS.items():
                change=difference(values[metric],prior['values'][metric])
                if change is not None:changes.append(dict(key=metric,label=label,unit='EUR' if metric in ('spend','revenue','margin') else 'unità',**change))
            comparisons.append(dict(event=event,previous=prior['event'],changes=changes,
                                    overlap=item['overlap'] or prior['overlap']))
        previous[key]=item
    # Exact email links, not name matching or physical attendance. Scope is explicit.
    email_events=defaultdict(set)
    for contact,event_id in ParticipationRecord.objects.filter(batch__event_id__in=ids,batch__status='confirmed',contact__email_key__isnull=False).values_list('contact_id','batch__event_id'):
        email_events[event_id].add(contact)
    seen=set();audience=[]
    for day in sorted({r['event'].date for r in observations}):
        on_day=[r for r in observations if r['event'].date==day]
        day_contacts=set().union(*(email_events[r['event'].pk] for r in on_day))
        for item in on_day:
            contacts=email_events[item['event'].pk];returning=contacts & seen
            audience.append(dict(event=item['event'],linked=len(contacts),returning=len(returning),
                new=len(contacts-seen),rate=Decimal(len(returning))*100/len(contacts) if contacts else None))
        seen.update(day_contacts) # Same-day editions cannot establish a return sequence.
    decisions=list(StrategicDecision.objects.filter(event_id__in=ids).select_related('event').order_by('-updated_at')[:10])
    chart=[]
    for item in observations:
        event=item['event']
        chart.append(dict(label=event.name+' · '+event.date.isoformat(),url=reverse('event-detail',args=[event.pk]),
            values={key:dict(value=str(item['values'][key]) if item['values'][key] is not None else None,
                display=number_format(item['values'][key],decimal_pos=2 if key in ('spend','revenue') else 0,force_grouping=True) if item['values'][key] is not None else 'Non disponibile')
                for key in ('spend','revenue','tickets','rsvp')}))
    return dict(chart=chart, observations=observations,comparisons=comparisons,priorities=priorities,
                audience=audience,decisions=decisions,decision_count=StrategicDecision.objects.filter(event_id__in=ids).count(),
                completed_comparisons=len(comparisons))
