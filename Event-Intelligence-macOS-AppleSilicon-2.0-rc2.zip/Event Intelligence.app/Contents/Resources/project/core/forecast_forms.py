from decimal import Decimal
from django import forms
from django.utils import timezone
from .models import Event


class HistoricalChoices(forms.ModelMultipleChoiceField):
    def label_from_instance(self,event):
        return f'{event.name} · {event.brand.name} · {event.date.isoformat()}'


class ForecastForm(forms.Form):
    event = forms.ModelChoiceField(label='Evento', queryset=Event.objects.select_related('brand', 'format'))
    comparables = HistoricalChoices(label='Edizioni storiche da confrontare (facoltative)',
        queryset=Event.objects.none(),required=False,widget=forms.CheckboxSelectMultiple,
        help_text='Lascia vuoto per i confronti automatici omogenei. Puoi selezionare fino a trenta edizioni concluse anche di brand diversi, dichiarando il motivo.')
    comparison_note = forms.CharField(label='Motivo e limiti del confronto storico scelto',required=False,max_length=1000,widget=forms.Textarea(attrs={'rows':2}))
    title = forms.CharField(label='Nome simulazione', max_length=160)
    capacity = forms.IntegerField(label='Capienza massima', min_value=1, max_value=1000000)
    goal = forms.ChoiceField(label='Unità obiettivo', choices=[('tickets', 'Biglietti (tutti)'),
        ('ticket_paid','Biglietti pagati'), ('rsvp','RSVP confermati'), ('free_registration','Registrazioni gratuite')])
    target = forms.IntegerField(label='Obiettivo quantità', min_value=0, max_value=1000000)
    prudent = forms.IntegerField(label='Quantità prudente (ipotesi manuale)', min_value=0, max_value=1000000)
    central = forms.IntegerField(label='Quantità centrale (ipotesi manuale)', min_value=0, max_value=1000000)
    optimistic = forms.IntegerField(label='Quantità ottimistica (ipotesi manuale)', min_value=0, max_value=1000000)
    price = forms.DecimalField(label='Ricavo medio unitario EUR (prima dei costi sotto)', min_value=0, max_digits=12, decimal_places=2)
    ad_budget = forms.DecimalField(label='Budget pubblicitario EUR', min_value=0, max_digits=12, decimal_places=2)
    fixed_cost = forms.DecimalField(label='Costi fissi EUR (pubblicità esclusa)', min_value=0, max_digits=12, decimal_places=2)
    variable_cost = forms.DecimalField(label='Costo variabile unitario EUR', min_value=0, max_digits=12, decimal_places=2)
    fee = forms.DecimalField(label='Commissione unitaria a carico organizzatore EUR', min_value=0, max_digits=12, decimal_places=2)
    other_income = forms.DecimalField(label='Altri ricavi EUR', min_value=0, max_digits=12, decimal_places=2)
    desired_margin = forms.DecimalField(label='Margine desiderato EUR', min_value=0, max_digits=12, decimal_places=2)
    assumed_cpa = forms.DecimalField(label='Costo per azione ipotizzato EUR (facoltativo)', required=False,
        min_value=Decimal('0.0001'), max_digits=12, decimal_places=4,
        help_text='Ipotesi manuale, non attribuzione o previsione di acquisizione.')
    stress = forms.IntegerField(label='Variazione per sensibilità % (non probabilità)', min_value=1, max_value=50, initial=10)
    assumptions = forms.CharField(label='Assunzioni e limiti', max_length=4000, widget=forms.Textarea(attrs={'rows':3}))
    costs_reviewed = forms.BooleanField(label='Ho verificato tutte le categorie di costo; restano ipotesi', required=False)

    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.fields['comparables'].queryset=Event.objects.filter(date__lt=timezone.localdate()).select_related('brand','format')

    def clean(self):
        data = super().clean()
        keys = ('prudent','central','optimistic','capacity','target')
        if all(k in data for k in keys):
            if not data['prudent'] <= data['central'] <= data['optimistic'] <= data['capacity']:
                self.add_error(None, 'Le quantità devono essere ordinate: prudente ≤ centrale ≤ ottimistica ≤ capienza.')
            if data['target'] > data['capacity']:
                self.add_error('target', 'L’obiettivo supera la capienza.')
        if data.get('goal') in ('rsvp','free_registration') and data.get('price',0) != 0:
            self.add_error('price', 'RSVP e registrazioni gratuite richiedono ricavo unitario zero; indica eventuali sponsorizzazioni negli altri ricavi.')
        event=data.get('event');selected=data.get('comparables')
        if event is not None and selected is not None:
            if len(selected)>30:self.add_error('comparables','Seleziona al massimo trenta edizioni.')
            if any(past.pk==event.pk or past.date>=event.date for past in selected):
                self.add_error('comparables','Gli eventi storici devono precedere la data dell’evento pianificato.')
            heterogeneous=any((past.brand_id,past.format_id,past.mode)!=(event.brand_id,event.format_id,event.mode) for past in selected)
            if heterogeneous and not data.get('comparison_note'):
                self.add_error('comparison_note','Descrivi perché confronti edizioni con brand, format o modalità diversi; non sono benchmark omogenei.')
        return data
